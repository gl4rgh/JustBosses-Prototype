# Versioning — Git pour UE5 (Just Bosses) v0.0.1

## État actuel du repo

```
E:\JustBosses\JustBosses\.git  ← initialisé ✓
Git LFS 3.7.1                  ← installé et configuré ✓
Commits actuels :
  4c2251a  chore: Git LFS setup + Config + Input actions
  027ab96  docs: blender pipeline, RT bounces, AA/upscaling
  f13d217  chore: initial commit docs + tutos
  f52cfe1  chore: init repo + gitignore
```

Identité git locale configurée : `schla / schla@justbosses.local`
→ Pour changer : `git config user.email "ton@email.com"` dans le dossier projet.

---

## Setup — ce qui est déjà fait

- ✅ `.gitignore` — exclut Intermediate/, Saved/, DerivedDataCache/, Binaries/
- ✅ `.gitattributes` — LFS track sur `.uasset` `.umap` `.fbx` `.png` `.jpg` `.tga` `.wav` `.mp3` `.blend`
- ✅ `Config/` — parametres moteur/jeu committés
- ✅ `Content/Input/` — Input Actions de base

---

## Ce qu'on commit, ce qu'on ne commit pas

### ✅ Committer au fil du dev

```
Content/Blueprints/        ← BP_JB_Character, BP_JB_DummyBoss, etc.
Content/Maps/              ← L_Arena_01.umap et futures maps
Content/Materials/         ← M_Projectile, M_Arena_Floor, etc.
Content/Effects/           ← NS_ElectricBolt, NS_PlayerHit
Content/Audio/             ← SFX, Metasounds
Content/Input/             ← déjà committé
Config/                    ← déjà committé
docs/                      ← déjà committé
```

### ❌ Ne PAS committer (template Epic, pas notre code)

```
Content/Characters/Mannequins/   ← mannequin template Epic (126 Mo — pas notre asset)
Content/DemoTemplate/            ← démo Epic
Content/FirstPerson/             ← blueprint FPS template
Content/LevelPrototyping/        ← grid materials template
Content/__ExternalActors__/      ← World Partition (géré auto par UE5, conflits garantis)
Content/__ExternalObjects__/     ← idem
```

> Ajouter ces dossiers à `.gitignore` si tu veux être propre (voir ci-dessous).

---

## Ajouter les dossiers template au .gitignore

Ouvre `.gitignore` et ajoute :

```gitignore
# Contenu template Epic (pas du code projet)
Content/Characters/
Content/DemoTemplate/
Content/FirstPerson/
Content/LevelPrototyping/
Content/Localization/
Content/__ExternalActors__/
Content/__ExternalObjects__/
Content/Collections/
Content/Developers/
```

Puis :
```bash
git add .gitignore
git commit -m "chore: ignore Epic template content + World Partition folders"
```

---

## Workflow quotidien — pratique

### 1. Après avoir créé/modifié un Blueprint dans UE5

```bash
# Dans Git Bash ou le terminal, depuis E:\JustBosses\JustBosses\

git status                          # voir ce qui a changé
git add Content/Blueprints/         # ajouter tous les BP modifiés
git add Content/Maps/               # ajouter les maps si modifiées
git commit -m "feat: BP_JB_Character dash + iframes (step03)"
```

### 2. Après avoir modifié de la doc

```bash
git add docs/
git commit -m "docs: update step02 arena style Algos"
```

### 3. Vérifier l'état en permanence

```bash
git status       # fichiers modifiés / non trackés
git log --oneline -10   # 10 derniers commits
git diff         # voir les changements en cours (texte seulement — .uasset pas diffable)
```

---

## Convention de nommage des commits

```
feat:   nouvelle fonctionnalité BP (feat: BP_JB_Projectile snap P1003)
fix:    correction de bug         (fix: DashCooldown reset on death)
docs:   documentation             (docs: step07 patterns suite)
chore:  maintenance               (chore: gitignore, config)
perf:   optimisation              (perf: disable Tick on idle projectiles)
art:    asset visuel              (art: M_Projectile_v2 electric corona)
wip:    work in progress          (wip: step06 pattern engine — pas terminé)
```

---

## Récupérer un fichier cassé

Si un Blueprint est corrompu après une modif :

```bash
# Revenir à la dernière version committée
git checkout HEAD -- Content/Blueprints/Character/BP_JB_Character.uasset
```

> C'est le cas d'usage principal de git pour UE5 — pas besoin de remote pour ça.

---

## Remote optionnel (GitHub)

Si tu veux un backup cloud :

```bash
# Créer un repo privé sur GitHub (obligatoire — assets sous licence Epic)
gh repo create JustBosses --private
git remote add origin https://github.com/schla/JustBosses.git   # remplacer schla par ton username GitHub
git push -u origin master

# Push quotidien
git push
```

> **GitHub LFS gratuit : 1 Go.** Au-delà = payant ($5/mois pour 50 Go).
> Avec Content/ entier (172 Mo) + futures maps → budget LFS consommé rapidement.
> Alternative : remote local sur NAS ou disque réseau : `git remote add backup //NAS/JustBosses`

---

## Branches — à quand ?

Pour le moment (solo, 0.0.1) : **travailler directement sur `master`**.
Les branches deviennent utiles quand :
- Plusieurs personnes travaillent en parallèle
- Tu veux expérimenter sans casser le build stable (branche `experiment/water-boss`)
- Un step est long et risqué (branche `step/07-patterns-suite`)

```bash
# Créer une branche d'expérimentation
git checkout -b experiment/water-arena
# ... tester ...
# Si concluant → merge
git checkout master
git merge experiment/water-arena
# Si pas concluant → abandon
git branch -D experiment/water-arena
```

---

## Taille actuelle du repo

```bash
git count-objects -vH   # voir la taille du repo local
```

> Avec LFS, les binaires sont stockés dans `.git/lfs/` séparément du repo.
> Le repo texte reste léger même avec des centaines de .uasset.
