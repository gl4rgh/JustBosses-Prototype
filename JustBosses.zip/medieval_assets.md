# Assets Médiévaux / Renaissance — Inventaire

**Téléchargés le :** 2026-02-28
**Chemin local :** `E:\JustBosses\SourceAssets\Meshes\Medieval\`
**Licence :** tous CC0 (domaine public, usage libre y compris commercial)

---

## Assets téléchargés

### 1. Kenney Castle Kit
- **Dossier :** `Kenney_CastleKit/`
- **Source :** https://kenney.nl/assets/castle-kit
- **Contenu :** 228 meshes FBX, 88 textures PNG
- **Usage :** Murs, tours, créneaux, portes — kit modulaire château

### 2. Kenney Fantasy Town Kit 2.0
- **Dossier :** `Kenney_RetroMedieval/`
- **Source :** https://kenney.nl/assets/fantasy-town-kit
- **Contenu :** 501 meshes FBX, 174 textures PNG
- **Usage :** Bâtiments ville médiévale/fantasy, déco extérieure

### 3. KayKit Dungeon Remastered 1.0
- **Dossier :** `KayKit_MedievalBuilder/`
- **Source :** https://github.com/KayKit-Game-Assets/KayKit-Dungeon-Remastered-1.0
- **Contenu :** 411 meshes GLB (`.gltf.glb`), 2 textures atlas
- **Usage :** Décors intérieurs dungeon/caveau — bannières, colonnes, pièges, coffres
- **Note :** Format GLB → importable directement dans UE5 (Import > FBX/glTF)

### 4. KayKit Medieval Hexagon Pack 1.0
- **Dossier :** `KayKit_MedievalHexagon/`
- **Source :** https://github.com/KayKit-Game-Assets/KayKit-Medieval-Hexagon-Pack-1.0
- **Contenu :** 484 meshes GLB, 27 textures
- **Usage :** Tuiles hexagonales médiévales — sol arène stylisé possible

### 5. PolyHaven — Large Castle Door (4K)
- **Dossier :** `PolyHaven_CastleDoor/`
- **Source :** https://polyhaven.com/a/large_castle_door
- **Contenu :** 1 mesh FBX (396 Ko) + 5 textures 2K PNG :
  - `_diff_2k.png` — Albedo/Couleur
  - `_nor_dx_2k.png` — Normal Map DirectX (compatible UE5 direct)
  - `_rough_2k.png` — Roughness
  - `_ao_2k.png` — Ambient Occlusion
  - `_metal_2k.png` — Metallic
- **Usage :** Porte château réaliste PBR — décor arène ou boss gate

---

## Dossiers vides (rien téléchargé)

| Dossier | Raison |
|---------|--------|
| `CastleDungeonTileset/` | URLs OpenGameArt non vérifiées |
| `CastleDungeonTilesetExtended/` | URLs OpenGameArt non vérifiées |
| `DungeonModular2/` | URLs OpenGameArt non vérifiées |

---

## Import dans UE5

### FBX (Kenney)
`Content Browser → Import → sélectionner .fbx → Settings :`
- Combine Meshes : Non (garder chaque mesh séparé)
- Import Materials : Oui
- Import Textures : Oui
- Transform : Scale=1.0 (Kenney exporte déjà en cm UE5)

### GLB (KayKit)
`Content Browser → Import → sélectionner .glb`
- UE5 supporte le glTF/GLB natif depuis UE 5.0
- Textures atlas : importer séparément si non embarquées

### PolyHaven FBX + textures manuelles
1. Importer le .fbx (mesh uniquement)
2. Créer un Material dans UE5
3. Connecter les textures :
   - `_diff` → Base Color
   - `_nor_dx` → Normal (DirectX = pas besoin d'inverser le canal G)
   - `_rough` → Roughness
   - `_metal` → Metallic
   - `_ao` → Ambient Occlusion (multiplier sur Base Color ou entrée AO)

---

## Notes

- **Kenney Medieval RTS** (`Kenney_DungeonKit/`) : pack de sprites 2D/icônes RTS, **pas de meshes 3D** — inutile pour UE5 3D
- Les KayKit packs utilisent une texture atlas partagée (style low-poly coloré) — pas de PBR, mais très lisible en rendu stylisé
- Pour l'arène JustBosses, les KayKit Hexagon tiles pourraient servir de décor de sol stylisé (non-réaliste = cohérent avec le bullet-hell)
