# Level Design — Catacombes de Paris → Boss

**Vision :** Catacombes réelles de Paris (calcaire, ossuaires, verticalité multi-niveaux) + ennemis IA
dans les couleurs des patterns + mini-boss cachés + raccourcis verticaux. Boss au bout.
**Inspiration :** Demon's Souls 1-1 (lisibilité, raccourcis, landmark permanent) + Paris sous-terrain réel.
**Ordre de construction :** Boss d'abord → puis le chemin en remontant vers l'entrée.

---

## A. Vision globale — structure verticale

A demander mais garde```
([SURFACE] → Entrée (bâtiment abandonné / bouche d'égout)
                │
            -18m ↓
        ═══════════════════════════
        NIVEAU 1 — Galeries d'inspection
        (calcaire, 2m×2.5m, torches rares)
        → IA ennemis orange
        → Mini-boss 1 (salle des carriers)
        ═══════════════════════════
                │ puits -8m ↓
        ═══════════════════════════
        NIVEAU 2 — Ossuaires
        (murs de crânes/os, galerie large, ~4m×3m)
        → IA ennemis violet (snap)
        → Mini-boss 2 (galerie des sculptures)
        ═══════════════════════════
                │ escalier en spirale -5m ↓
        ═══════════════════════════
        NIVEAU 3 — Le Puits (salle boss)
        Hauteur ~15m, circulaire, Ø30m
        Murs = ossuaire du sol au plafond
        → BOSS PRINCIPAL
        ═══════════════════════════)

RACCOURCIS VERTICAUX :
  R1 : Niveau 2 → Niveau 1 (mur effondré, ouvert depuis N2)
  R2 : Niveau 3 → Entrée directe (trappe dans le plancher de la salle boss, ouverte après 1ère mort)
  R3 : Caché — galerie secrète horizontale qui relie N1 ↔ N3 (pour les explorateurs)
```

---

## B. Entrée (surface → -18m)

**Ambiance :** Bâtiment parisien abandonné, nuit. Escalier en colimaçon descend dans le noir.

### Layout BSP

```
┌──────────────────────┐
│ BÂTIMENT (surface)   │
│  Porte en bois cassée│
│  Sol : parquet abîmé │
│  → Trappe au sol     │
└──────────┬───────────┘
           │ Escalier colimaçon (40cm de large par marche, ~40 marches)
           │ Rampe en fer rouillée
           │ Éclairage : rien, juste la lumière du joueur
           ↓
    [Galerie d'accès — 30m horizontal]
    Voûte en brique, ~2m×2m
    Murs : traces de charbon (anciens mineurs)
    ↓
    [Entrée NIVEAU 1]
```

**Points de design :**
- L'escalier colimaçon = 40 marches → longue descente = tension montante
- Aucune lumière dans la galerie d'accès → le joueur est seul dans le noir
- Au bout : une faible lueur orange (torche de l'IA ennemi N1) → promesse de danger

---

## C. Niveau 1 — Galeries d'inspection (-18m)

**Dimensions :** ~80m × 60m (irrégulier), plafond 2.5m
**Ambiance :** Pierre calcaire beige-gris, humide, repères des anciens carriers gravés dans la roche,
quelques graffiti modernes de cataphiles, eau qui ruisselle.

### Layout

```
[Entrée galerie]
        │
   COULOIR A (3m×2.5m, 30m long)
        │         └───────→ Alcôve (trésor/item)
        │
   CARREFOUR (6m×6m)
   ┌────┴────────────────────┐
   │                         │
COULOIR B                COULOIR C (vers mini-boss)
(bouchée - impasse)      4m×2.5m, 25m long
                              │
                    ┌─────────┴────────┐
                    │  SALLE CARRIERS  │
                    │  (12m×10m×4m)   │
                    │  Mini-boss 1     │
                    │  Puits -8m ici   │
                    └──────────────────┘
                         │ [RACCOURCI R1 visible depuis ici]
                         │ → mur légèrement éboulé → N2
```

### Ennemis IA Niveau 1 — couleur ORANGE

> Stationnaires ou à déplacement limité (couloirs trop étroits pour pathfinding complexe).
> Tirent des versions simplifiées des patterns P1xxx.

**BP_JB_Enemy_Basic** (nouveau blueprint, dérivé de DummyBoss) :

| Propriété       | Valeur                          |
|-----------------|---------------------------------|
| HP              | 80                              |
| AttackPool      | ["P1001_mini", "P1004_mini"]    |
| PatternDuration | 4.0s                            |
| PauseBetween    | 1.5s                            |
| AggroRadius     | 800cm (déclenche à 8m)          |
| ProjColor       | Orange (1.0, 0.4, 0.05)         |
| TriggerType     | EnterRadius (pas de tracking)   |

**P1001_mini** = P1001 réduit (2×4 au lieu de 4×8), Speed=600 (plus lent qu'un vrai pattern)
**P1004_mini** = vague sinusoïdale 8 proj au lieu de 16

> **Placement :** 2-3 ennemis dans Couloir A, 1 ennemi gardien dans Salle Carriers.

### Mini-boss 1 — "Le Carrier"

> 1er boss mineur. Protège le puits d'accès au Niveau 2.

| Propriété       | Valeur                          |
|-----------------|---------------------------------|
| HP              | 350                             |
| AttackPool      | ["P1001", "P1002", "P2004"]     |
| Phase 2 (50%HP) | Ajoute P2001 (snap)             |
| ProjColor       | Orange intense, flash rouge à P2|
| Drop            | ArmorShard ×2 sur mort          |
| Tell            | Flash rouge-orange, son distinct|

**Positionnement :** Centre de la Salle Carriers, sphère ×5 (même base que DummyBoss).
La salle 12×10m = assez grande pour les patterns P1xxx mais serrée pour P2004 (éventail).

---

## D. Niveau 2 — Ossuaires (-26m)

**Dimensions :** ~60m × 50m, plafond 3-3.5m (galeries) / 6m (salles)
**Ambiance :** Murs entièrement tapissés de crânes et d'os arrangés en motifs géométriques.
Style ossuaire réel de Paris (Denfert-Rochereau). Quelques lampions violet/bleu des anciens rituels.

### Layout

```
[Bas du puits N1 → N2]
        │
   GALERIE DES OS (8m×3m, 40m long)
   Murs : crânes et tibias arrangés
        │                    │
   Embranchement        Passage caché (R3 secret)
        │
   ┌────┴──────────────────────────────┐
   │  SALLE DES SCULPTURES             │
   │  (20m×15m×6m)                    │
   │  Colonnes sculptées dans le roc   │
   │  Mini-boss 2                      │
   │                                   │
   │  [RACCOURCI R1] ← mur cassé → N1  │
   └─────────────────┬─────────────────┘
                     │
              ESCALIER SPIRALE
              Fer forgé, -5m
                     │
              [Antichambre Boss]
```

### Ennemis IA Niveau 2 — couleur VIOLET

> Plus agressifs qu'au N1. Snap activé. Les voir tirer violet = signal danger immédiat.

**BP_JB_Enemy_Snap** :

| Propriété   | Valeur                          |
|-------------|---------------------------------|
| HP          | 120                             |
| AttackPool  | ["P2001", "P2004"]              |
| ProjColor   | Violet (0.67, 0.2, 1.0)         |
| AggroRadius | 1000cm                          |

> **Placement :** 2 ennemis dans la Galerie des Os, 1 ennemi gardien de l'escalier.

### Mini-boss 2 — "Le Sculpteur"

> Gardien de la Salle des Sculptures. Plus difficile que le Carrier.

| Propriété       | Valeur                               |
|-----------------|--------------------------------------|
| HP              | 600                                  |
| AttackPool      | ["P2001", "P2004", "P2006", "P2007"] |
| Phase 2 (50%HP) | Ajoute P3001 (Ciseaux)               |
| Phase 3 (25%HP) | Ajoute P3006 (Étoile Convergente)    |
| ProjColor       | Violet (P2xxx) / Rouge intense (P3xx)|
| Drop            | ArmorShard ×3 + SpecialAmmo +2       |

**Positionnement :** La salle 20×15m permet les patterns P2006 (spirale) et P2007 (moulin).
**Verticalité unique :** La salle a un balcon à +3m (colonnes sculptées) — le mini-boss peut
monter dessus à la Phase 3, changeant l'angle des patterns (P3006 tire depuis le haut).

---

## E. Niveau 3 — Le Puits (salle boss, -31m)

**Dimensions :** Circulaire, Ø3000cm (30m), hauteur 1500cm (15m)
**Ambiance :** La plus grande salle des catacombes. Murs du sol au plafond = crânes et os.
Éclairage : 0. Seulement les projectiles du boss et quelques lampions bleus au sol.

### Antichambre (transition)

```
[Bas de l'escalier spirale]
  │
  Couloir final (4m×3m, 20m long)
  Murs : inscriptions latines + date 1786 (vrai ossuaire)
  Son : silence absolu sauf gouttes d'eau
  │
  [ARCHE EN OS] ← "fog gate" visuel, franchir = engagement combat
  │
  [LE PUITS — BOSS ARENA]
```

### Arène boss — Le Puits

```
         Ø 30m
    ┌─────────────┐
   /               \
  │  [BOSS CENTER]  │
  │       ×         │  ← socle surélevé 80cm, Ø 4m
  │                 │
  │  3 piliers os   │  ← couverts par les patterns, pas de cover réel
  │   (Ø 80cm)      │
  │                 │
  │  [JOUEUR SPAWN] │  ← bord de l'arène, à 10m du boss
   \               /
    └─────────────┘
         │
    Trappe au sol (RACCOURCI R2, s'ouvre après 1ère mort → accès direct depuis entrée)
```

### Éclairage

- **Pas de lumière fixe** → ambiance zéro
- Seul éclairage : bloom des projectiles boss (orange, violet, rouge)
- Effets : 3 bougies au sol qui s'éteignent à chaque phase boss (transition de phase = noir total 0.5s)
- Post Process : Exposure Min très bas → joueur doit "voir" avec les projectiles

---

## F. Raccourcis — détail mécanique

| ID  | De         | Vers       | Déclencheur                               | Sens unique ? |
|-----|------------|------------|-------------------------------------------|---------------|
| R1  | N2         | N1         | Activer levier dans Salle Sculpteur       | N2→N1 seulement |
| R2  | Boss Arena | Entrée     | S'ouvre automatiquement après 1ère mort   | Boss→Entrée  |
| R3  | N1 (caché) | N3 (caché) | Pousser un crâne spécifique dans un mur   | Bidirectionnel |

**R3 (caché) :** Un passage secret (80cm×180cm) dissimulé derrière un mur de crânes.
Marqueur subtil : un crâne légèrement différent (doré, taille anormale). Si le joueur le touche → le mur s'ouvre.
Ce raccourci bypass les deux mini-boss → récompense l'exploration.

---

## G. Verticalité — détail technique UE5

| Transition              | Hauteur    | Type BSP                          |
|-------------------------|------------|-----------------------------------|
| Surface → N1            | -1800cm    | Escalier colimaçon BSP (40 steps × 45cm) |
| N1 → N2 (Puits)         | -800cm     | Cylindre BSP Ø 150cm + iron rungs (SM) |
| N2 → N3 (Escalier)      | -500cm     | Escalier spirale BSP (20 steps en arc) |
| Balcon mini-boss 2      | +300cm     | Plateforme BSP + rampe d'accès    |
| Trappe R2               | +3100cm    | Lift Blueprint (montée verticale rapide) |

**Astuce UE5 BSP pour l'escalier colimaçon :**
- Placer des boîtes BSP en rotation incrémentale (5° par marche)
- Snap à 5° dans le viewport (Grid → Angle snap = 5°)
- Ou utiliser un Static Mesh d'escalier Quixel (search: "Stone Spiral Staircase")

---

## H. Assets Quixel Bridge — liste complète par zone

### Catacombes (N1 + N2)

| Search term (Fab/Quixel)         | Usage                                |
|----------------------------------|--------------------------------------|
| `Limestone Quarry Wall`          | Murs N1 — calcaire parisien          |
| `Wet Stone Cave Floor`           | Sol humide                           |
| `Rock Cave Ceiling`              | Plafond irrégulier N1                |
| `Skull Pile Human`               | Décoration murs N2                   |
| `Human Bone Long`                | Tibias/fémurs pour les murs N2       |
| `Medieval Torch Sconce`          | Torches murales N1                   |
| `Candle Wax Melted`              | Lampions sol N3                      |
| `Iron Gate Rusty`                | Portes de couloir + raccourcis        |
| `Stone Pillar Ancient`           | Colonnes salle sculpteur (N2)        |
| `Water Puddle Cave`              | Flaques au sol N1                    |
| `Mushroom Cave`                  | Détails atmosphériques               |
| `Stone Carved Relief`            | Sculptures dans les murs N2          |
| `Latin Inscription Stone`        | Inscriptions antichambre boss        |
| `Metal Ladder Rusty`             | Échelle de descente (puits N1→N2)    |

### Surface + entrée

| Search term                      | Usage                                |
|----------------------------------|--------------------------------------|
| `Paris Haussmann Facade`         | Bâtiment surface (si visible)        |
| `Old Wood Door Broken`           | Porte d'entrée bâtiment              |
| `Parquet Floor Worn`             | Sol bâtiment surface                 |
| `Iron Spiral Staircase`          | Escalier colimaçon                   |
| `Brick Arch Industrial`          | Voûte galerie d'accès                |

---

## I. AI Enemy Blueprint — structure technique

> À créer après validation du Boss flow. Même base que BP_JB_DummyBoss.

**BP_JB_Enemy_Basic** (Actor, extends BP_JB_DummyBoss via copie) :

```
Variables supplémentaires vs DummyBoss :
  AggroRadius     (Float, 800) ← rayon de détection
  bIsAggro        (Boolean)    ← en combat ou inactif
  MaxHP           (Float, 80)  ← mini HP
  CurrentHP       (Float)
  XPValue         (Float, 10)  ← futur système score

Event Tick (si bIsAggro=false) :
  [Sphere Overlap] AggroRadius → détecter BP_JB_Character
  Si trouvé → Set bIsAggro=true → démarrer AttackLoop

On Death (HP <= 0) :
  Stop AttackLoop
  [Play Sound] SFX_EnemyDeath
  [Spawn] BP_JB_ArmorShard (si Random < 0.4)
  [Destroy Actor] après 1.5s (death anim)
```

**Différences visuelles par type :**

| Type ennemi     | Couleur mesh      | Couleur proj       | HP  | Patterns           |
|-----------------|-------------------|--------------------|-----|--------------------|
| Basic (N1)      | Orange mat        | Orange (1,0.4,0.05)| 80  | P1001_mini, P1004_mini |
| Snap (N2)       | Violet sombre     | Violet (0.67,0.2,1)| 120 | P2001, P2004       |
| Elite (gardien) | Rouge intense     | Rouge (1,0.1,0.1)  | 200 | P2004, P2007       |

---

## J. Ordre de construction (boss d'abord)

```
1. Boss Arena (Le Puits)          ← COMMENCER ICI — BSP + éclairage + Boss BP
2. Antichambre + escalier spirale ← test du flow d'accès
3. Niveau 2 — Ossuaires           ← mini-boss 2 + IA snap
4. Puits N1→N2 + niveau 1        ← mini-boss 1 + IA basic
5. Galerie d'accès + entrée       ← surface
6. Raccourcis R1, R2, R3         ← polish + test flow complet
7. Assets Quixel + lighting      ← visuels finaux
```

> **Pourquoi boss d'abord ?** Le gameplay core est la rencontre avec le boss.
> Tout le reste est du chemin pour y arriver. Si le boss est fun, le niveau est fun.
> Si le boss est nul, peu importe le niveau.
