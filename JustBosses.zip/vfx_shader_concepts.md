# VFX & Shader Concepts — Just Bosses

---

## A. M_Projectile_v2 — Orange-Noir dégradé + frange électrique

> Style Kosmos amélioré : dégradé orange→noir avec crépitement électrique en bordure.

### A1 — Material Graph

```
Domain       : Surface
Blend Mode   : Additive
Shading Model: Unlit

─── Dégradé radial orange → noir ───

[TexCoord UV]
  → [Subtract 0.5]         ← centre UV à (0.5, 0.5)
  → [Length]               ← distance depuis le centre (0 au centre, 0.5 au bord)
  → dist

[Power] (dist, 1.5)        ← courbe : centre plat, bord abrupt
  → [OneMinus]             ← inversion : centre=1 (orange), bord=0 (noir)
  → radialMask

[Vector Param "Color"] × radialMask × [Scalar Param "Intensity"]
  → partialEmissive

─── Frange électrique ───

[Panner] Speed=(0.8, 1.2)  ← animation UV
  [Noise Texture] (Perlin, 0.5 tiling)
    → [Multiply] radialMask_inverted   ← seulement au bord
    → [Power] 4.0                      ← crépitement = trait fin
    → electricMask

[Vector Param "ElectricColor"] (1.0, 0.95, 0.6)  ← blanc-jaune électrique
  × electricMask × [Scalar Param "ElectricIntensity"] (15.0)
  → electricEmissive

─── Combinaison finale ───

partialEmissive + electricEmissive
  → [Emissive Color]
```

### A2 — Variables

| Param              | Type         | Défaut            | Rôle                        |
|--------------------|--------------|-------------------|-----------------------------|
| `Color`            | Vector Param | (1.0, 0.3, 0.0)   | Orange Kosmos               |
| `Intensity`        | Scalar       | 8.0               | Bloom principal             |
| `ElectricColor`    | Vector Param | (1.0, 0.95, 0.6)  | Blanc-jaune arc électrique  |
| `ElectricIntensity`| Scalar       | 15.0              | Intensité de l'arc          |
| `ElectricSpeed`    | Scalar       | 1.0               | Vitesse animation électrique|

> Résultat : boule orange intense au centre, noir profond aux 2/3, frange électrique crépitante au bord.

---

## B. NS_ElectricBolt — Niagara arc électrique autour des projectiles

> Niagara GPU → léger même avec 50 projectiles simultanés.

`Content/Effects/` → Niagara System
Nommer : `NS_ElectricBolt`

### B1 — Config Emitter

```
Emitter Type : GPU Sprites

Spawn Rate : 20/s (par projectile parent)
Lifetime   : 0.05s

─── Position ───
[Initialize Particle]
  Sphere Location : Radius = 25cm (surface du proj)
  → Random point en surface

─── Vélocité ───
[Point Attraction] Force=1500 → attirés vers centre
[Curl Noise] Magnitude=200 → mouvement chaotique

─── Visuel ───
Sprite Size  : Random entre 1 et 4cm
Color        : Lerp((1,0.9,0.3), (0.8,0.4,0.0), AgeRatio)  ← jaune → orange
Sprite Material : M_ElectricArc (simple additive glow)
```

### B2 — Attacher à BP_JB_Projectile

Dans `BP_JB_Projectile` BeginPlay :
```
[Spawn System Attached]
  Template : NS_ElectricBolt
  Attachment : StaticMesh (le projectile)
  Location Type : Snap to Target
```

---

## C. M_CharacterHit — Flash électrique sur dégât joueur

> Quand le joueur prend un projectile : le personnage flashe en blanc-bleu avec distorsion électrique 0.2s.

### C1 — Material (overlay sur le character mesh)

```
Domain       : Surface
Blend Mode   : Translucent
Shading Model: Unlit

[Sine] (Time × [Param "FlashSpeed" 30.0])
  → [Saturate]
  → flashWave

[Lerp] A=BaseColor, B=[Param "HitColor" (0.6, 0.8, 1.0)], Alpha=(flashWave × Param "HitIntensity")
  → [Emissive Color]

[Noise] (UV, Scale=50, Speed=(2,3))
  → [Step] 0.7               ← crépitement sporadique
  → [Multiply] flashWave
  → [Saturate]
  → Opacity
```

### C2 — Déclencher depuis BP_JB_Character

Dans `TakeDamage` :
```
[Set Scalar Parameter "HitIntensity" = 3.0]  ← on CharacterMesh material
[Set Timer] 0.2s → reset HitIntensity = 0.0
[Camera Shake] (BP_CS_Hit — small, 0.1s)
```

---

## D. MetaHuman — Intégration joueur

> Remplacer le mannequin par défaut de BP_JB_Character par un MetaHuman personnalisé.

### D1 — Créer le MetaHuman

1. `Fab.com` → télécharger **MetaHuman Creator** (gratuit)
2. Ou directement via `Quixel Bridge → MetaHuman Creator`
3. Créer le perso : masculin/féminin, style urbain/sombre cohérent avec l'ambiance
4. Exporter vers le projet UE5 (bouton "Export to UE5")

### D2 — Brancher au BP_JB_Character

MetaHuman génère automatiquement :
- `BP_MH_[NomPerso]` → Blueprint avec Skeletal Mesh + LODs
- `SK_[NomPerso]_Body` + `SK_[NomPerso]_Face`

Dans BP_JB_Character :
```
Skeletal Mesh Component
  → Mesh = SK_[NomPerso]_Body
  → Material Override [3] = M_CharacterHit (overlay pour le flash)
```

Anim Blueprint : utiliser l'ABP généré par MetaHuman comme base, adapter les transitions dash/idle/run.

### D3 — Adaptation du dash visuel

E_DashVisualMode (Enum existant) reste compatible :
- **SemiTransparent** : Set Material Opacity = 0.3 sur le MetaHuman body mesh
- **OutlineGlow** : Post Process Material outline sur le character
- **FullInvisible** : Set Visibility = Hidden

---

## E. Résumé assets à créer

```
Content/
├── Effects/
│   ├── NS_ElectricBolt              ← Niagara arc électrique (projectiles boss)
│   └── NS_PlayerHit                 ← Niagara explosion électrique (hit reçu)
├── Materials/
│   ├── M_Projectile_v2              ← Orange-noir + frange électrique
│   ├── M_ElectricArc                ← Sprite simple pour Niagara (Additive)
│   └── M_CharacterHit               ← Flash overlay sur le joueur
└── Characters/
    └── MetaHuman/
        └── MH_JB_Player             ← Le joueur MetaHuman
```
