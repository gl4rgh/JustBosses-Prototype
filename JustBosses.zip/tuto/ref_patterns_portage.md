# Step 06 — Portage des patterns Kosmos → UE5 Blueprint

**Objectif :** Implémenter le moteur de projectiles + les premiers patterns (P1001→P1005). Même visuel que Kosmos (sphères Emissive Additive + snap). Framework extensible aux 35 attaques.
**Prérequis :** Step 05 ✓ — Menu admin fonctionnel, JB_FireAttack placeholder
**Blueprint only — aucun C++**

---

## A. BP_JB_Projectile — base commune à TOUS les projectiles

`Content/Blueprints/Projectiles/` → Blueprint Class → **Actor**
Nommer : `BP_JB_Projectile`

### A1 — Composants

| Composant               | Rôle                                      |
|-------------------------|-------------------------------------------|
| `SphereCollision` (root)| Hitbox — radius = paramétrique            |
| `StaticMesh`            | Sphère Engine/BasicShapes/Sphere          |
| `ProjectileMovement`    | Déplacement linéaire natif UE5            |

**SphereCollision :**
- Collision Preset : Custom → tout = Ignore SAUF Pawn = Overlap

**StaticMesh :**
- Mesh : Engine/BasicShapes/Sphere
- Collision : No Collision (la SphereCollision gère)
- Taille dynamique via variable Size

**ProjectileMovement :**
- Gravity Scale : 0
- Initial Speed : variable (set en BeginPlay)
- Projectile Lifetime : variable

---

### A2 — Variables

| Nom              | Type          | Défaut        | Instance | Rôle                                   |
|------------------|---------------|---------------|----------|----------------------------------------|
| `Speed`          | Float         | 700.0         | oui      | cm/s                                   |
| `Size`           | Float         | 30.0          | oui      | Rayon visuel (cm)                      |
| `Damage`         | Float         | 20.0          | oui      | Dégâts sur impact joueur               |
| `MaxDist`        | Float         | 3500.0        | oui      | Distance de vie (cm)                   |
| `ProjColor`      | LinearColor   | (1,0.4,0.05,1)| oui      | Orange par défaut (Emissive HDR)       |
| `ColorIntensity` | Float         | 8.0           | oui      | Multiplicateur bloom                   |
| `bSnap`          | Boolean       | false         | oui      | Active le snap de direction            |
| `SnapDist`       | Float         | 1000.0        | oui      | Distance déclenchement snap (cm)       |
| `SnapAngle`      | Float         | 45.0          | oui      | Angle de rotation du snap (degrés)     |
| `SnapSpeedMult`  | Float         | 1.5           | oui      | Multiplicateur de vitesse après snap   |
| `SpawnLocation`  | Vector        | (0,0,0)       | non      | Mémorisé au BeginPlay                  |
| `bSnapped`       | Boolean       | false         | non      | Snap déjà effectué                     |
| `MatInstance`    | MaterialInstanceDynamic | — | non    | Instance material pour changer couleur |

---

### A3 — Event Graph

**BeginPlay :**
```
[Event BeginPlay]
  │
  ├─→ Mémoriser spawn location :
  │     [Get Actor Location] → Set SpawnLocation
  │
  ├─→ Configurer hitbox :
  │     [Get SphereCollision] → [Set Sphere Radius] = Size
  │
  ├─→ Configurer mesh :
  │     [Get StaticMesh] → [Set World Scale 3D] = (Size/50, Size/50, Size/50)
  │
  ├─→ Créer material dynamique :
  │     [Create Dynamic Material Instance]
  │       ├─ Parent : M_Projectile (voir section B)
  │       └─→ Set MatInstance
  │             ├─→ [Set Vector Parameter Value] "Color" = ProjColor × ColorIntensity
  │             └─→ [Set Scalar Parameter Value] "Intensity" = ColorIntensity
  │
  └─→ Configurer ProjectileMovement :
        [Get ProjectileMovement]
          ├─ Initial Speed = Speed
          ├─ Max Speed     = Speed
          └─ Projectile Lifetime = MaxDist / Speed
```

**Event Tick — Snap :**
```
[Event Tick]
  │
  └─→ [Branch] bSnap AND NOT bSnapped ?
        TRUE →
          [Get Actor Location] → CurrentPos
          [VSize] (CurrentPos - SpawnLocation) → DistFromSpawn
          │
          [Branch] DistFromSpawn >= SnapDist ?
            TRUE →
              Set bSnapped = true
              │
              [Get ProjectileMovement → Velocity] → CurrentVelocity
              [Rotator from Velocity] → CurrentDir (Rotator)
              │
              [Make Rotator] (Pitch=0, Yaw=CurrentDir.Yaw + SnapAngle, Roll=0) → NewRot
              [Get Forward Vector from Rotator] → NewDir
              │
              [Set Velocity in Local Space] (ProjectileMovement)
                └─ Velocity = NewDir × (Speed × SnapSpeedMult)
              │
              Changer couleur → violet (snap = piège) :
                [Set Vector Parameter] "Color" = (0.67, 0.2, 1.0) × 10.0
```

**OnComponentBeginOverlap (SphereCollision) :**
```
[OnComponentBeginOverlap]
  Other Actor →
    [Cast to BP_JB_Character]
      SUCCESS →
        [Branch] BP_JB_Character.bIsInvincible ?
          FALSE → [Call TakeDamage on Character] Damage
          TRUE  → (ignore — iframes)
        [Destroy Actor]
```

---

## B. M_Projectile — material partagé

`Content/Materials/` → Material
Nommer : `M_Projectile`

```
Material Domain  : Surface
Blend Mode       : Additive
Shading Model    : Unlit

[Vector Parameter "Color"] (R=1, G=0.4, B=0.05)
  └─→ × [Scalar Parameter "Intensity"] (8.0)
          └─→ [Emissive Color]
```

> Additive = s'accumule sur les surfaces, crée automatiquement du bloom si le Post Process World a Bloom activé.
> Intensity > 1.0 = surexposé → bloom visible. C'est le même rendu que les boules Kosmos.

---

## C. Couleurs par type (Config équivalent Kosmos)

Ajouter une **Structure** `S_ProjColor` dans Content/Blueprints/ :
| Field         | Type         |
|---------------|--------------|
| Color         | LinearColor  |
| Intensity     | Float        |

Créer une variable dans BP_JB_DummyBoss (ou dans un Blueprint de config) :
`ProjectileColors` (Array of S_ProjColor) :

| Index | Couleur (R,G,B)    | Intensity | Usage               |
|-------|--------------------|-----------|---------------------|
| 0     | (1.0, 0.4, 0.05)   | 8.0       | Orange — standard   |
| 1     | (1.0, 0.1, 0.1)    | 8.0       | Rouge — rapide      |
| 2     | (0.67, 0.2, 1.0)   | 10.0      | Violet — piège/snap |
| 3     | (0.1, 0.5, 1.0)    | 8.0       | Bleu — missile      |

---

## D. JB_SpawnProjectile — helper de spawn

Fonction dans BP_JB_DummyBoss :
`JB_SpawnProjectile(SpawnPos Vector, Direction Vector, Config S_ProjConfig)`

Où `S_ProjConfig` est une structure avec tous les paramètres de BP_JB_Projectile.

```
[Spawn Actor BP_JB_Projectile]
  Location  : SpawnPos
  Rotation  : [Rotation from X Vector] Direction
  → Set Speed, Size, Damage, MaxDist, ProjColor, bSnap, SnapDist, SnapAngle, SnapSpeedMult
    sur l'instance spawné
```

---

## E. Portage des 5 patterns D1

### E1 — Fonction JB_FireAttack (mise à jour)

Dans BP_JB_DummyBoss, remplacer le placeholder par un Switch on String :

```
[Function JB_FireAttack] (AttackID, BossPos)
  │
  └─→ [Switch on String] AttackID
        "P1001" → JB_Pattern_RectVertical(BossPos)
        "P1002" → JB_Pattern_RectHorizontal(BossPos)
        "P1003" → JB_Pattern_RingsChain(BossPos)
        "P1004" → JB_Pattern_Wave(BossPos)
        "P1005" → JB_Pattern_Cross(BossPos)
        Default → [Print String] "ID inconnu : " + AttackID
```

---

### E2 — P1001 : Rect Vertical (4×8 grid, orange)

> Config Kosmos : cols=4, rows=8, spacing_x=120cm, spacing_y=100cm, wave=1 (orange)

**Fonction `JB_Pattern_RectVertical(BossPos Vector)` :**

```
Direction = Normalize(LiveTargetLocation - BossPos)   ← direction vers le joueur
PerpRight = Cross(Direction, (0,0,1))                 ← axe perpendiculaire (horizontal)

For ColIdx = 0 to 3 :
  For RowIdx = 0 to 7 :
    OffsetH = (ColIdx - 1.5) × 120          ← centre la grille : -180, -60, +60, +180
    OffsetV = (RowIdx - 3.5) × 100          ← centre vertical  : -350..+350
    SpawnPos = BossPos
               + (PerpRight × OffsetH)
               + (0, 0, OffsetV)
    JB_SpawnProjectile(SpawnPos, Direction, Config_P1001)
```

> **Config_P1001** : Speed=800, Size=30, Damage=20, MaxDist=3500, Color=Orange, bSnap=false

> **Cross product** pour l'axe horizontal : si Direction = (1,0,0) → PerpRight = (0,1,0) ✓

---

### E3 — P1002 : Rect Horizontal (8×3 grid, rouge)

> cols=8, rows=3, wave=2 (rouge)

```
Direction = Normalize(LiveTargetLocation - BossPos)
PerpRight = Cross(Direction, (0,0,1))

For ColIdx = 0 to 7 :
  For RowIdx = 0 to 2 :
    OffsetH = (ColIdx - 3.5) × 120
    OffsetV = (RowIdx - 1.0) × 100
    SpawnPos = BossPos + (PerpRight × OffsetH) + (0,0,OffsetV)
    JB_SpawnProjectile(SpawnPos, Direction, Config_P1002)
```

> **Config_P1002** : Speed=800, Size=30, Color=Rouge, rest idem

---

### E4 — P1003 : Rings Chain (10 anneaux, violet)

> ring_radius=300cm, count=10, delay_between=0.4s, wave=3 (violet)

```
[Function JB_Pattern_RingsChain(BossPos)]

  For RingIdx = 0 to 9 :
    [Set Timer by Event] Time = RingIdx × 0.4
      Event → SpawnRing(BossPos, RingIdx)

[Function SpawnRing(BossPos, RingIdx)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  PerpRight = Cross(Direction, (0,0,1))

  For i = 0 to 15 :   ← 16 proj par anneau
    Angle = i × (360 / 16)   ← répartis en cercle
    OffsetH = Cos(Angle) × 300   ← radius 300cm
    OffsetV = Sin(Angle) × 300
    SpawnPos = BossPos + (PerpRight × OffsetH) + (0,0,OffsetV)
    JB_SpawnProjectile(SpawnPos, Direction, Config_P1003)
```

> **Config_P1003** : Speed=700, Size=30, Color=Violet, MaxDist=3000

---

### E5 — P1004 : Wave sinusoïdale (16 proj, orange)

> count=16, frequency=2.0, amplitude=250cm, spacing=80cm

```
Direction = Normalize(LiveTargetLocation - BossPos)
PerpRight = Cross(Direction, (0,0,1))

For i = 0 to 15 :
  PosAlongLine = (i - 7.5) × 80           ← décalage horizontal
  SinOffset    = Sin(i × frequency × Pi / 16) × 250   ← onde sinusoïdale verticale
  SpawnPos = BossPos
             + (PerpRight × PosAlongLine)
             + (0, 0, SinOffset)
  JB_SpawnProjectile(SpawnPos, Direction, Config_P1004)
```

---

### E6 — P1005 : Croix (4 bras, orange)

> proj_per_arm=6, spacing=120cm, 4 directions cardinales

```
Directions = [
  Forward Vector of Boss,
  -Forward Vector,
  Right Vector of Boss,
  -Right Vector
]

For each ArmDir in Directions :
  For j = 1 to 6 :
    SpawnPos = BossPos + (ArmDir × j × 120)
    JB_SpawnProjectile(SpawnPos, ArmDir, Config_P1005)
```

> Les 4 bras spawns simultanément, chaque proj part dans la direction du bras.

---

## F. Tell visuel (avant chaque attaque)

Dans `JB_FireAttack`, AVANT de spawner :

```
[Set Scalar Parameter on BossMaterial] "EmissiveIntensity" → 15.0 (flash)
[Set Timer] Time=0.3s → reset EmissiveIntensity → 3.0 (normal)
[Play Sound at Location] (son selon type : P/M/U)
```

> Le boss flashe 0.3s dans la couleur de l'attaque imminente → tell lisible.

---

## G. Résumé fichiers créés / modifiés

```
Content/
├── Blueprints/
│   ├── Boss/
│   │   └── BP_JB_DummyBoss       ← modifié : JB_FireAttack → Switch + 5 patterns
│   └── Projectiles/
│       └── BP_JB_Projectile      ← nouveau : base projectile avec snap
├── Materials/
│   └── M_Projectile              ← modifié : ajout params Color + Intensity
└── (Structures)
    └── S_ProjConfig              ← struct config projectile
```

---

## H. Test

`Alt+P` → F1 spawn boss → Menu admin F9 → Boss → Pool = PATTERN → Lancer P1001 :
- ✅ Grille 4×8 de boules oranges se déplace vers le joueur
- ✅ Boules détruites après MaxDist ou au contact joueur
- ✅ Hit joueur → dégâts (step 08 : HP system)
- ✅ Iframes dash → boules traversent le joueur sans dégâts

---

## I. Ordre de portage des patterns restants

Après validation P1001→P1005, portage progressif :

| Priorité | Patterns         | Difficulté BP                          |
|----------|------------------|----------------------------------------|
| 1        | P1001→P1005      | ✓ Step courant                         |
| 2        | P2001→P2003      | Moyen — snap, rotation                 |
| 3        | M1001, M1002     | Missiles = tracking → besoin LiveTarget|
| 4        | P2004→P2009      | Éventail, spirale, moulin              |
| 5        | P3001→P3011      | D3 — logique complexe (Mandala, Flower)|
| 6        | M2xxx, M3xxx     | Missiles avancés (fake, déluge)        |
| 7        | U2xxx, U3xxx     | Uniques (boomerang, architecture)      |

**Prochaine étape → Step 08 : HP / Armure / Munitions + HUD** (`step08_hp_armor_ammo_hud.md`)
