# Nanite Vegetation — UE 5.7.3

> Référence : végétation optimisée pour les niveaux de Just Bosses.
> Utilisé en N1 (catacombes, racines) et surface (rues parisiennes, parcs).
> **Pas de SpeedTree nécessaire** — Electric Dreams + Quixel Bridge suffisent largement.

---

## Pourquoi Nanite pour la végétation ?

| Méthode classique | Nanite Vegetation |
|---|---|
| LOD manuels (LOD0/1/2/3) | Nanite gère la géo automatiquement |
| Imposter atlas pour LOD4 | Nanite fallback automatique |
| Triangle count limité | Plusieurs millions de triangles, coût quasi-fixe |
| Foliage Culling manuel | Nanite + Hardware RT culling intégré |

> **UE 5.4+** : Nanite supporte les meshes avec masque d'opacité (feuilles transparentes).
> **UE 5.7** : Nanite foliage + wind via World Position Offset = fully supported.

---

## PARTIE 1 — Activer Nanite sur un mesh végétation (attention sur pc midrange prevoir sans nanite)

### Sur un mesh existant (Quixel Bridge ou Electric Dreams)

1. Content Browser → trouver le Static Mesh (ex: `SM_Fern_01`)
2. Double-clic → ouvrir l'éditeur de mesh
3. **Details → Nanite → Enable Nanite Support** = **true**
4. Clic **Apply Changes** (en haut)
5. Recompile shader si demandé

> Quixel Bridge activera Nanite automatiquement sur les assets récents (2022+).
> Assets Electric Dreams : Nanite activé par défaut sur la plupart des meshes.

### Vérifier que Nanite est actif en jeu

```
Console → NaniteStats 1
→ Les meshes Nanite apparaissent en surbrillance dans la vue Nanite
Console → NaniteStats 0
```

Ou : **Viewport → View Mode → Nanite Visualization → Triangles**
→ Les meshes Nanite apparaissent en rouge/orange = correct.

---

## PARTIE 2 — Sources de végétation disponibles

### 2a. Quixel Bridge (PRIORITAIRE — gratuit)

Dans l'éditeur : `Add → Quixel Bridge`

| Search term | Usage JustBosses | Zone |
|---|---|---|
| `fern plant` | Fougères dans les crevasses N1 | N1 |
| `moss rock` | Rochers moussus (déjà dl pour textures) | N1 N2 |
| `ivy vine wall` | Lierre sur murs catacombes | N1 |
| `mushroom small` | Champignons bioluminescents N2 | N2 |
| `dead tree branch` | Racines sèches qui percent le calcaire | N1 |
| `grass dry` | Herbe sèche - surface Paris | Surface |
| `bush urban` | Arbustes trottoir Paris | Surface |
| `tree linden` | Tilleuls (arbres Paris typiques) | Surface |
| `plane tree` | Platanes (Paris = platanes) | Surface |

> **Astuce** : chercher `Paris tree` ou `urban tree europe` pour des assets adaptés au style haussmannien.

### 2b. Electric Dreams (migration)

Contient de la végétation Nanite de haute qualité — herbes, fougères, plantes basses.

Migration :
1. Ouvrir Electric Dreams dans un projet séparé UE 5.7
2. Content Browser → filtrer `Foliage` ou `Vegetation`
3. Sélectionner les assets voulus
4. Clic droit → **Asset Actions → Migrate**
5. Destination : `E:\JustBosses\JustBosses\Content\`

Assets à migrer en priorité :
```
Vegetation/Ferns/       ← fougères détaillées
Vegetation/Grasses/     ← herbes courtes + longues
Vegetation/Plants/      ← plantes basses
Rocks/Mossy/            ← rochers moussus (complète Quixel)
```

### 2c. Infinity Blade: Grass Lands

Assets UE4 — migration identique.
Vegetation dispo : herbes, lierre, buissons style fantasy.
Compatible Nanite après import (activer manuellement dans le mesh editor).

---

## PARTIE 3 — Foliage Painter (placement)

`Shift+F4` ou **Mode → Foliage** dans la toolbar (icône arbre)

### Setup

1. Ouvrir Foliage Mode
2. Glisser-déposer un Static Mesh Nanite dans la zone **"Drop Foliage Here"**
3. Régler les paramètres :

| Paramètre | Valeur recommandée | Notes |
|---|---|---|
| Brush Size | 500–2000 cm | Zone de peinture |
| Paint Density | 0.1–0.5 | Densité (0.5 = dense) |
| Scale Min/Max | 0.5 / 1.5 | Variation taille |
| Random Yaw | ON | Rotation aléatoire Y |
| Align to Normal | ON pour terrain, OFF murs | Alignement surface |
| Cull Distance | 3000–8000 cm | Distance disparition |

### Perf : régler le Cull Distance

Pour végétation décorative (pas de gameplay dessus) :
- N1 catacombes : `Max Cull Distance = 3000 cm` (déco proche uniquement)
- Surface Paris : `Max Cull Distance = 6000 cm` (arbres visibles plus loin)

### Perf : Instance Count

Foliage Painter groupe les instances → **1 draw call par mesh type**.
Nanite réduit encore plus le coût. Pas de limite stricte, mais rester raisonnable :
- Intérieur catacombe N1 : 200–500 instances par type max
- Surface Paris : 1000–3000 instances par type (arbres, herbes)

---

## PARTIE 4 — PCG (Procedural Content Generation) pour végétation automatique

> UE5 PCG = système procédural intégré depuis 5.2. Très bien supporté en 5.7.

### Setup PCG basique pour herbes de surface

1. `Place Actors → PCG Volume` → poser sur la zone surface
2. Ouvrir le **PCG Graph** (double-clic sur l'acteur)
3. Construire le graph :

```
[Surface Sampler]
    → Point Count : 500
    → Density Falloff : curve (moins dense vers les bords)
  ↓
[Filter by Tag] (optionnel — exclure route, trottoir)
  ↓
[StaticMesh Spawner]
    → Mesh : SM_Grass_01 (Nanite)
    → Scale Random : 0.5 → 1.2
    → Rotation Random Y : 0 → 360
```

4. **Generate** → les herbes apparaissent sur la surface

### Règle : PCG pour ambiance, Foliage Painter pour placement précis

- PCG = remplissage automatique grandes zones (herbes, graviers)
- Foliage Painter = placement précis (arbre devant une façade, fougère dans un coin)

---

## PARTIE 5 — Wind (animation végétation)

> UE 5.7 : Nanite supporte World Position Offset (WPO) → wind animation via WPO.

### Activer le wind sur un material

Dans le Material Editor du mesh végétation :

1. Créer un node `SimpleGrassWind`
   - `Wind Intensity` : 0.3–0.8
   - `Wind Weight` : texture de masque (blanc = bouge, noir = fixe — pour les tiges)
   - `Additional WPO` : connecter à `World Position Offset`
2. Dans **Material Details → Nanite** : `bEvaluateWPOEnabled = true`

> ⚠️ WPO en Nanite a un coût GPU. Limiter aux assets visibles proches.
> `r.Nanite.MaxPixelsPerEdge = 1.0` → désactive WPO en Nanite si nécessaire pour perf.

### Réglage perf WPO Nanite

Dans `DefaultEngine.ini` :

```ini
[SystemSettings]
; WPO Nanite : limiter la distance d'évaluation
r.Nanite.WPOCullAngle=90.0
r.Nanite.MaxWPOExtent=200.0
```

---

## PARTIE 6 — Bioluminescence N2 (catacombes niveau 2)

Idée boss : champignons et mousses qui brillent dans le noir de N2.

### Material M_JB_BioMoss

```
Base Color : vert-bleu sombre (0.02, 0.1, 0.05)
Emissive Color : vert électrique HDR (0.0, 4.0, 1.0)
Emissive Strength : Scalar param "Pulse" → animé en BP
Roughness : 0.9 (mat, organique)
```

### Blueprint BP_JB_BioFoliage (optionnel)

Pour une pulsation vivante :

```
Event BeginPlay :
  → Timer Loop 0.5–2.0s (random)
  → Set Material Scalar "Pulse" : Random Float 0.5 → 1.5
  → Lerp smooth via Timeline 0.3s
```

> Alterne l'intensité émissive → impression de respiration organique.

---

## PARTIE 7 — Checklist par niveau

### N1 — Galeries d'inspection

- [ ] Fougères + lierre (Quixel Bridge) dans les recoins
- [ ] Racines sèches qui percent le plafond calcaire
- [ ] Mousse sur le sol humide (Quixel `mossy_cobblestone` déjà dl)
- [ ] Champignons de base (Quixel `mushroom small`)
- [ ] Cull Distance ≤ 3000 cm sur tout

### N2 — Ossuaires

- [ ] Champignons bioluminescents (M_JB_BioMoss)
- [ ] Racines massives qui descendent du plafond
- [ ] Mousse fluorescente sur les murs entre les crânes
- [ ] Densité faible — ambiance oppressante (pas une jungle)

### N3 — Le Puits (boss arena)

- [ ] Végétation absente ou quasi (pierre nue, boss dominant)
- [ ] 2–3 racines massives pour habiller les murs de l'arène
- [ ] Pas de distraction visuelle — le boss = focus

### Surface — Rues parisiennes

- [ ] Platanes / tilleuls sur les trottoirs (Quixel `plane tree` / `linden tree`)
- [ ] Herbe sèche dans les fissures asphalte
- [ ] Arbustes urbains aux pieds des façades
- [ ] PCG pour remplissage automatique des grandes zones
- [ ] Cull Distance ≤ 6000 cm pour arbres, ≤ 3000 pour herbes

---

## Notes perf globales

| Asset | Instances estimées | Draw calls | GPU estimé RTX 4080 |
|---|---|---|---|
| Fougères N1 | 150–300 | 1 (Nanite) | ~0.2ms |
| Champignons N2 | 50–100 | 1 | ~0.1ms |
| Platanes surface | 30–80 | 1 | ~0.3ms |
| Herbes surface (PCG) | 2000–5000 | 1 | ~0.5ms |
| **Total végétation** | | | **< 1.5ms** |

> Nanite rend la végétation pratiquement "gratuite" en draw calls.
> Le vrai coût = textures en mémoire VRAM (RTX 4080 16 Go → pas de problème).
