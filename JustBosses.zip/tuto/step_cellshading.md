# Cell Shading — Post Process Setup UE5

> Référence: à intégrer pendant step10 (lighting/texturing).
> Tout est built-in UE5 — zéro plugin, zéro achat.

---

## Résultat attendu

- Contours noirs sur personnages / boss / projectiles
- Couleurs en bandes (toon shading — 3 à 5 niveaux max)
- Compatible Lumen + Nanite + DLSS

---

## Vue d'ensemble

Deux composants indépendants :

| Composant | Technique | Lieu |
|-----------|-----------|------|
| **Outlines** | Custom Depth Stencil | Post Process Material |
| **Bandes couleur** | Color quantization | Post Process Material |
| **Shading toon** | Material function | Chaque material 3D |

---

## PARTIE 1 — Post Process Material (outline + bandes)

### Étape 1 : Activer Custom Depth Stencil

`Project Settings → Engine → Rendering → Custom Depth-Stencil Pass`
→ Mettre sur **Enabled with Stencil**

### Étape 2 : Créer le material PP

`Content/JustBosses/PostProcess/M_JB_CelShading`
- Material Domain : **Post Process**
- Blendable Location : **Before Tonemapping**

#### Nœuds — Outline (détection de contours)

```
SceneTexture(CustomDepth) ──┐
                             ├─ Sobel Edge Detection ──┐
SceneTexture(CustomDepth)   │   (voir nœuds ci-dessous) │
  décalé 1px en X/Y ───────┘                            │
                                                         ├─ Lerp(SceneColor, Black, EdgeMask)
SceneTexture(SceneColor) ────────────────────────────────┘
```

**Sobel simplifié en BP material :**
```
A = SceneTexture(CustomDepth) UV(0,0)
B = SceneTexture(CustomDepth) UV(TexelSize * float2(1,0))
C = SceneTexture(CustomDepth) UV(TexelSize * float2(0,1))

EdgeX = A - B
EdgeY = A - C
Edge  = saturate(abs(EdgeX) + abs(EdgeY))
Edge  = pow(Edge, 0.5)  ← ajuster dureté
```

**Paramètres exposés :**
- `EdgeThickness` (Scalar, default 1.0) — épaisseur outline
- `EdgeColor` (LinearColor, default black)

#### Nœuds — Color quantization (bandes toon)

```
SceneTexture(SceneColor)
  → Luminance (Dot avec float3(0.299, 0.587, 0.114))
  → Multiply par NbBandes (4.0)
  → Floor
  → Divide par NbBandes
  → Multiply SceneColor par résultat
```

**Paramètre exposé :**
- `ToonBands` (Scalar, default 4.0) — nombre de niveaux de couleur

#### Combiner les deux

```
ToonColor ──────────────────────────────────────────────┐
                                                         ├─ Lerp(ToonColor, EdgeColor, EdgeMask) → Emissive
EdgeMask (saturate) ────────────────────────────────────┘
```

### Étape 3 : Brancher sur le Post Process Volume

Dans la scène, sélectionner le **PostProcessVolume** :
- `Rendering Features → Post Process Materials → Array → +`
- Ajouter `M_JB_CelShading`
- `Infinite Extent` = true (couvre toute l'arène)

---

## PARTIE 2 — Activer les outlines par objet

Chaque mesh qui doit avoir un outline doit avoir **Custom Depth** activé.

**Par mesh (manuel) :**
- Sélectionner le mesh → Details → `Render CustomDepth Pass = true`
- `CustomDepth Stencil Value` = 1 (ou valeur unique par type)

**Via Blueprint (automatique) :**
```
BeginPlay → SetRenderCustomDepth(true) → SetCustomDepthStencilValue(1)
```

Appliquer à : Boss, Projectiles, Joueurs.
Ne pas appliquer à : Sol, Murs, Décors (trop de bruit).

---

## PARTIE 3 — Material Function toon (optionnel, par matériau)

Pour un look encore plus stylisé, remplacer le lighting standard par un shading en rampe.

`Content/JustBosses/PostProcess/MF_JB_ToonLighting`
- Type : **Material Function**

```
Inputs: BaseColor (V3), Normal (V3), LightDir (V3)

NdotL = saturate(dot(Normal, LightDir))
ToonNdotL = ceil(NdotL * NbBandes) / NbBandes   ← bandes dures
FinalColor = BaseColor * ToonNdotL

Output: FinalColor
```

Utiliser cette function dans chaque material boss/joueur à la place du lighting Lumen direct.

> Note : avec Lumen actif, cette approche est partielle. Le PP Material suffit généralement.

---

## PARTIE 4 — Blueprint parametres runtime

Créer `BP_JB_CelShadingController` (ou brancher sur AdminMenu) :

```
Function: SetCelShadingStyle(Style ENUM)
  → Style = Outline_Only / Toon_Only / Full / Off
  → GetPostProcessVolume → SetMaterialParameter(...)
      "ToonBands" → 1.0 / 4.0 / 4.0 / 0.0
      "EdgeThickness" → 0.0 / 0.0 / 1.0 / 0.0
```

Ajouter dans `WBP_JB_AdminMenu` panel Options.

---

## Valeurs recommandées par style

| Style | ToonBands | EdgeThickness | Look |
|-------|-----------|---------------|------|
| Returnal-like | 5.0 | 0.0 | Pas d'outline, légère quantization |
| Borderlands | 3.0 | 2.0 | Gros outlines, peu de bandes |
| Anime | 4.0 | 1.0 | Équilibré |
| Off | 0.0 | 0.0 | PBR standard |

---

## Checklist intégration

- [ ] Custom Depth Stencil activé dans Project Settings
- [ ] `M_JB_CelShading` créé (Domain = Post Process)
- [ ] PP Volume → Material Array → M_JB_CelShading
- [ ] Boss + Projectiles → Render Custom Depth = true
- [ ] Paramètres exposés testés dans PP Volume overrides
- [ ] Option ajoutée dans AdminMenu (optionnel)

---

## Perf

- Post Process Material : ~0.2ms GPU sur RTX 4080 (négligeable)
- Custom Depth Pass : actif par défaut si Stencil activé — coût fixe faible
- Ne pas activer Custom Depth sur les meshes statiques de décor (inutile + draw calls)
