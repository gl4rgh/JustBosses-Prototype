# Step 04 — Menu Admin (UMG)

**Objectif :** Menu admin F9 style Kosmos, adapté UE5. UMG Widget Blueprint, navigation clavier + souris. Sections : Boss / Joueur / Joueurs / Gameplay / Props.
**Prérequis :** Step 03 ✓ — BP_JB_Character fonctionnel, dash + tir joueur
**Blueprint only — aucun C++**

---

## Structure du menu (équivalent Kosmos)

```
WBP_JB_AdminMenu
│
├── 🎯 Boss
│   ├── Pool actif : [PATTERN | MISSILE | UNIQUE | ALL]
│   ├── Spawn Boss      → spawne BP_JB_DummyBoss au socle central + prévoir un pool de boss
│   ├── Despawn Boss
│   ├── Reset Boss
│   ├── Pause / Reprendre (toggle)
│   └── Forcer attaque
│       ├── Sélecteur PATTERN  (P1001 … P3011)
│       ├── Sélecteur MISSILE  (M1001 … M3004)
│       ├── Sélecteur UNIQUE   (U2001 … U3003)
│       └── [Lancer]
│
├── 👤 Joueur (Moi)
│   ├── God Mode (toggle)
│   ├── Heal (HP max)
│   ├── No-aréne du boss
│
├── 👥 Joueurs (multijoueur — placeholder pour l'instant)
│   ├── Liste joueurs en ligne
│   ├── TP vers joueur
│   ├── TP joueur sur moi
│   ├── Heal joueur
│   └── Kick joueur
│
├── 🎮 Gameplay (Just Bosses — exclusif)
│   ├── Dash visuel : [Semi-Transparent | Outline Glow | Invisible]
│   ├── Overlay iframes debug (toggle)
│   ├── Overlay hitbox debug (toggle)
│   └── Vitesse boss : slider (0.5× … 2.0×)
│
└── 📦 Props / Décors (city assets)
    ├── Catégorie (liste)
    ├── Prop (liste)
    ├── Spawn (3m devant admin)
    └── Supprimer le plus proche
```

---

## A. Créer les fichiers

### A1 — Enum DashVisualMode

`Content/Blueprints/Admin/` → clic droit → **Blueprint → Enumeration**
Nommer : `E_DashVisualMode`

Valeurs :
| Nom            | Description               |
|----------------|---------------------------|
| SemiTransparent| Opacité 0.3 (défaut)     |
| OutlineGlow    | Custom Depth stencil      |
| FullInvisible  | Mesh caché               |

### A2 — WBP_JB_AdminMenu

`Content/Blueprints/Admin/` → clic droit → **User Interface → Widget Blueprint**
Nommer : `WBP_JB_AdminMenu`

---

## B. Layout UMG (Designer)

Palette de composants à utiliser : `Canvas Panel` → `Horizontal Box` → `Vertical Box` → `Button` → `Text` → `ComboBoxString` → `Slider` → `CheckBox`

### Structure Canvas Panel :

```
[Canvas Panel]  (plein écran)
  └─ [Border] "MenuBackground"
       Brush Color : (R=0.03, G=0.03, B=0.07, A=0.92)  ← fond sombre semi-opaque
       Size : 900×600, Alignement : centre écran
       │
       └─ [Vertical Box]
             ├─ [Text] "JUST BOSSES — ADMIN"
             │    Font : Courier New, Size 14, Color Orange (R=1.0, G=0.4, B=0.0)
             │    Alignement : centre
             │
             ├─ [Horizontal Box]  ← corps du menu
             │    │
             │    ├─ [Vertical Box] "CatList" (largeur 160px)  ← boutons catégories
             │    │    ├─ [Button] "🎯 Boss"
             │    │    ├─ [Button] "👤 Joueur"
             │    │    ├─ [Button] "👥 Joueurs"
             │    │    ├─ [Button] "🎮 Gameplay"
             │    │    └─ [Button] "📦 Props"
             │    │
             │    └─ [Named Slot] "ContentArea"  ← contenu changeant selon catégorie
             │         (ou Border avec Switcher)
             │
             └─ [Text] "F9 pour fermer"
                  Font : Courier, Size 9, Color Gris
```

> **Named Slot** : permet de swapper le contenu dynamiquement. Alternative : `Widget Switcher` avec un panneau par catégorie.

**Recommandation : Widget Switcher** (plus simple en Blueprint) :
- Ajouter `Widget Switcher` dans ContentArea
- Index 0 = panneau Boss, 1 = Joueur, 2 = Joueurs, 3 = Gameplay, 4 = Props
- Les boutons de catégorie changent l'index actif du Widget Switcher

---

## C. Panneau Boss (Index 0)

```
[Vertical Box] "PanelBoss"
  ├─ [Text] "🎯 BOSS"
  ├─ [ComboBoxString] "CBPool"        ← Options : "PATTERN", "MISSILE", "UNIQUE", "ALL"
  ├─ [Button] "Spawn Boss"
  ├─ [Button] "Despawn Boss"
  ├─ [Button] "Reset Boss"
  ├─ [CheckBox] "Pause"              ← texte : "Pause / Reprendre"
  ├─ [Separator]
  ├─ [Text] "Forcer une attaque"
  ├─ [ComboBoxString] "CBAttackType" ← Options : "PATTERN", "MISSILE", "UNIQUE"
  ├─ [ComboBoxString] "CBAttackID"   ← mis à jour dynamiquement selon type
  └─ [Button] "Lancer"
```

**Blueprint Event Graph WBP — bouton Spawn Boss :**
```
[Button Spawn Boss → OnClicked]
  └─→ [Get Game Mode] → Cast to BP_JB_GameMode
        └─→ [Get JB_AdminSubsystem] (ou référence globale au DummyBoss)
              └─→ [Branch] Boss actif ?
                    FALSE → [Spawn Actor BP_JB_DummyBoss]
                              Location : [Get Boss Spawn Location] (socle central = 0,0,150)
                                └─→ Call BossStart
                    TRUE  → [Print] "Boss déjà actif"
```

**Mise à jour CBAttackID selon type sélectionné :**
```
[CBAttackType → OnSelectionChanged] (SelectedItem)
  ├─ "PATTERN" → CBAttackID.ClearOptions → AddOption chaque ID de patternIds
  ├─ "MISSILE" → idem avec missileIds
  └─ "UNIQUE"  → idem avec uniqueIds
```

> Définir les listes d'IDs comme variables Array String dans le WBP :
> `PatternIds = ["P1001","P1002",...,"P3011"]`
> `MissileIds = ["M1001","M1002",...,"M3004"]`
> `UniqueIds  = ["U2001","U2002","U3001","U3002","U3003"]`

---

## D. Panneau Joueur (Index 1)

```
[Vertical Box] "PanelJoueur"
  ├─ [Text] "👤 JOUEUR (MOI)"
  ├─ [CheckBox] "God Mode"
  ├─ [Button]   "Heal (HP max)"
  ├─ [CheckBox] "No-Clip"
  └─ [Button]   "TP au socle boss"
```

**God Mode CheckBox :**
```
[CheckBox GodMode → OnCheckStateChanged] (IsChecked)
  └─→ [Get Player Character] → Cast to BP_JB_Character
        └─→ Set variable "bGodMode" = IsChecked
```

> Côté BP_JB_Character : dans le système de dégâts (step 08), check `bGodMode` avant d'appliquer.

**No-Clip CheckBox :**
```
[CheckBox NoClip → OnCheckStateChanged] (IsChecked)
  └─→ [Get Player Character] → Cast to BP_JB_Character
        └─→ [Get Character Movement]
              ├─ TRUE  → Set Movement Mode = Flying + Set Gravity Scale = 0
              └─ FALSE → Set Movement Mode = Walking + Set Gravity Scale = 1
```

---

## E. Panneau Joueurs (Index 2)

Placeholder multijoueur — pour l'instant :
```
[Vertical Box] "PanelJoueurs"
  ├─ [Text] "👥 JOUEURS"
  └─ [Text] "Multijoueur non implémenté (step futur)"
```

---

## F. Panneau Gameplay (Index 3)

```
[Vertical Box] "PanelGameplay"
  ├─ [Text] "🎮 GAMEPLAY"
  │
  ├─ [Text] "Dash visuel"
  ├─ [ComboBoxString] "CBDashVisual"   ← Options : "Semi-Transparent", "Outline Glow", "Invisible"
  │
  ├─ [CheckBox] "Overlay iframes debug"
  ├─ [CheckBox] "Overlay hitbox debug"
  │
  ├─ [Text] "Vitesse boss"
  ├─ [Slider] "SliderBossSpeed"        Min=0.5, Max=2.0, Step=0.1, Default=1.0
  └─ [Text] "BossSpeedValue"           ← affiche la valeur actuelle du slider
```

**CBDashVisual → OnSelectionChanged :**
```
  ├─ "Semi-Transparent" → Set DashVisualMode = SemiTransparent (sur BP_JB_Character)
  ├─ "Outline Glow"     → Set DashVisualMode = OutlineGlow
  └─ "Invisible"        → Set DashVisualMode = FullInvisible
```

> `DashVisualMode` est une variable `E_DashVisualMode` à ajouter dans `BP_JB_Character`.
> Dans le nœud de dash (step03), remplacer le Set Opacity fixe par un Switch on Enum :
> - SemiTransparent → Opacity 0.3
> - OutlineGlow → SetRenderCustomDepth(true) + CustomDepthStencilValue = 1
> - FullInvisible → SetVisibility(false)

**SliderBossSpeed → OnValueChanged :**
```
  └─→ Set BossSpeedValue text = Format(Value, "×{0:.1f}")
      → Get reference BP_JB_DummyBoss → Set PatternDuration = 7.0 / SliderValue
```

---

## G. Panneau Props (Index 4)

```
[Vertical Box] "PanelProps"
  ├─ [Text] "📦 PROPS / DÉCORS"
  ├─ [ComboBoxString] "CBPropCategory"
  ├─ [ComboBoxString] "CBPropName"
  ├─ [Button] "Spawn (3m devant)"
  └─ [Button] "Supprimer le plus proche"
```

Logique identique à `AdminSpawnProp` de Kosmos :
```
[Button Spawn → OnClicked]
  [Get Player Character] → [Get Actor Location] → Origin
  [Get Player Character] → [Get Actor Forward Vector] → Fwd
  SpawnLoc = Origin + (Fwd × 300)  ← 3m devant
  [Spawn Actor] Class = mesh sélectionné, Location = SpawnLoc
  → stocker dans Array "SpawnedProps"

[Button Delete → OnClicked]
  → Boucle sur SpawnedProps, Find closest (< 1000cm), Destroy + Remove from array
```

---

## H. Ouvrir/Fermer le menu (F9)

Dans `BP_JB_Character` :

### H1 — Variable
| Nom              | Type                          | Rôle                  |
|------------------|-------------------------------|-----------------------|
| `AdminMenuWidget`| WBP_JB_AdminMenu (Object Ref) | Instance du widget    |
| `bAdminMenuOpen` | Boolean                       | État ouvert/fermé     |

### H2 — IA_AdminMenu

`Content/Input/Actions/` → IA_AdminMenu (Digital bool)
Dans `IMC_JB_Default` → IA_AdminMenu → touche **F9**

### H3 — Event Graph BP_JB_Character

```
[Enhanced Input Action IA_AdminMenu]  (Triggered)
  │
  └─→ [Branch] bAdminMenuOpen ?
        │
        FALSE → Ouvrir :
          [Create Widget] Class=WBP_JB_AdminMenu → Set AdminMenuWidget
          [Add to Viewport]
          [Set Input Mode UI Only]  ← souris devient visible, input clavier bloqué
          [Set Show Mouse Cursor] = true
          Set bAdminMenuOpen = true
        │
        TRUE → Fermer :
          [Remove from Parent] AdminMenuWidget
          [Set Input Mode Game Only]
          [Set Show Mouse Cursor] = false
          Set bAdminMenuOpen = false
```

> **Set Input Mode UI Only** pendant le menu : le ZQSD ne bouge plus le perso.
> **Set Input Mode Game Only** à la fermeture : tout revient à la normale.

---

## I. Résumé fichiers créés

```
Content/
├── Blueprints/
│   └── Admin/
│       ├── WBP_JB_AdminMenu.uasset    ← Widget principal
│       └── E_DashVisualMode.uasset    ← Enum dash visuel
└── Input/
    └── Actions/
        └── IA_AdminMenu.uasset        ← F9
```

> IMC_JB_Default à mettre à jour : ajouter IA_AdminMenu → F9

---

## J. Test

`Alt+P` → F9 :
- ✅ Menu s'ouvre, fond sombre, 5 catégories à gauche
- ✅ ZQSD ne bouge plus le joueur pendant le menu
- ✅ Clic sur "Spawn Boss" → BP_JB_DummyBoss apparaît au socle
- ✅ Pause/Reprendre → le boss stoppe ses attaques
- ✅ "Forcer attaque" → Print dans Output Log
- ✅ Dash visuel changeable depuis le menu Gameplay
- ✅ F9 à nouveau → menu fermé, jeu normal

---

**Prochaine étape → Step 05 : Dummy Boss (BP_JB_DummyBoss)** (`step05_dummy_boss.md`)
