# Step 07 — Patterns Suite (P2 restants + P3 + Missiles + Uniques)

**Objectif :** Compléter le catalogue complet des attaques. Après ce step, tous les patterns Kosmos sont portés en Blueprint.
**Prérequis :** Step 06 ✓ — BP_JB_Projectile fonctionnel, P1001→P1005, JB_SpawnProj, JB_FireAttack switch
**Blueprint only — aucun C++**

---

## Récap de ce qui existe déjà (ne pas refaire)

| Step | Patterns |
|------|----------|
| Step 06 | P1001–P1005 ✓ |

Ce step ajoute les **patterns D2 / D3 restants**, le **système missile** et les **Uniques**.

---

## A. Patterns D2 — Restants (5 patterns)

> Même framework que step06 : ajouter dans BP_JB_DummyBoss.

---

### A1 — P2002 : Rect Spin (grille vrillée)

> P1001 déguisé : même grille 4×8 mais chaque rangée spawne avec 0.07s de délai et un twist angulaire de +5° — donne l'illusion d'une grille qui tourne sur elle-même pendant le vol.

**Variables :**
```
SpinRowCount (Integer, non-instance)
```

**Custom Event `JB_SpawnSpinRow` :**
```
[Branch] SpinRowCount >= 8 ? → TRUE = return
│
BossPos = Get Actor Location
Direction = Normalize(LiveTargetLocation - BossPos)
PerpRight = Cross(Direction, (0,0,1))

YawTwist = SpinRowCount × 5                  ← twist cumulatif par rangée
TwistedRot = Make Rotator(0, [Rotation from X Vector]Direction.Yaw + YawTwist, 0)
TwistedDir = [Get Forward Vector] TwistedRot

For ColIdx = 0 to 3
  OffsetH = (ColIdx - 1.5) × 120
  OffsetV = (SpinRowCount - 3.5) × 100
  SpawnPos = BossPos + (PerpRight × OffsetH) + (0,0,OffsetV)
  JB_SpawnProj(SpawnPos, TwistedDir,
    Speed=750, Size=30, Damage=20, MaxDist=3500,
    Color=(1,0.4,0.05), Intensity=8, bSnap=false, ...)
│
SpinRowCount += 1
[Set Timer by Event] 0.07s → JB_SpawnSpinRow

[Function JB_Pat_RectSpin(BossPos)]
  Set SpinRowCount = 0
  Call JB_SpawnSpinRow
```

> Les 8 rangées spawned en 0.56s total, chacune légèrement décalée en angle → la grille "vrille" visuellement. Le twist max est de 35° (rangée 7) — suffisant pour perturber la lecture sans être injuste.

---

### A2 — P2003 : Triangles Rotatifs (3 triangles successifs)

> 3 triangles de taille décroissante (5→3→1 proj) tirés à 0°, 90°, 180° avec 0.8s entre chaque.

```
[Function JB_Pat_TrianglesRotatifs(BossPos)]
  For TriIdx = 0 to 2
    [Set Timer by Function Name] "JB_SpawnTriangle" Time = TriIdx × 0.8
```

**Custom Event `JB_SpawnTriangle(TriIdx Integer)` :**
```
BaseDir = Normalize(LiveTargetLocation - Get Actor Location)
BaseRot = [Rotation from X Vector] BaseDir
TriRot  = Make Rotator(0, BaseRot.Yaw + TriIdx × 90, 0)
TriDir  = [Get Forward Vector] TriRot
PerpRight = Cross(TriDir, (0,0,1))

RowSizes = [5, 3, 1]   ← Array of Integer (ou hardcoded dans un Switch)
For RowIdx = 0 to 2
  Count = RowSizes[RowIdx]
  OffsetV = (RowIdx - 1.0) × 100
  For ColIdx = 0 to Count-1
    OffsetH = (ColIdx - (Count-1)/2.0) × 120
    SpawnPos = BossPos + (PerpRight × OffsetH) + (0,0,OffsetV)
    JB_SpawnProj(SpawnPos, TriDir,
      Speed=700, Size=30, Damage=20, MaxDist=3000,
      Color=(1,0.1,0.1), Intensity=8, bSnap=false, ...)
```

> 3 triangles = 27 proj total. Le 3ème triangle (180°) arrive dos au joueur → il doit se retourner ou dash en avant. C'est le piège.

---

### A3 — P2005 : Lignes Alternées (2 flux décalés)

> Ligne A (orange, offset -60cm) puis Ligne B (rouge, offset +60cm) après 1.2s. Le joueur dodge A → B l'attend légèrement décalée.

```
[Function JB_Pat_LignesAlternees(BossPos)]
  Spawn Ligne A immédiatement
  [Set Timer by Event] 1.2s → SpawnLigneB
```

**Ligne A :**
```
Direction = Normalize(LiveTargetLocation - BossPos)
PerpRight = Cross(Direction, (0,0,1))
For i = 0 to 7
  OffsetH = (i - 3.5) × 120                    ← -420 à +420 cm (centré)
  OffsetV = -60                                 ← décalage vertical gauche
  SpawnPos = BossPos + (PerpRight × OffsetH) + (0,0,OffsetV)
  JB_SpawnProj(SpawnPos, Direction,
    Speed=700, Size=30, Damage=20, MaxDist=3500,
    Color=(1,0.4,0.05), Intensity=8, bSnap=false, ...)
```

**Ligne B (décalée) :**
```
(même logic)
OffsetV = +60                                   ← décalage vertical droite
JB_SpawnProj(..., Color=(1,0.1,0.1), ...)
```

> Deux lignes = 16 proj. La séparation verticale de 120cm est exactement 1 dash vertical. Dodge Ligne A → reçoit Ligne B si pas préparé.

---

### A4 — P2008 : Tourniquet (3 bras expansifs)

> 3 bras spawned en étoile (120° chacun), d'abord proches du boss, puis une 2ème salve à plus grande distance simulant l'expansion. Effet visuel de "roue qui tourne".

```
[Function JB_Pat_Tourniquet(BossPos)]
  Pour les 3 bras, deux phases avec 0.5s entre elles.

  Phase 1 — 3 bras serrés (dist = 90cm entre proj) :
  [Call JB_SpawnTourniquet(BossPos, Phase=1)]

  [Set Timer by Event] 1.5s → Phase 2

Phase 2 — 3 bras expansifs (dist = 150cm) + bras pivotés 60° :
  [Call JB_SpawnTourniquet(BossPos, Phase=2)]
```

**Fonction `JB_SpawnTourniquet(BossPos, Phase Integer)` :**
```
BaseDir = Normalize(LiveTargetLocation - BossPos)
BaseRot = [Rotation from X Vector] BaseDir
Spacing = Phase == 1 ? 90 : 150

For ArmIdx = 0 to 2
  PhaseOffset = Phase == 1 ? 0 : 60
  ArmYaw = ArmIdx × 120 + PhaseOffset
  ArmRot = Make Rotator(0, BaseRot.Yaw + ArmYaw, 0)
  ArmDir = [Get Forward Vector] ArmRot

  For j = 1 to 6
    SpawnPos = BossPos + (ArmDir × j × Spacing)
    JB_SpawnProj(SpawnPos, ArmDir,
      Speed = Phase == 1 ? 500 : 900,
      Size=30, Damage=20, MaxDist=3000,
      Color = Phase == 1 ? (1,0.4,0.05) : (1,0.1,0.1),
      Intensity=8, bSnap=false, ...)
```

> Phase 1 (lente, orange) = tell visuel. Phase 2 (rapide, rouge, pivotée 60°) arrive là où le joueur ne l'attend pas.

---

### A5 — P2009 : Double Hélice (CW + CCW → snap 45°)

> Deux spirales opposées (20 proj chacune, 2 tours). Toutes snappent à 1000cm, +45° pour CW, -45° pour CCW.

```
[Function JB_Pat_DoubleHelice(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  BaseRot   = [Rotation from X Vector] Direction
  PerpRight = Cross(Direction, (0,0,1))

  Turns = 2.0      (720° total)
  Count = 20

  For i = 0 to 19
    t = i / 19.0                               ← 0.0 → 1.0
    Radius = Lerp(100, 800, t)                 ← rayon croissant 100→800 cm

    ─── Hélice CW ───
    AngleCW = i × (Turns × 360.0 / Count)     ← +36° par proj
    OffsetH_CW = Cos(AngleCW°) × Radius
    OffsetV_CW = Sin(AngleCW°) × Radius
    SpawnPosCW = BossPos + (PerpRight × OffsetH_CW) + (0,0,OffsetV_CW)
    JB_SpawnProj(SpawnPosCW, Direction,
      Speed=700, Size=30, Damage=20, MaxDist=3500,
      Color=(1,0.4,0.05), Intensity=8,
      bSnap=true, SnapDist=1000, SnapAngle=+45, SnapMult=1.4)

    ─── Hélice CCW ───
    AngleCCW = -(i × (Turns × 360.0 / Count)) ← sens opposé
    OffsetH_CCW = Cos(AngleCCW°) × Radius
    OffsetV_CCW = Sin(AngleCCW°) × Radius
    SpawnPosCCW = BossPos + (PerpRight × OffsetH_CCW) + (0,0,OffsetV_CCW)
    JB_SpawnProj(SpawnPosCCW, Direction,
      Speed=700, Size=30, Damage=20, MaxDist=3500,
      Color=(1,0.1,0.1), Intensity=8,
      bSnap=true, SnapDist=1000, SnapAngle=-45, SnapMult=1.4)
```

> 40 proj total. Les deux spirales semblent s'écarter → après 10m, elles se referment en ciseau. Un seul couloir de fuite par côté.

---

## B. Patterns D3 — Restants (8 patterns)

---

### B1 — P3002 : Double Spirale (CW orange + CCW rouge)

> Même principe que P2009 mais sans snap — deux spirales pures, opposées, simultanées. Plus lisible mais plus dense.

```
[Function JB_Pat_DoubleSpirale(BossPos)]
  (Identique à P2009, sans bSnap)

  For i = 0 to 19
    t = i / 19.0
    Radius = Lerp(100, 900, t)

    AngleCW  = i × (2.5 × 360.0 / 20)        ← 2.5 tours CW
    AngleCCW = -AngleCW                        ← CCW

    SpawnCW → JB_SpawnProj(... Color=(1,0.4,0.05), bSnap=false, ...)
    SpawnCCW → JB_SpawnProj(... Color=(1,0.1,0.1), bSnap=false, ...)
```

> 40 proj. Orange va CW, rouge va CCW. Le joueur voit deux spirales qui s'enlacent. Gaps étroits mais réguliers.

---

### B2 — P3003 : Parcours Murs (gauntlet 3 murs)

> 3 murs de projectiles en succession (2s entre chaque), avec un trou qui alterne Gauche/Droite/Gauche. Force 3 repositionnements.

```
[Function JB_Pat_ParcourssMurs(BossPos)]
  GapPositions = [(0, 1), (8, 9), (0, 1)]    ← indices de cols à skipper (trous)
  WaveColors   = [(1,0.1,0.1), (0.67,0.2,1.0), (1,0.4,0.05)]

  For WallIdx = 0 to 2
    [Set Timer by Event] WallIdx × 2.0s →
      SpawnWall(BossPos, GapPositions[WallIdx], WaveColors[WallIdx])

[Function SpawnWall(BossPos, GapCols, Color)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  PerpRight = Cross(Direction, (0,0,1))

  For ColIdx = 0 to 9                         ← 10 colonnes
    [Branch] ColIdx == GapCols.X OR ColIdx == GapCols.Y ? → skip
    For RowIdx = 0 to 2                        ← 3 rangées de hauteur
      OffsetH = (ColIdx - 4.5) × 120          ← -540 à +540 cm
      OffsetV = (RowIdx - 1.0) × 100
      SpawnPos = BossPos + (PerpRight × OffsetH) + (0,0,OffsetV)
      JB_SpawnProj(SpawnPos, Direction,
        Speed=700, Size=30, Damage=20, MaxDist=3500,
        Color=Color, Intensity=8, bSnap=false, ...)
```

> Mur 1 = rouge, trou à gauche. Mur 2 = violet, trou à droite. Mur 3 = orange, trou à gauche. Chaque mur = 24 proj (2 trous × 3 rows = -6 → 30-6=24). 2s = pile assez pour se repositionner avec un dash.

---

### B3 — P3004 : Nébuleuse (cercle qui converge)

> 20 proj spawned sur un cercle de rayon 1000cm autour du joueur, tous pointés vers le joueur. Même principe que P3006 mais depuis une distance plus grande, speed plus lente.

```
[Function JB_Pat_Nebuleuse(BossPos)]
  PlayerPos = Get Actor Location of BP_JB_Character

  For i = 0 to 19
    Angle    = i × 18                          ← 360/20 = 18°
    SpawnRadius = 1000
    OffsetX  = Cos(Angle°) × SpawnRadius
    OffsetY  = Sin(Angle°) × SpawnRadius
    SpawnPos = PlayerPos + Make Vector(OffsetX, OffsetY, 0)

    Direction = Normalize(PlayerPos - SpawnPos) ← tous vers le joueur
    JB_SpawnProj(SpawnPos, Direction,
      Speed=800, Size=30, Damage=20, MaxDist=2000,
      Color=(1,0.1,0.1), Intensity=8, bSnap=false, ...)
```

> MaxDist=2000cm = ils meurent après 20m depuis leur spawn (≈ juste après le centre). Différence avec P3006 : 20 proj (vs 8), radius 1000cm (vs 700cm). Plus de temps pour réagir mais plus de proj → dash latéral hors du cercle, pas vers le centre.

---

### B4 — P3005 : Spirale Snap (spirale → snap 90°)

> Spirale CW classique (20 proj, 2.5 tours), mais toutes les boules sont snap à 1000cm avec un angle de 90°. Elles semblent partir droit → tournent brusquement.

```
[Function JB_Pat_SpiralSnap(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  PerpRight = Cross(Direction, (0,0,1))

  For i = 0 to 19
    t = i / 19.0
    Radius = Lerp(100, 900, t)
    Angle  = i × (2.5 × 360.0 / 20)
    OffsetH = Cos(Angle°) × Radius
    OffsetV = Sin(Angle°) × Radius
    SpawnPos = BossPos + (PerpRight × OffsetH) + (0,0,OffsetV)

    JB_SpawnProj(SpawnPos, Direction,
      Speed=800, Size=30, Damage=20, MaxDist=3500,
      Color=(0.67,0.2,1.0), Intensity=10,
      bSnap=true, SnapDist=1000, SnapAngle=90, SnapMult=1.5)
```

> Violet = signal "ça va snapper". Snap à 90° = les projectiles font un virage droit → le joueur qui esquive latéralement se fait rattraper. Dash perpendiculaire au snap = seule échappatoire.

---

### B5 — P3007 : Mandala (3 anneaux contra-rotatifs)

> 3 anneaux de proj qui "tournent" autour du boss pendant 3s, puis convergent vers le centre. La rotation est simulée par des spawns séquentiels en cercle, décalés angulaire à chaque itération.

**Variables :**
```
MandalaPhase  (Integer, non-instance)    ← 0=spin, 1=converge
MandalaAngle  (Float, non-instance)
MandalaCount  (Integer, non-instance)
```

**Phase Spin (3s de spectacle) :**
```
[Custom Event] JB_MandalaSpinTick
  [Branch] MandalaCount >= 30 ? → TRUE = go Phase Converge
  │
  BossPos = Get Actor Location
  MandalaAngle += 6              ← 6° par tick × 30 = 180° total (demi-tour)

  ─── Anneau 1 : radius 300cm, 10 proj, CW ───
  For i = 0 to 9
    A = (i × 36) + MandalaAngle
    SpawnPos = BossPos + (PerpRight × Cos(A°) × 300) + (0,0,Sin(A°) × 300)
    JB_SpawnProj(SpawnPos, Direction_flat,
      Speed=100, Size=25, Damage=20, MaxDist=200,    ← MaxDist 200 = proj "de décor"
      Color=(1,0.4,0.05), Intensity=6, bSnap=false, ...)

  ─── Anneau 2 : radius 550cm, 16 proj, CCW ───
  For i = 0 to 15
    A = (i × 22.5) - MandalaAngle
    SpawnPos = BossPos + (PerpRight × Cos(A°) × 550) + (0,0,Sin(A°) × 550)
    JB_SpawnProj(SpawnPos, Direction_flat,
      Speed=100, Size=25, MaxDist=200, Color=(1,0.1,0.1), Intensity=6, ...)

  ─── Anneau 3 : radius 800cm, 22 proj, CW ───
  For i = 0 to 21
    A = (i × 16.36) + MandalaAngle
    SpawnPos = BossPos + (PerpRight × Cos(A°) × 800) + (0,0,Sin(A°) × 800)
    JB_SpawnProj(SpawnPos, Direction_flat,
      Speed=100, Size=25, MaxDist=200, Color=(0.67,0.2,1.0), Intensity=6, ...)
  │
  MandalaCount += 1
  [Set Timer by Event] 0.1s → JB_MandalaSpinTick
```

> **Note BP :** `Direction_flat` = direction vers le joueur mais applatie sur le plan horizontal (Z=0). Speed=100 + MaxDist=200 = les proj avancent à peine → ils semblent "flotter". Ce sont des indicateurs visuels. L'attaque réelle vient dans la phase converge.

**Phase Converge (après 3s) :**
```
[Custom Event] JB_MandalaConverge
  BossPos = Get Actor Location
  PlayerPos = Get Actor Location of Character
  Direction = Normalize(PlayerPos - BossPos)
  PerpRight = Cross(Direction, (0,0,1))

  ─── Lancer tous les anneaux d'un coup, pleine vitesse ───
  For each Ring (radius in [300, 550, 800], count in [10, 16, 22])
    For i = 0 to count-1
      A = i × (360 / count)
      SpawnPos = BossPos + PerpRight × Cos(A°) × radius + (0,0,Sin(A°) × radius)
      JB_SpawnProj(SpawnPos, Direction,
        Speed=900, Size=25, Damage=20, MaxDist=3500, ...)

[Function JB_Pat_Mandala(BossPos)]
  Set MandalaAngle = 0
  Set MandalaCount = 0
  Call JB_MandalaSpinTick
```

> Pattern hypnotisant : 3s de show visuel → 48 proj convergents d'un coup. Lisible mais stressant. Le joueur sait ce qui arrive mais ne peut pas tous les éviter sans un bon dash.

---

### B6 — P3008 : Fleur du Chaos (pétales convergentes + snap)

> 8 pétales de 3 proj chacune, spawned à 1400cm du boss, toutes pointant vers le boss. Snap à 1200cm, 90°.

```
[Function JB_Pat_FleurChaos(BossPos)]
  For PetalIdx = 0 to 7
    PetalAngle = PetalIdx × 45
    SpawnRadius = 1400

    ─── 3 proj par pétale, légèrement étalés ───
    For SubIdx = -1 to 1          ← -1, 0, +1
      SpawnAngle = PetalAngle + SubIdx × 8     ← écart de 8° entre proj
      OffsetX = Cos(SpawnAngle°) × SpawnRadius
      OffsetY = Sin(SpawnAngle°) × SpawnRadius
      SpawnPos = BossPos + Make Vector(OffsetX, OffsetY, 0)

      Direction = Normalize(BossPos - SpawnPos) ← vers le boss
      JB_SpawnProj(SpawnPos, Direction,
        Speed=1000, Size=35, Damage=20, MaxDist=3500,
        Color=(1,0.1,0.1), Intensity=9,
        bSnap=true, SnapDist=1200, SnapAngle=90, SnapMult=1.0)
```

> 24 proj depuis l'extérieur → convergent rapidement (14m / 10 m/s = 1.4s). Snap à 1200cm = à 2m du boss. Elles passent "autour" du boss puis font un virage. Le joueur doit être loin du boss ET pas dans l'axe du snap.

---

### B7 — P3009 : Engrenage 🎭 (faux-semblant)

> **Concept :** grande roue (16 proj, radius 700cm) + petite roue (8 proj, radius 350cm). Les deux semblent identiques. Après 3s, grande roue = lancée orange normale. Petite roue = se révèle être des missiles tracking.

**Prérequis : BP_JB_Missile fonctionnel (section C de ce step).**

```
[Function JB_Pat_Engrenage(BossPos)]
  ─── Spawn grande roue (décor + lancement) ───
  For i = 0 to 15
    A = i × 22.5
    OuterPos = BossPos + (PerpRight × Cos(A°) × 700) + (0,0,Sin(A°) × 700)
    JB_SpawnProj(OuterPos, [prop direction flat],
      Speed=50, Size=35, Damage=20, MaxDist=150,         ← "décor" temporaire
      Color=(1,0.4,0.05), Intensity=6, bSnap=false, ...)

  ─── Spawn petite roue (fake — même apparence) ───
  For i = 0 to 7
    A = i × 45
    InnerPos = BossPos + (PerpRight × Cos(A°) × 350) + (0,0,Sin(A°) × 350)
    JB_SpawnProj(InnerPos, [prop direction flat],
      Speed=50, Size=35, Damage=20, MaxDist=150,         ← "décor" temporaire
      Color=(1,0.4,0.05), Intensity=6, ...)

  ─── Après 3s : lancer grande roue outward + spawner missiles depuis petite ───
  [Set Timer by Event] 3.0s →
    ─── Grande roue : lancement pleine vitesse ───
    For i = 0 to 15
      A = i × 22.5
      LaunchDir = Normalize(Make Vector(Cos(A°), Sin(A°), 0))
      JB_SpawnProj(BossPos + (LaunchDir × 700), LaunchDir,
        Speed=900, Size=35, Damage=20, MaxDist=3500,
        Color=(1,0.4,0.05), Intensity=8, bSnap=false, ...)

    ─── Petite roue : spawn missiles (tracking) ───
    For i = 0 to 7
      A = i × 45
      MissilePos = BossPos + Make Vector(Cos(A°) × 350, Sin(A°) × 350, 0)
      [Spawn Actor BP_JB_Missile] at MissilePos
        Set Color=(0.1,0.5,1.0), Intensity=8
        Set Speed=700, Size=35, Damage=25, MaxDist=3500
```

> Le faux-semblant : petite roue = orange identique à la grande → joueur se concentre sur la grande roue → les missiles bleus révélés le surprennent. Classic.

---

### B8 — P3011 : Labyrinthe Tournant (murs rotatifs convergents)

> 3 "murs" de proj (6 par mur) disposés en étoile, qui se resserrent sur le joueur pendant 4s, puis rafale finale.

**Variables :**
```
LabyrinthCount (Integer, non-instance)
LabyrinthAngle (Float, non-instance)
```

```
[Custom Event] JB_LabyrinthTick
  [Branch] LabyrinthCount >= 40 ? → TRUE = go Burst
  │
  BossPos   = Get Actor Location
  PlayerPos = Get Actor Location of Character
  Direction = Normalize(PlayerPos - BossPos)
  BaseRot   = [Rotation from X Vector] Direction

  Radius = Lerp(800, 150, LabyrinthCount / 39.0)   ← rétrécit de 800cm → 150cm
  LabyrinthAngle += 9                               ← 9° par tick (rotation)

  For WallIdx = 0 to 2
    WallAngle = WallIdx × 120 + LabyrinthAngle
    WallDir = [Get Forward Vector] Make Rotator(0, BaseRot.Yaw + WallAngle, 0)
    PerpW   = Cross(WallDir, (0,0,1))

    For j = -2 to 3                                ← 6 proj par mur
      SpawnPos = BossPos + (WallDir × Radius) + (PerpW × j × 120)
      JB_SpawnProj(SpawnPos, WallDir,
        Speed=50, Size=30, Damage=20, MaxDist=150,  ← proj "décor" temporaire
        Color=(1,0.1,0.1), Intensity=7, bSnap=false, ...)
  │
  LabyrinthCount += 1
  [Set Timer by Event] 0.1s → JB_LabyrinthTick

[Custom Event] JB_LabyrinthBurst
  BossPos   = Get Actor Location
  PlayerPos = Get Actor Location of Character
  Direction = Normalize(PlayerPos - BossPos)
  BaseRot   = [Rotation from X Vector] Direction

  For WallIdx = 0 to 2
    WallYaw = WallIdx × 120
    WallRot = Make Rotator(0, BaseRot.Yaw + WallYaw, 0)
    WallDir = [Get Forward Vector] WallRot
    PerpW   = Cross(WallDir, (0,0,1))
    For j = -2 to 3
      SpawnPos = BossPos + (PerpW × j × 120)
      JB_SpawnProj(SpawnPos, WallDir,
        Speed=900, Size=30, Damage=25, MaxDist=3000,
        Color=(1,0.4,0.05), Intensity=9, bSnap=false, ...)

[Function JB_Pat_LabyrinteTournant(BossPos)]
  Set LabyrinthCount = 0
  Set LabyrinthAngle = 0
  Call JB_LabyrinthTick
```

> 4s de murs visuels qui resserrent → 18 proj finaux en rafale (3 directions × 6). Le joueur est coincé dans un espace de plus en plus petit puis subit la rafale. Identifier le gap entre les murs avant la rafale.

---

## C. Système Missiles — BP_JB_Missile

> Missiles = tracking actif. Ils corrigent leur trajectoire vers le joueur à chaque Tick.

### C1 — Créer BP_JB_Missile

`Content/Blueprints/Projectiles/` → Blueprint Class → **Actor**
Nommer : `BP_JB_Missile`

**Composants (identiques à BP_JB_Projectile) :**
- `SphereCollision` (root) — radius 30
- `StaticMesh` — Engine/BasicShapes/Sphere, légèrement allongé (Scale X=1.5)
- `ProjectileMovement`

**Variables spécifiques missiles :**
| Nom           | Type   | Défaut | Role                                |
|---------------|--------|--------|-------------------------------------|
| `Speed`       | Float  | 700.0  | cm/s                                |
| `Damage`      | Float  | 25.0   | Dégâts                              |
| `MaxDist`     | Float  | 3500.0 | Distance de vie                     |
| `TurnRate`    | Float  | 120.0  | Degrés/s de rotation max            |
| `ActivateDelay`| Float | 0.0   | Délai avant activation tracking     |
| `bActive`     | Bool   | false  | Tracking activé                     |
| `SpawnLoc`    | Vector | -      | Mémorisé BeginPlay                  |
| `MatInst`     | MID    | -      | Material dynamique                  |

### C2 — BeginPlay Missile

```
[Event BeginPlay]
  Set SpawnLoc = Get Actor Location
  Set MatInst = Create Dynamic Material Instance (M_Projectile)
  Set Vector Param "Color" = (0.1, 0.5, 1.0) × 8.0  ← bleu
  │
  Configure ProjectileMovement :
    Initial Speed = Speed
    Max Speed     = Speed
    Rotating Component : oui (vitesse = 360°/s)  ← visuel rotation missile
  │
  [Set Timer by Event] ActivateDelay → ActiveTracking
```

### C3 — Tick Missile (tracking)

```
[Event Tick] (DeltaTime)
  │
  ├─ Mort par distance :
  │    VSize(Get Actor Location - SpawnLoc) >= MaxDist → Destroy Actor
  │
  └─ Tracking (si bActive) :
       PlayerPos = Get Actor Location of Character
       MissilePos = Get Actor Location
       TargetDir  = Normalize(PlayerPos - MissilePos)
       CurrentVel = ProjectileMovement.Velocity
       CurrentDir = Normalize(CurrentVel)
       │
       NewDir = [VInterp To] Current=CurrentDir Target=TargetDir
                  DeltaTime=DeltaTime InterpSpeed=TurnRate/Speed
       │
       [Set Velocity on ProjectileMovement] NewDir × Speed

[Custom Event] ActiveTracking
  Set bActive = true
```

> **VInterp To** (smooth rotation) vs rotation instantanée = missile qui tourne progressivement. Plus fair, plus intéressant à esquiver. TurnRate=120 avec Speed=700 = rayon de virage ~330cm.

### C4 — Collision Missile (identique Projectile)

```
[OnComponentBeginOverlap] → Cast to BP_JB_Character
  NOT bIsInvincible → Damage, Destroy
```

---

## D. Patterns Missiles

> Ajouter dans BP_JB_DummyBoss. Utiliser `[Spawn Actor BP_JB_Missile]` à la place de JB_SpawnProj.

**Helper rapide — JB_SpawnMissile(Pos, Dir, Delay) :**
```
[Spawn Actor BP_JB_Missile]
  Location : Pos
  Rotation : [Rotation from X Vector] Dir
  → Set Speed=700, Damage=25, MaxDist=3500
  → Set ActivateDelay=Delay
```

---

### D1 — M1001 : Salve Simple (3 missiles successifs)

```
[Function JB_Pat_M_Salve(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  PerpRight = Cross(Direction, (0,0,1))
  Offsets = [-50, 50, 0]   ← cm perpendiculaire

  For i = 0 to 2
    Pos = BossPos + (PerpRight × Offsets[i])
    [Set Timer by Event] i × 0.3s → SpawnMissile(Pos, Direction, Delay=0)
```

> 3 missiles avec 0.3s entre chaque. Spacing 50cm = très serré. Dash latéral large = seule échappatoire.

---

### D2 — M1002 : Éventail Missiles (5 missiles, arc 60°)

```
[Function JB_Pat_M_Eventail(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  BaseRot   = [Rotation from X Vector] Direction

  For i = 0 to 4
    YawOff = (i - 2) × 15                     ← -30°, -15°, 0°, +15°, +30°
    MissileRot = Make Rotator(0, BaseRot.Yaw + YawOff, 0)
    MissileDir = [Get Forward Vector] MissileRot
    Pos = BossPos + (MissileDir × 80)         ← légèrement devant le boss
    JB_SpawnMissile(Pos, MissileDir, Delay=0.0)
```

> 5 missiles en éventail. Ils se corrigent vers le joueur → même si le joueur bouge, les missiles pivotent. 1 dash bien timé passe entre deux missiles.

---

### D3 — M2001 : Doubles Vagues (vague 2 ciblée post-esquive)

```
[Function JB_Pat_M_DoubleVague(BossPos)]
  Spawn 4 missiles en ligne (spacing 120cm) → vague 1 (orange)
  [Set Timer by Event] 1.5s → Spawn vague 2 (rouge) ← re-cibler le joueur
```

> Vague 2 recalcule la position joueur → le joueur qui a dashé pour esquiver vague 1 est la cible de vague 2.

---

### D4 — M2002 : Pinces (2 missiles convergents)

```
[Function JB_Pat_M_Pinces(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  PerpRight = Cross(Direction, (0,0,1))

  PosLeft  = BossPos + (PerpRight × -200)
  PosRight = BossPos + (PerpRight ×  200)

  JB_SpawnMissile(PosLeft,  Direction, Delay=0)
  JB_SpawnMissile(PosRight, Direction, Delay=0)
```

> Deux missiles partent des côtés du boss et convergent vers le joueur. Passer entre les deux = possible avec un dash vers le boss.

---

### D5 — M2003 : Faux Projectiles 🎭 (orange → missiles à mi-chemin)

> **Concept :** 5 projectiles normaux (orange) → à 8m, ils spawnen des missiles bleus sur leur position et se détruisent. Le joueur pensait esquiver des proj → les missiles arrivent.

**Besoin :** une variable `bMorphToMissile` dans BP_JB_Projectile + logique dans Tick.

```
Ajout variable dans BP_JB_Projectile :
  bMorphToMissile (Boolean, Instance Editable, défaut false)
  MorphDist       (Float, Instance Editable, défaut 800.0)

Dans Event Tick, après la logique distance/snap :
  [Branch] bMorphToMissile AND NOT bSnapped AND DistDone >= MorphDist ?
    TRUE →
      Set bSnapped = true                      ← réutilise bSnapped pour "déjà morphé"
      [Spawn Actor BP_JB_Missile] at Get Actor Location
        Set ActivateDelay = 0
      [Destroy Actor] (self)
```

**Pattern :**
```
[Function JB_Pat_M_FauxProjectiles(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  PerpRight = Cross(Direction, (0,0,1))
  For i = 0 to 4
    OffsetH = (i - 2) × 120
    SpawnPos = BossPos + (PerpRight × OffsetH)
    JB_SpawnProj(SpawnPos, Direction,
      Speed=800, Size=30, Damage=20, MaxDist=3500,
      Color=(1,0.4,0.05), Intensity=8,
      bSnap=false, bMorphToMissile=true, MorphDist=800, ...)
```

> Orange = trompeur. Le joueur repositionne pour éviter la grille → à 8m, 5 missiles bleus apparaissent sur les positions des proj et le ciblent depuis ces nouvelles positions.

---

### D6 — M2004 : Spirale Missiles (8 missiles depuis cercle)

```
[Function JB_Pat_M_Spirale(BossPos)]
  For i = 0 to 7
    A = i × 45
    SpawnRadius = 300
    Pos = BossPos + Make Vector(Cos(A°) × SpawnRadius, Sin(A°) × SpawnRadius, 0)
    Direction = Normalize(LiveTargetLocation - Pos)
    [Set Timer by Event] i × 0.2s → JB_SpawnMissile(Pos, Direction, Delay=0)
```

> 8 missiles en spirale depuis autour du boss avec 0.2s entre chaque. Pas simultanés → le joueur a moins de temps pour gérer tous les angles.

---

### D7 — M2005 : Retardés (missiles à activation différée)

```
[Function JB_Pat_M_Retardes(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  PerpRight = Cross(Direction, (0,0,1))
  ActivationDelays = [0.0, 0.6, 1.2, 0.3, 0.9, 1.5]

  For i = 0 to 5
    OffsetH = (i - 2.5) × 120
    Pos = BossPos + (PerpRight × OffsetH)
    JB_SpawnMissile(Pos, Direction, Delay=ActivationDelays[i])
    ← le missile spawn, avance lentement (Speed=200 pendant le délai) puis accélère
```

**Note :** Ajouter `SpeedActivated` dans BP_JB_Missile. Pendant `bActive=false`, Speed=200. Au `ActiveTracking`, Speed=900.

> 6 missiles lents puis soudainement rapides à des instants différents. Impossible de tous esquiver avec un seul dash → lecture des délais = compétence requise.

---

### D8 — M3001 : Faux Mur 🎭

```
[Function JB_Pat_M_FauxMur(BossPos)]
  (identique à M2003 mais 8 proj en grille 8×1)
  bMorphToMissile=true, MorphDist=800
```

> Mur de 8 proj orange → tous morphent en missiles simultanément à mi-chemin.

---

### D9 — M3002 : Déluge (10 missiles rapides, offsets aléatoires)

```
[Function JB_Pat_M_Deluge(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  PerpRight = Cross(Direction, (0,0,1))

  For i = 0 to 9
    RandomOffset = [Random Float In Range] -250 250
    Pos = BossPos + (PerpRight × RandomOffset)
    [Set Timer by Event] i × 0.15s → JB_SpawnMissile(Pos, Direction, Delay=0)
      avec Speed=800
```

> 10 missiles rapides (0.15s entre chaque), offsets aléatoires. L'aléatoire est OK ici = difficulté intentionnelle. Dash en boucle = seule stratégie viable.

---

### D10 — M3004 : Faux Salve 🎭 (missile caché parmi 5)

```
[Function JB_Pat_M_FauxSalve(BossPos)]
  FakeIndex = 2    ← index 0-based du missile caché (position centrale)
  Direction = Normalize(LiveTargetLocation - BossPos)
  PerpRight = Cross(Direction, (0,0,1))

  For i = 0 to 4
    OffsetH = (i - 2) × 120
    Pos = BossPos + (PerpRight × OffsetH)

    IF i == FakeIndex :
      JB_SpawnMissile(Pos, Direction, Delay=0)    ← vrai missile
    ELSE :
      JB_SpawnProj(Pos, Direction, Speed=800, Size=30, bSnap=false, ...)  ← faux
```

> 5 "proj" identiques, mais le central est un missile. Visuellement indistinguables au spawn (orange, même taille). Le missile commence à dévier vers le joueur après ~2s → tard pour esquiver.

---

## E. Uniques

---

### E1 — U2001 : Boomerang (aller violet → demi-tour → retour rouge)

> **Concept :** 9 proj en éventail 120° partent du boss, voyagent 1200cm, s'arrêtent, inversent et reviennent à grande vitesse.

**Besoin :** Variable `bBoomerang` dans BP_JB_Projectile + logique dans Tick.

```
Ajout dans BP_JB_Projectile :
  bBoomerang       (Boolean, Instance Editable, défaut false)
  BoomerangDist    (Float, Instance Editable, défaut 1200.0)
  bBoomeranged     (Boolean, non-instance, défaut false)

Dans Event Tick :
  [Branch] bBoomerang AND NOT bBoomeranged AND DistDone >= BoomerangDist ?
    TRUE →
      Set bBoomeranged = true
      ─── Inverser vitesse ───
      CurrentVel = ProjectileMovement.Velocity
      [Set Velocity on ProjectileMovement] = CurrentVel × -1.5  ← retour plus rapide
      ─── Changer couleur : violet → rouge ───
      [Set Vector Param "Color"] = (1,0.1,0.1) × 10
```

**Pattern :**
```
[Function JB_Pat_Boomerang(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  BaseRot   = [Rotation from X Vector] Direction

  For i = 0 to 8
    YawOff = (i - 4) × 15                     ← -60° à +60° (éventail 120°)
    ShotRot = Make Rotator(0, BaseRot.Yaw + YawOff, 0)
    ShotDir = [Get Forward Vector] ShotRot
    JB_SpawnProj(BossPos, ShotDir,
      Speed=800, Size=35, Damage=20, MaxDist=4000,
      Color=(0.67,0.2,1.0), Intensity=10,
      bBoomerang=true, BoomerangDist=1200, ...)
```

> Le joueur recule pour éviter l'éventail → les proj font demi-tour et le rattrapent depuis la même direction. Dash vers le boss (entre les proj aller) = meilleure stratégie.

---

### E2 — U2002 : L'Essaim 🎭 (12 missiles qui disparaissent + retour)

> **Faux-semblant :** 12 missiles semblent partir à l'opposé du joueur, hors champ → reviennent 2s plus tard depuis l'extérieur.

```
[Function JB_Pat_Essaim(BossPos)]
  PlayerPos = Get Actor Location of Character
  AwayDir   = Normalize(BossPos - PlayerPos)  ← direction OPPOSÉE au joueur

  For i = 0 to 11
    A = i × 30
    SpawnDir = Rotate AwayDir by A° around Z
    JB_SpawnMissile(BossPos, SpawnDir, Delay=2.0)  ← Delay = 2s avant tracking
    ← missile part à l'opposé, puis au bout de 2s, tracking s'active → demi-tour
```

> Missiles bleus partent en sens inverse → le joueur croit avoir du temps → ils font demi-tour et arrivent de tous les angles. ActivateDelay=2.0 est le secret du faux-semblant.

---

### E3 — U3001 : La Pluie (chute ciblée avec avertissement)

> 8 impacts tombent depuis le haut, ciblés sur ou près du joueur, avec un marqueur au sol pendant 1.2s avant l'impact.

**Besoin :** Un `BP_JB_RainMarker` Actor (simple décal ou mesh plan avec material warning) + logique de spawn de proj depuis le haut.

```
[Function JB_Pat_Pluie(BossPos)]
  PlayerPos = Get Actor Location of Character

  For i = 0 to 7
    [Set Timer by Event] i × 0.5s → SpawnRainDrop(PlayerPos, i)

[Custom Event] SpawnRainDrop(BasePos, i)
  ─── Offset aléatoire autour du joueur ───
  RandomOffsetX = [Random Float In Range] -300 300
  RandomOffsetY = [Random Float In Range] -300 300
  TargetPos = BasePos + Make Vector(RandomOffsetX, RandomOffsetY, 0)

  ─── Spawner le marqueur au sol ───
  [Spawn Actor BP_JB_RainMarker] at TargetPos   ← cercle rouge au sol
  │
  ─── Après 1.2s : spawner le proj depuis le haut ───
  [Set Timer by Event] 1.2s →
    SpawnPos = TargetPos + (0, 0, 1500)          ← 15m au dessus
    JB_SpawnProj(SpawnPos, (0,0,-1),              ← vers le bas
      Speed=1500, Size=40, Damage=25, MaxDist=2000,
      Color=(1,0.1,0.1), Intensity=9, bSnap=false, ...)
    [Destroy BP_JB_RainMarker]
```

> Le marqueur au sol donne 1.2s pour sortir de la zone. Rayon danger ≈ 100cm (Size=40 = radius 40cm hitbox). 8 impacts en 3.5s sur des positions semi-aléatoires.

---

### E4 — U3002 : Le Miroir 🎭

> Grille 5×4 (comme P1001 mais plus petite). Les colonnes 1 et 3 (indices 0-based) sont des missiles, les autres sont des proj normaux. Visuellement identiques.

```
[Function JB_Pat_Miroir(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  PerpRight = Cross(Direction, (0,0,1))
  FakeCols  = [1, 3]                           ← colonnes missiles

  For ColIdx = 0 to 4
    For RowIdx = 0 to 3
      OffsetH = (ColIdx - 2.0) × 120
      OffsetV = (RowIdx - 1.5) × 100
      SpawnPos = BossPos + (PerpRight × OffsetH) + (0,0,OffsetV)

      IF ColIdx in FakeCols :
        JB_SpawnMissile(SpawnPos, Direction, Delay=0.0)
      ELSE :
        JB_SpawnProj(SpawnPos, Direction, Speed=800, ...)
```

> 20 "projectiles" dont 8 missiles cachés. Les missiles dévient légèrement après ~1s → le joueur voit trop tard lequel est lequel.

---

### E5 — U3003 : Architecture Vivante

> **Note de portage :** Ce pattern implique des formes géométriques dessinées progressivement (maison, voiture, chat, épée) avec des centaines de projectiles ponctuels. En Blueprint pur, ce serait des centaines de SpawnProj synchronisés.

> **Recommandation :** Implémenter en deux phases lors d'un step dédié après les bases multijoueur :
> 1. Définir les formes comme des tableaux de Vector offsets (coordonnées des "pixels")
> 2. Spawner avec un timer loop sur chaque point
> 3. La phase épée finale = rafale linéaire classique (faisable avec le framework existant)

> Pour l'instant, le placer dans JB_FireAttack avec un stub PrintString. Portage complet = step ultérieur.

---

## F. Mise à jour JB_FireAttack (switch complet)

Ajouter tous les nouveaux IDs dans le Switch on String de `JB_FireAttack` dans BP_JB_DummyBoss :

```
[Switch on String] AttackID
  ─── D1 ───
  "P1001" → JB_Pat_RectVertical
  "P1002" → JB_Pat_RectHorizontal
  "P1003" → JB_Pat_RingsChain
  "P1004" → JB_Pat_Wave
  "P1005" → JB_Pat_Cross
  ─── D2 ───
  "P2001" → JB_Pat_RectSnap
  "P2002" → JB_Pat_RectSpin
  "P2003" → JB_Pat_TrianglesRotatifs
  "P2004" → JB_Pat_Eventail
  "P2005" → JB_Pat_LignesAlternees
  "P2006" → JB_Pat_SpiraleLente
  "P2007" → JB_Pat_Moulin
  "P2008" → JB_Pat_Tourniquet
  "P2009" → JB_Pat_DoubleHelice
  ─── D3 ───
  "P3001" → JB_Pat_Ciseaux
  "P3002" → JB_Pat_DoubleSpirale
  "P3003" → JB_Pat_ParcoursMurs
  "P3004" → JB_Pat_Nebuleuse
  "P3005" → JB_Pat_SpiralSnap
  "P3006" → JB_Pat_EtoileConvergente
  "P3007" → JB_Pat_Mandala
  "P3008" → JB_Pat_FleurChaos
  "P3009" → JB_Pat_Engrenage
  "P3010" → JB_Pat_Pulsation
  "P3011" → JB_Pat_LabyrinteTournant
  ─── Missiles ───
  "M1001" → JB_Pat_M_Salve
  "M1002" → JB_Pat_M_Eventail
  "M2001" → JB_Pat_M_DoubleVague
  "M2002" → JB_Pat_M_Pinces
  "M2003" → JB_Pat_M_FauxProjectiles
  "M2004" → JB_Pat_M_SpiraleMissiles
  "M2005" → JB_Pat_M_Retardes
  "M3001" → JB_Pat_M_FauxMur
  "M3002" → JB_Pat_M_Deluge
  "M3004" → JB_Pat_M_FauxSalve
  ─── Uniques ───
  "U2001" → JB_Pat_Boomerang
  "U2002" → JB_Pat_Essaim
  "U3001" → JB_Pat_Pluie
  "U3002" → JB_Pat_Miroir
  "U3003" → [Print String] "U3003 Architecture Vivante — TODO"
  ─── Default ───
  Default → [Print String] "Pattern inconnu : " + AttackID
```

---

## G. Variables supplémentaires dans BP_JB_Projectile

Ce step nécessite deux nouvelles variables dans BP_JB_Projectile :

| Nom                | Type    | Défaut | Expose on Spawn | Rôle                      |
|--------------------|---------|--------|-----------------|---------------------------|
| `bMorphToMissile`  | Boolean | false  | oui             | M2003/M3001/M3004         |
| `MorphDist`        | Float   | 800.0  | oui             | Distance du morph (cm)    |
| `bBoomerang`       | Boolean | false  | oui             | U2001                     |
| `BoomerangDist`    | Float   | 1200.0 | oui             | Distance demi-tour (cm)   |

Et dans le **Tick** de BP_JB_Projectile, ajouter après la logique snap :

```
─── Morph to Missile ───
[Branch] bMorphToMissile AND NOT bBoomeranged AND DistDone >= MorphDist ?
  TRUE → [Spawn BP_JB_Missile] at Get Actor Location → [Destroy Actor]

─── Boomerang ───
[Branch] bBoomerang AND NOT bBoomeranged AND DistDone >= BoomerangDist ?
  TRUE →
    Set bBoomeranged = true
    [Set Velocity] ProjectileMovement.Velocity × -1.5
    [Set Vector Param "Color"] = (1,0.1,0.1) × 10
```

> **Note :** `bBoomeranged` est réutilisé comme flag générique "transformation déjà faite". Renommer en `bTransformed` si tu veux être propre.

---

## H. AttackPools recommandés

**Pool "Missiles découverte" :**
```
["M1001", "M1002", "P1001", "P1004"]
```

**Pool "Uniques découverte" :**
```
["U2001", "U3001", "P1003"]
```

**Pool "Build complet D2" :**
```
["P2002", "P2005", "P2008", "P2009", "M1001", "M2002"]
```

**Pool "Build complet D3" :**
```
["P3002", "P3003", "P3005", "P3007", "P3009", "M2003", "U2001"]
```

**Pool "Boss complet" (mix équilibré) :**
```
["P1002", "P1005", "P2001", "P2004", "P2007",
 "P3001", "P3006", "P3010",
 "M1001", "M2001", "M2002",
 "U2001", "U3001"]
```

---

## I. Checklist

Tester depuis F9 → Force Attack par ID :

**P2xxx :**
- ✅ P2002 : grille vrillée (chaque rangée légèrement décalée en angle)
- ✅ P2003 : 3 triangles à 90°, 0.8s entre chaque
- ✅ P2005 : ligne orange → 1.2s → ligne rouge décalée
- ✅ P2008 : 3 bras lents orange → 3 bras rapides rouges pivotés
- ✅ P2009 : double spirale CW+CCW → snap 45° à 1000cm

**P3xxx :**
- ✅ P3002 : double spirale sans snap (orange+rouge)
- ✅ P3003 : 3 murs avec trou alternant Gauche/Droite/Gauche
- ✅ P3004 : 20 proj depuis cercle de 10m autour du joueur
- ✅ P3005 : spirale violet → snap 90° à 1000cm
- ✅ P3007 : 3 anneaux animés → rafale convergente
- ✅ P3008 : 24 proj depuis 14m → snap 90° à 1200cm
- ✅ P3009 : 16 proj orange + 8 missiles révélés
- ✅ P3011 : murs visuels qui rétrécissent → rafale 18 proj

**Missiles :**
- ✅ M1001 : 3 missiles successifs (0.3s entre)
- ✅ M1002 : 5 missiles éventail 60°, tracking actif
- ✅ M2003 : 5 proj orange → morphent en missiles à 800cm
- ✅ Dash avec iframes → missiles ne hitent pas pendant les frames

**Uniques :**
- ✅ U2001 : 9 proj violets → demi-tour à 1200cm → rouge rapide retour
- ✅ U3001 : marqueurs au sol + proj depuis 15m au dessus (1.2s d'avertissement)

---

## J. Récap variables ajoutées à BP_JB_Projectile

Ce step étend BP_JB_Projectile avec 4 variables. Le Tick a maintenant 4 branches :

```
[Event Tick]
  1. Mort par distance (MaxDist)
  2. Snap (bSnap + bSnapped + SnapDist)
  3. Morph to Missile (bMorphToMissile + bBoomeranged + MorphDist)
  4. Boomerang (bBoomerang + bBoomeranged + BoomerangDist)
```

Ordre des branches : Mort → Snap → Morph → Boomerang (toutes en parallèle avec AND NOT flags).
