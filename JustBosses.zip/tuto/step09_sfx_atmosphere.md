# Step 09 — SFX / Atmosphère sonore

**Objectif :** Sons de combat, tells audio, feedback UI, ambiance arène. Utiliser les assets audio UE5 + Metasounds.
**Prérequis :** Step 08 ✓
**Blueprint only — aucun C++**

---

## A. Catalogue des sons nécessaires

| ID              | Événement                           | Style                         |
|-----------------|-------------------------------------|-------------------------------|
| SFX_BossAlert   | Tell avant attaque (0.3s avant)     | Buzz grave court              |
| SFX_PatternFire | Lancement d'un pattern              | Whoosh + impact sourd         |
| SFX_MissileFire | Lancement missile                   | Sifflement électrique         |
| SFX_ProjHitWall | Projectile boss touche un mur       | Pop court                     |
| SFX_PlayerHit   | Joueur prend des dégâts             | Impact + grunt                |
| SFX_IframeAbsorb| Dash absorbe un projectile          | Ding cristallin               |
| SFX_HPGain      | Gain de HP                          | Montée courte                 |
| SFX_ArmorGain   | Gain d'armure                       | Cliquetis métallique          |
| SFX_AmmoGain    | Gain munition spéciale              | Bip positif                   |
| SFX_WeakPointHit| Hit point faible                    | Impact résonnant fort         |
| SFX_BossPhase   | Transition de phase                 | Impact + silence + reprise    |
| SFX_PlayerDeath | Mort du joueur                      | Descente + silence            |
| SFX_PlayerShoot | Tir standard                        | Pew léger                     |
| SFX_SpecialShoot| Tir puissant                        | Boom + résonance              |
| SFX_AdminMenu   | Ouverture/fermeture menu admin      | Bip UI court                  |
| AMB_Arena       | Ambiance arène (loop)               | Bourdonnement électrique bas  |

---

## B. Sources audio recommandées (gratuites)

1. **Fab.com (Epic)** — chercher "sci-fi SFX pack", "bullet hell sounds", "UI sounds"
2. **freesound.org** — libre de droits, filtrer CC0
3. **Metasounds UE5** — générer des sons procéduraux directement dans l'éditeur (pas besoin de fichier externe)

> Pour le prototype : utiliser des sons Metasound générés (bruit blanc + filtre) plutôt que rien.

---

## C. Structure des dossiers audio

```
Content/
└── Audio/
    ├── SFX/
    │   ├── Boss/          (SFX_BossAlert, SFX_PatternFire, etc.)
    │   ├── Player/        (SFX_PlayerHit, SFX_PlayerShoot, etc.)
    │   └── UI/            (SFX_AdminMenu, SFX_HPGain, etc.)
    ├── Ambiance/
    │   └── AMB_Arena.wav  (loop)
    └── Metasounds/
        └── MS_IframeAbsorb (procédural)
```

---

## D. Intégration Blueprint

### D1 — Son de tell (BP_JB_DummyBoss, avant JB_FireAttack)

```
[JB_FireAttack]
  → [Play Sound at Location] Sound=SFX_BossAlert, Location=BossPos, Volume=1.0
  → (0.3s délai) → spawn les projectiles
```

### D2 — Son de tir joueur (BP_JB_Character)

```
[IA_Shoot → Triggered]
  → [Play Sound 2D] Sound=SFX_PlayerShoot
  → ... spawn projectile
```

### D3 — Son hit joueur (TakeDamage)

```
[TakeDamage]
  → [Play Sound 2D] Sound=SFX_PlayerHit
  → [Camera Shake] (small, 0.1s)
```

### D4 — Son iframe absorb

```
[IframeHitCache gain]
  → [Play Sound at Location] Sound=SFX_IframeAbsorb, Location=PlayerLocation
```

### D5 — Ambiance arène (BeginPlay level)

Placer un **Ambient Sound Actor** dans le niveau :
- Sound : AMB_Arena (loop)
- Volume : 0.3
- Attenuation : None (plein volume partout dans l'arène)

---

## E. Metasound — MS_IframeAbsorb (procédural)

> Metasound = synthétiseur procédural UE5. Pas besoin de fichier .wav.

`Content/Audio/Metasounds/` → clic droit → **Metasound Source**
Nommer : `MS_IframeAbsorb`

Nœuds dans l'éditeur Metasound :
```
[On Play]
  └─→ [Sine] Frequency=800Hz, Duration=0.15s
        └─→ × [ADSR] Attack=0.01s, Decay=0.1s, Sustain=0, Release=0.05s
              └─→ [Limiter]
                    └─→ [Output Mono]
```

> Résultat : ding cristallin court à 800Hz → feedback satisfaisant pour l'iframe.

---

## F. Test

- ✅ Attaque boss → buzz 0.3s avant + whoosh au tir
- ✅ Dash iframe → ding cristallin
- ✅ Prendre un dégât → grunt + camera shake
- ✅ Ambiance arène : bourdonnement discret en fond
- ✅ Menu admin F9 → bip UI

---

**Prochaine étape → Step 10 : Éclairage, texturing, city assets** (`step10_lighting_assets.md`)
