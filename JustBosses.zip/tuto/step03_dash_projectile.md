# Step 03 — Dash + Projectile joueur

**Objectif :** Dash avec iframes + préservation de vélocité + visuel configurable. Projectile joueur style Kosmos (sphère glowing, tire vers le curseur).
**Prérequis :** Step 02 ✓ — BP_JB_Character fonctionnel, IA_Dodge + IA_Shoot créés
**Blueprint only — aucun C++**

---

## A. Dash — mécanique complète

### Design acté
| Paramètre             | Valeur                                              |
|-----------------------|-----------------------------------------------------|
| Distance              | 200 cm (2 m)                                        |
| Direction             | Direction du mouvement ZQSD (pas la visée souris)   |
| Vitesse dash          | 1400 cm/s → durée ≈ 143ms                           |
| Iframes               | 100% de la durée du dash (du début à la fin)        |
| Velocité post-dash    | Vélocité pré-dash préservée (pas de freinage brutal)|
| Visuel (défaut)       | Semi-transparent pendant le dash (voir note admin)  |
| Cooldown              | 600ms depuis la fin du dash                       |

> **Velocity preservation** : si tu courais Nord à 600 cm/s avant le dash, après le dash tu repars à 600 cm/s vers le Nord. Pas de stop net. Feeling fluide, pas de "rubber band".

> **Note admin menu (futur)** : choix entre 3 visuels dash — Semi-transparent / Outline glow (style Kosmos) / Full invisible. À câbler dans le menu admin quand il sera créé.

- Dash sur touche shift

### Animation dash
-debut du dash arréter l'animation IMMEDIATEMENT avant le dash, reprendre l'animation IMMEDIATEMENT aprés le dash, pendant le dash, pour le moment comme Kosmos.

---

## B. Variables à ajouter dans BP_JB_Character

Ouvrir `BP_JB_Character` → onglet **My Blueprint** → section Variables → `+` :

| Nom                  | Type     | Défaut  | Rôle                                     |
|----------------------|----------|---------|------------------------------------------|
| `bIsDashing`         | Boolean  | false   | true pendant le dash                     |
| `bIsInvincible`      | Boolean  | false   | true = iframes actives                   |
| `DashDistance`       | Float    | 200.0   | Distance totale du dash (cm)             |
| `DashSpeed`          | Float    | 1400.0  | Vitesse du dash (cm/s)                   |
| `DashCooldown`       | Float    | 0.6     | Cooldown en secondes                     |
| `DashDistanceDone`   | Float    | 0.0     | Distance parcourue (interne)             |
| `PreDashVelocity`    | Vector   | (0,0,0) | Vélocité stockée avant le dash           |
| `DashDirection`      | Vector   | (0,0,0) | Direction normalisée du dash             |
| `LastDashTime`       | Float    | -999.0  | Timestamp du dernier dash (GetTimeSeconds)|

> Cocher **Instance Editable** sur DashDistance, DashSpeed, DashCooldown pour les modifier dans le viewport sans ouvrir le BP.

---

## C. Event Graph — Dash complet

### C1 — IA_Dodge : lancer le dash

```
[Enhanced Input Action IA_Dodge]  (Triggered)
  │
  ├─→ [Branch] Condition : bIsDashing == false
  │                        AND (GetTimeSeconds - LastDashTime) >= DashCooldown
  │
  │    TRUE →
  │      [Get Character Movement] → [Velocity] → [VSize2D]
  │        └─→ [Branch] Velocity > 10 ?  ← (le joueur bouge-t-il ?)
  │
  │              TRUE  → DashDirection = [Get Character Movement → Velocity] → [GetSafeNormal2D]
  │              FALSE → DashDirection = [Get Actor Forward Vector] → [GetSafeNormal2D]
  │                      (si immobile, dash vers la visée)
  │
  │      Stocker la vélocité pré-dash :
  │        [Get Character Movement] → [Velocity] → Set PreDashVelocity
  │
  │      Démarrer :
  │        Set bIsDashing = true
  │        Set bIsInvincible = true
  │        Set DashDistanceDone = 0.0
  │        Set LastDashTime = [GetTimeSeconds]
  │
  │      Visuel dash ON :
  │        [Get Mesh] → [Set Scalar Parameter Value on Materials]
  │          ├─ Parameter Name : "Opacity"
  │          └─ Value : 0.3   ← semi-transparent
  │
  └─ FALSE → (ignore)
```

---

### C2 — Event Tick : déplacement + fin du dash

```
[Event Tick]  (Delta Seconds)
  │
  └─→ [Branch] bIsDashing ?
        │
        TRUE →
          [Calculate Step]
            ├─ StepSize = DashSpeed × DeltaSeconds
            ├─ Remaining = DashDistance - DashDistanceDone
            └─ ActualStep = Min(StepSize, Remaining)
          │
          [Add Actor World Offset]
            ├─ Delta Location : DashDirection × ActualStep
            └─ Sweep : true  ← s'arrête sur les murs
          │
          DashDistanceDone += ActualStep
          │
          [Branch] DashDistanceDone >= DashDistance ?
            │
            TRUE → Fin du dash :
              Set bIsDashing = false
              Set bIsInvincible = false
              │
              Restaurer la vélocité pré-dash :
                [Get Character Movement]
                  └─→ [Launch Character]
                        ├─ LaunchVelocity : PreDashVelocity (XY only → Make Vector X,Y,0)
                        └─ bXYOverride : true
                        └─ bZOverride : false
              │
              Visuel dash OFF :
                [Get Mesh] → [Set Scalar Parameter Value on Materials]
                  ├─ Parameter Name : "Opacity"
                  └─ Value : 1.0
```

> **Make Vector XY only** : clic droit sur PreDashVelocity → Split Struct → brancher X et Y, Z = 0. On ne restaure pas la vélocité verticale (évite de projeter le joueur en l'air).

> **Sweep=true** sur Add Actor World Offset : le dash s'arrête proprement contre les murs de l'arène sans les traverser.

---

### C3 — Exclure le dash du mouvement normal

Pour éviter que CharacterMovement n'interfère pendant le dash, désactiver brièvement le movement mode :

Ajouter dans le nœud TRUE de C2 (début dash) :
```
[Get Character Movement] → [Set Movement Mode] → Mode : None
```

Ajouter dans le nœud TRUE de C2 (fin dash) :
```
[Get Character Movement] → [Set Movement Mode] → Mode : Walking
```

> Cela empêche le moteur de freiner le dash ou d'appliquer sa propre friction.

---

## D. Système de collision projectiles → iframes

Dans `BP_JB_PlayerProjectile` (créé section E) et dans les projectiles du boss :

```
[On Component Hit / On Component Begin Overlap]
  └─→ [Branch] Cast To BP_JB_Character → bIsInvincible ?
        TRUE  → ignore (projectile traverse)
        FALSE → appliquer les dégâts
```

> Pour les projectiles Niagara (GPU) → utiliser un collision volume sur le Character qui check `bIsInvincible` avant d'appliquer les dégâts.

- Systéme collision armes CAC ou PNJ/BOSS à prévoir

---

## E. BP_JB_PlayerProjectile — Projectile joueur

`Content/Blueprints/Projectiles/` → Blueprint Class → **Actor**
Nommer : `BP_JB_PlayerProjectile`

### E1 — Composants

| Composant               | Rôle                                              |
|-------------------------|---------------------------------------------------|
| `SphereCollision` (root)| Hitbox, radius = 8cm                              |
| `StaticMesh`            | Sphère (mesh Engine/BasicShapes/Sphere, Scale 0.08)|
| `ProjectileMovement`    | Déplacement automatique en ligne droite           |

> `ProjectileMovement` est un composant UE5 natif qui gère la trajectoire, la gravité, la vitesse — parfait pour les projectiles simples.

### E2 — Configurer ProjectileMovement

Sélectionner `ProjectileMovement` → Détails :

| Paramètre               | Valeur  |
|-------------------------|---------|
| Initial Speed           | `1800`  |
| Max Speed               | `1800`  |
| Gravity Scale           | `0.0`   |
| Projectile Lifetime     | `2.0`   |

### E3 — Material projectile (style Kosmos)

Créer `Content/Materials/M_PlayerProjectile` :
- Material Domain : **Surface**
- Blend Mode : **Additive**
- Shading Model : **Unlit**
- Nœuds :
  ```
  [Vector Parameter "Color"] (défaut : R=1.0, G=0.4, B=0.05) → × [Scalar Parameter "Intensity"] (défaut : 8.0) → Emissive Color
  ```

> **Additive + Emissive > 1.0** = bloom automatique si Post Process avec Bloom activé. Même rendu que les projectiles Kosmos (boules lumineuses avec halo).

Appliquer `M_PlayerProjectile` sur le StaticMesh Sphere.

### E4 — Event Graph BP_JB_PlayerProjectile

```
[Event BeginPlay]
  └─→ [Set Timer by Event] Duration=2.0 → [Destroy Actor]  ← backup si Lifetime rate

[On Component Begin Overlap] (SphereCollision)
  Other Actor →
    [Branch] Is Boss? (Cast to BP_JB_DummyBoss)
      TRUE  → appliquer dégâts au boss + [Destroy Actor]
      FALSE → [Destroy Actor] si mur (tag "Wall")
```

---

## F. Tir dans BP_JB_Character

### F1 — Variable de tir

| Nom               | Type  | Défaut | Rôle                        |
|-------------------|-------|--------|-----------------------------|
| `FireRate`        | Float | 0.10   | Délai min entre deux tirs (s)|
| `LastFireTime`    | Float | -999.0 | Timestamp dernier tir        |

### F2 — IA_Shoot dans l'Event Graph

```
[Enhanced Input Action IA_Shoot]  (Triggered = maintien clic gauche = tir auto)
  │
  └─→ [Branch] (GetTimeSeconds - LastFireTime) >= FireRate ?
        │
        TRUE →
          Set LastFireTime = GetTimeSeconds
          │
          [Get Actor Location] → SpawnLocation
            └─→ + offset [Get Actor Forward Vector × 80] ← spawn devant le perso
          │
          [Get Actor Rotation] → SpawnRotation  ← le perso regarde vers la souris (étape G4 step02)
          │
          [Spawn Actor BP_JB_PlayerProjectile]
            ├─ Class : BP_JB_PlayerProjectile
            ├─ Location : SpawnLocation
            └─ Rotation : SpawnRotation
```

> Le tir est automatique au maintien (Triggered fires chaque frame où la touche est tenue). `FireRate` limite la cadence.
> La direction est la rotation de l'Actor, qui pointe vers le curseur souris — pas besoin de recalculer.

---

## G. Résumé des fichiers créés

```
Content/
├── Blueprints/
│   ├── Character/
│   │   └── BP_JB_Character.uasset    ← modifié : dash + tir
│   └── Projectiles/
│       └── BP_JB_PlayerProjectile.uasset
└── Materials/
    └── M_PlayerProjectile.uasset
```

---

## H. Test

`Alt+P` :
- ✅ Espace → dash 2m dans la direction du mouvement, semi-transparent pendant le dash
- ✅ Après le dash, le personnage reprend la vélocité d'avant (pas de stop net)
- ✅ Cooldown 600ms entre deux dashs
- ✅ Clic gauche (maintenu) → tir automatique de boules orange lumineuses vers le curseur
- ✅ Projectiles détruits après 2s ou au contact d'un mur

---

## I. Note admin menu (futur step)

Visuels dash à câbler dans le menu admin :
- `0.3 opacity` → **Semi-transparent** (défaut actuel)
- `SetRenderCustomDepth(true)` + stencil → **Outline glow** (style Kosmos)
- `SetVisibility(false)` → **Full invisible**

Exposer via variable `DashVisualMode` (Enum : SemiTransparent / OutlineGlow / Invisible).

---

**Prochaine étape → Step 04 : Menu Admin UMG (WBP_JB_AdminMenu)** (`step04_admin_menu.md`)
