# Step 06 — Moteur de patterns (playtest track)

**Objectif :** BP_JB_Projectile fonctionnel + P1001→P1005 + collision iframes. À la fin de ce step, le gameplay core est playtestable.
**Prérequis :** Step 05 ✓ — Dummy boss spawn/despawn via menu admin F9, JB_FireAttack placeholder
**Blueprint only — aucun C++**

> Menu admin déjà en place → tester les patterns directement depuis F9 (force attack, changer pool).

---

## CHEMIN PLAYTEST MINIMAL
```
Step 02 → Arena + mouvement joueur
Step 03 → Dash + iframes + tir joueur
Step 04 → Menu Admin (F9 — spawn/despawn boss, force attack)
Step 05 → Dummy Boss boucle des attaques
Step 06 → Boss tire de vrais projectiles → PLAYTEST ← tu es ici
```

---

## A. M_Projectile — material commun

`Content/Materials/` → Material
Nommer : `M_Projectile`

```
Domain       : Surface
Blend Mode   : Additive
Shading Model: Unlit

[Vector Parameter "Color"]   default (R=1.0, G=0.4, B=0.05, A=1)
  └─→ × [Scalar Parameter "Intensity"]  default 8.0
            └─→ Emissive Color
```

> Additive + valeurs > 1.0 = bloom automatique si Post Process actif (il l'est par défaut en UE5).

---

## B. BP_JB_Projectile — acteur de base

`Content/Blueprints/Projectiles/` → Blueprint Class → **Actor**
Nommer : `BP_JB_Projectile`

### B1 — Composants

| Composant               | Rôle                                    |
|-------------------------|-----------------------------------------|
| `SphereCollision` (root)| Hitbox joueur                           |
| `StaticMesh`            | Sphere Engine/BasicShapes/Sphere        |
| `ProjectileMovement`    | Déplacement automatique                 |

**SphereCollision :**
- Sphere Radius : `20`
- Collision Preset : **OverlapAllDynamic**

**ProjectileMovement :**
- Gravity Scale : `0`
- Projectile Lifetime : `4.0` (fallback — on gère MaxDist manuellement)

### B2 — Variables

| Nom           | Type         | Défaut             | Instance | Rôle                        |
|---------------|--------------|--------------------|----------|-----------------------------|
| `Speed`       | Float        | 700.0              | oui      | cm/s                        |
| `ProjSize`    | Float        | 30.0               | oui      | Rayon visuel (cm)           |
| `Damage`      | Float        | 20.0               | oui      | Dégâts sur le joueur        |
| `MaxDist`     | Float        | 3500.0             | oui      | Distance de vie (cm)        |
| `ProjColor`   | LinearColor  | (1.0, 0.4, 0.05, 1)| oui      | Couleur Emissive (HDR)      |
| `Intensity`   | Float        | 8.0                | oui      | Multiplicateur bloom        |
| `bSnap`       | Boolean      | false              | oui      | Active le snap              |
| `SnapDist`    | Float        | 1000.0             | oui      | Distance déclenchement (cm) |
| `SnapAngle`   | Float        | 45.0               | oui      | Rotation du snap (degrés)   |
| `SnapMult`    | Float        | 1.5                | oui      | Multiplicateur vitesse snap |
| `SpawnLoc`    | Vector       | (0,0,0)            | non      | Mémorisé au BeginPlay       |
| `bSnapped`    | Boolean      | false              | non      | Snap déjà effectué          |
| `MatInst`     | MaterialInstanceDynamic | — | non    | Instance material           |

---

### B3 — Event BeginPlay

```
[Event BeginPlay]
  │
  ├─ Mémoriser position :
  │    [Get Actor Location] → Set SpawnLoc
  │
  ├─ Appliquer taille hitbox :
  │    [Get SphereCollision] → [Set Sphere Radius] = ProjSize
  │
  ├─ Appliquer taille mesh :
  │    [Get StaticMesh] → [Set World Scale 3D]
  │      Scale = Make Vector(ProjSize/50, ProjSize/50, ProjSize/50)
  │      (sphere par défaut = 100cm diamètre → /50 pour obtenir le rayon voulu)
  │
  ├─ Material dynamique :
  │    [Create Dynamic Material Instance]
  │      Parent : M_Projectile
  │      → Set MatInst
  │      → [Set Vector Parameter Value] Name="Color", Value=(ProjColor × Intensity)
  │
  └─ Configurer ProjectileMovement :
       [Get ProjectileMovement]
         → Set Initial Speed = Speed
         → Set Max Speed = Speed
```

> **Pourquoi pas Set Lifetime ici ?** On gère la mort par MaxDist dans le Tick — plus précis.

---

### B4 — Event Tick — mort par distance + snap

```
[Event Tick]
  │
  ├─ Mort par distance :
  │    [VSize] (Get Actor Location - SpawnLoc) → DistDone
  │    [Branch] DistDone >= MaxDist ?
  │      TRUE → [Destroy Actor]
  │
  └─ Snap (seulement si bSnap=true et pas encore snappé) :
       [Branch] bSnap AND NOT bSnapped AND DistDone >= SnapDist ?
         TRUE →
           Set bSnapped = true
           [Get ProjectileMovement → Velocity] → CurVel
           [Find Look at Rotation] From=(0,0,0) To=CurVel → CurRot (Rotator)
           │
           [Make Rotator] (Pitch=0, Yaw=CurRot.Yaw + SnapAngle, Roll=0) → NewRot
           [Get Forward Vector] NewRot → NewDir
           [Set Velocity] NewDir × (Speed × SnapMult)  sur ProjectileMovement
           │
           Changer couleur → violet (signal snap) :
             [Set Vector Parameter Value] "Color" = (6.7, 2.0, 10.0)
             ← (0.67 × 10, 0.2 × 10, 1.0 × 10 = violet HDR intense)
```

---

### B5 — OnComponentBeginOverlap — collision joueur

```
[OnComponentBeginOverlap] (SphereCollision)
  OtherActor →
    [Cast to BP_JB_Character]
      SUCCESS →
        [Branch] BP_JB_Character.bIsInvincible ?
          TRUE  → (ignore — iframes actives)
          FALSE →
            HP joueur -= Damage    ← simple pour le playtest (step 08 = full system)
            [Print String] "HIT — " + Damage  ← debug visible en playtest
            [Destroy Actor]
        FAIL → (pas un joueur — ignorer)
```

> **HP minimal pour le playtest :** ajouter juste une variable `HP` (Float, défaut=100) dans BP_JB_Character. Pas besoin d'armure/SP/HUD pour l'instant.

---

## C. Couleurs rapides à mémoriser

| Usage           | ProjColor (R,G,B)     | Intensity |
|-----------------|-----------------------|-----------|
| Orange standard | (1.0, 0.4, 0.05)      | 8.0       |
| Rouge rapide    | (1.0, 0.1, 0.1)       | 8.0       |
| Violet snap     | (0.67, 0.2, 1.0)      | 10.0      |
| Bleu missile    | (0.1, 0.5, 1.0)       | 8.0       |

---

## D. Fonction helper dans BP_JB_DummyBoss — JB_SpawnProj

> Mutualisé : tous les patterns l'appellent.

Fonction `JB_SpawnProj` dans BP_JB_DummyBoss :

**Inputs :**
| Param         | Type        |
|---------------|-------------|
| SpawnPos      | Vector      |
| Direction     | Vector      |
| Speed         | Float       |
| Size          | Float       |
| Damage        | Float       |
| MaxDist       | Float       |
| Color         | LinearColor |
| Intensity     | Float       |
| bSnap         | Boolean     |
| SnapDist      | Float       |
| SnapAngle     | Float       |
| SnapMult      | Float       |

```
[Spawn Actor From Class] BP_JB_Projectile
  Location : SpawnPos
  Rotation : [Rotation from X Vector] Direction
  → Récupérer la référence spawned
  → Set Speed, ProjSize, Damage, MaxDist, ProjColor, Intensity,
    bSnap, SnapDist, SnapAngle, SnapMult  sur la référence
```

> **Important :** les variables doivent être set AVANT que BeginPlay ait appliqué les valeurs. En UE5, SpawnActor avec `Expose on Spawn = true` sur les variables permet ça directement dans le nœud Spawn. Cocher **Expose on Spawn** sur toutes les variables de BP_JB_Projectile pour éviter les race conditions.

---

## E. Les 5 patterns D1 dans BP_JB_DummyBoss

> Ajouter une fonction par pattern. JB_FireAttack switche dessus.

### Pré-calcul commun à tous les patterns

```
Direction  = Normalize(LiveTargetLocation - Get Actor Location)
PerpRight  = Cross(Direction, (0,0,1))   ← axe horizontal perpendiculaire à la direction
BossPos    = Get Actor Location
```

> **Cross product tip :** nœud BP = "Cross Product" (Vector × Vector). Si Direction=(1,0,0) → PerpRight=(0,1,0). Si Direction=(0,1,0) → PerpRight=(-1,0,0). Toujours perpendiculaire.

---

### E1 — P1001 : Rect Vertical (4 cols × 8 rows, orange)

```
[Function JB_Pat_RectVertical(BossPos)]
  (pré-calcul Direction + PerpRight)

  For ColIdx = 0 to 3
    For RowIdx = 0 to 7
      OffsetH = (ColIdx - 1.5) × 120      ← -180, -60, +60, +180 cm
      OffsetV = (RowIdx - 3.5) × 100      ← -350 à +350 cm (Z)
      SpawnPos = BossPos
                 + (PerpRight × OffsetH)
                 + Make Vector(0, 0, OffsetV)
      JB_SpawnProj(SpawnPos, Direction,
        Speed=800, Size=30, Damage=20, MaxDist=3500,
        Color=(1,0.4,0.05), Intensity=8, bSnap=false, ...)
```

---

### E2 — P1002 : Rect Horizontal (8 cols × 3 rows, rouge)

```
For ColIdx = 0 to 7
  For RowIdx = 0 to 2
    OffsetH = (ColIdx - 3.5) × 120
    OffsetV = (RowIdx - 1.0) × 100
    SpawnPos = BossPos + (PerpRight × OffsetH) + (0,0,OffsetV)
    JB_SpawnProj(..., Color=(1,0.1,0.1), Intensity=8, ...)
```

---

### E3 — P1003 : Rings Chain (10 anneaux successifs, violet)

> Un anneau toutes les 0.4s — utilise des timers récursifs.

```
[Function JB_Pat_RingsChain(BossPos)]
  For RingIdx = 0 to 9
    [Set Timer by Function Name]
      Function Name : "SpawnRing"
      Time : RingIdx × 0.4
      (passer RingIdx via une variable temporaire — ou utiliser un Event avec paramètre)
```

> **Alternative plus propre en BP :** Sequence node + Delay nodes enchaînés pour 10 anneaux. Ou une variable compteur `RingCount` + Custom Event récursif avec délai.

**Méthode compteur (recommandée) :**
```
[Variable] RingCount (Integer, non-instance)

[Custom Event] SpawnNextRing
  [Branch] RingCount >= 10 ? → TRUE = return, FALSE → continue
  │
  (calculer Direction + PerpRight depuis BossPos)
  For i = 0 to 15  ← 16 proj par anneau
    AngleDeg = i × 22.5     (360 / 16)
    OffsetH = Cos(AngleDeg°) × 300
    OffsetV = Sin(AngleDeg°) × 300
    SpawnPos = BossPos + (PerpRight × OffsetH) + (0,0,OffsetV)
    JB_SpawnProj(SpawnPos, Direction, Speed=700, Size=30, ..., Color=(0.67,0.2,1.0), Intensity=10)
  │
  RingCount += 1
  [Set Timer by Event] Time=0.4 → SpawnNextRing

[Function JB_Pat_RingsChain]
  Set RingCount = 0
  Call SpawnNextRing
```

---

### E4 — P1004 : Wave sinusoïdale (16 proj, orange)

```
For i = 0 to 15
  OffsetH = (i - 7.5) × 80                      ← -600 à +600 cm
  OffsetV = Sin(i × 2.0 × Pi / 16) × 250        ← onde sinusoïdale (amplitude 250cm)
  SpawnPos = BossPos + (PerpRight × OffsetH) + (0,0,OffsetV)
  JB_SpawnProj(SpawnPos, Direction, Speed=700, ...)
```

> **Sin en BP :** nœud "Sin (Radians)". Convertir degrés → radians : × Pi / 180. Ou utiliser le nœud "Sin (Degrees)" directement si disponible.

---

### E5 — P1005 : Croix (4 bras, orange)

```
ArmDirections = [
  Get Actor Forward Vector,
  -Get Actor Forward Vector,
  Get Actor Right Vector,
  -Get Actor Right Vector
]

For each ArmDir in ArmDirections
  For j = 1 to 6
    SpawnPos = BossPos + (ArmDir × j × 120)
    JB_SpawnProj(SpawnPos, ArmDir, Speed=700, ...)
```

---

### E6 — JB_FireAttack (switch complet)

```
[Function JB_FireAttack(AttackID, BossPos)]
  [Switch on String] AttackID
    "P1001" → JB_Pat_RectVertical(BossPos)
    "P1002" → JB_Pat_RectHorizontal(BossPos)
    "P1003" → JB_Pat_RingsChain(BossPos)
    "P1004" → JB_Pat_Wave(BossPos)
    "P1005" → JB_Pat_Cross(BossPos)
    "P2001" → JB_Pat_RectSnap(BossPos)
    "P2004" → JB_Pat_Eventail(BossPos)
    "P2006" → JB_Pat_SpiraleLente(BossPos)
    "P2007" → JB_Pat_Moulin(BossPos)
    "P3001" → JB_Pat_Ciseaux(BossPos)
    "P3006" → JB_Pat_EtoileConvergente(BossPos)
    "P3010" → JB_Pat_Pulsation(BossPos)
    Default → [Print String] "Pattern inconnu : " + AttackID
```

---

## E7 — Patterns Moyens (P2xxx)

> Mêmes outils que P1xxx. Ajouter ces fonctions dans BP_JB_DummyBoss.

### P2001 — Rect Vertical Snap (grille + snap à mi-chemin)

> P1001 déguisé. Le joueur pense connaître le pattern → surprise à mi-chemin.

```
[Function JB_Pat_RectSnap(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  PerpRight = Cross(Direction, (0,0,1))

  For ColIdx = 0 to 3
    For RowIdx = 0 to 7
      OffsetH = (ColIdx - 1.5) × 120
      OffsetV = (RowIdx - 3.5) × 100
      SpawnPos = BossPos + (PerpRight × OffsetH) + (0,0,OffsetV)
      JB_SpawnProj(SpawnPos, Direction,
        Speed=750, Size=30, Damage=20, MaxDist=3500,
        Color=(0.67,0.2,1.0), Intensity=10,
        bSnap=true, SnapDist=1200, SnapAngle=30, SnapMult=1.4)
```

> Violet dès le départ → indique que c'est un snap. Snap à 1200cm, angle +30° → déviation vers la droite du joueur.

---

### P2004 — Éventail (7 proj, spread 60°)

> Fan spread classique. Le joueur peut passer sur les côtés ou à travers avec un dash précis.

```
[Function JB_Pat_Eventail(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  BaseRot = [Rotation from X Vector] Direction

  For i = 0 to 6
    YawOffset = (i - 3) × 10          ← -30°, -20°, -10°, 0°, +10°, +20°, +30°
    ShotRot = Make Rotator(0, BaseRot.Yaw + YawOffset, 0)
    ShotDir = [Get Forward Vector] ShotRot
    JB_SpawnProj(BossPos, ShotDir,
      Speed=950, Size=35, Damage=20, MaxDist=4000,
      Color=(1,0.1,0.1), Intensity=8,
      bSnap=false, ...)
```

> Éventail = couvre 60° → force le dash en dehors du cône. Vitesse haute = réaction rapide requise.

---

### P2006 — Spirale Lente (36 proj, 360°, timer loop)

> 1 proj toutes les 80ms, rotation de 10° à chaque tir. Crée une spirale expansive sur ~3s.

```
Variables dans BP_JB_DummyBoss :
  SpiralAngle (Float, non-instance)
  SpiralCount (Integer, non-instance)

[Custom Event] JB_SpawnSpiralProj
  [Branch] SpiralCount >= 36 ? → TRUE = return (fin)
  │
  Direction = Normalize(LiveTargetLocation - BossPos)
  BaseRot   = [Rotation from X Vector] Direction
  ShotRot   = Make Rotator(0, BaseRot.Yaw + SpiralAngle, 0)
  ShotDir   = [Get Forward Vector] ShotRot
  JB_SpawnProj(BossPos, ShotDir,
    Speed=600, Size=30, Damage=20, MaxDist=3500,
    Color=(1,0.4,0.05), Intensity=8, bSnap=false, ...)
  │
  SpiralAngle += 10
  SpiralCount += 1
  [Set Timer by Event] 0.08s → JB_SpawnSpiralProj

[Function JB_Pat_SpiraleLente(BossPos)]
  Set SpiralAngle = 0
  Set SpiralCount = 0
  Call JB_SpawnSpiralProj
```

> 36 proj × 10° = 360° couverts. Durée totale : ~2.9s. Speed=600 = slow → pattern "lisible mais envahissant".
> Le joueur doit se déplacer en cercle ou passer à travers les gaps.

---

### P2007 — Moulin (4 bras, 5 proj chacun)

> 4 bras disposés à 90° l'un de l'autre. Plus compact que la Croix, axes rotatifs par rapport à la direction joueur.

```
[Function JB_Pat_Moulin(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  BaseRot   = [Rotation from X Vector] Direction

  For ArmIdx = 0 to 3
    ArmYaw = ArmIdx × 90              ← 0°, 90°, 180°, 270°
    ArmRot = Make Rotator(0, BaseRot.Yaw + ArmYaw, 0)
    ArmDir = [Get Forward Vector] ArmRot

    For j = 1 to 5
      SpawnPos = BossPos + (ArmDir × j × 110)
      JB_SpawnProj(SpawnPos, ArmDir,
        Speed=800, Size=28, Damage=20, MaxDist=3500,
        Color=(1,0.4,0.05), Intensity=8, bSnap=false, ...)
```

> Différence avec P1005 (Croix) : les bras suivent la direction joueur + perpendiculaires.
> Donc le joueur ne peut pas "rester en face" du boss pour éviter 2 bras.

---

## E8 — Patterns Durs (P3xxx)

> Réflexes + lecture rapide + un dash bien placé. Ajouter seulement après avoir validé les P2xxx.

### P3001 — Ciseaux (2 murs obliques qui se croisent)

> Deux grilles 4×4 tirées à ±15° de la direction joueur. Les trajectoires se croisent → zone de convergence à éviter.

```
[Function JB_Pat_Ciseaux(BossPos)]
  Direction = Normalize(LiveTargetLocation - BossPos)
  BaseRot   = [Rotation from X Vector] Direction

  ─── Mur A — décalé -15° ───
  RotA  = Make Rotator(0, BaseRot.Yaw - 15, 0)
  DirA  = [Get Forward Vector] RotA
  PerpA = Cross(DirA, (0,0,1))
  For ColIdx = 0 to 3
    For RowIdx = 0 to 3
      OffsetH = (ColIdx - 1.5) × 150
      OffsetV = (RowIdx - 1.5) × 120
      SpawnPos = BossPos + (PerpA × OffsetH) + (0,0,OffsetV)
      JB_SpawnProj(SpawnPos, DirA, Speed=900, Size=28, Damage=25,
        MaxDist=4000, Color=(1,0.1,0.1), Intensity=8, bSnap=false, ...)

  ─── Mur B — décalé +15° ───
  RotB  = Make Rotator(0, BaseRot.Yaw + 15, 0)
  DirB  = [Get Forward Vector] RotB
  PerpB = Cross(DirB, (0,0,1))
  For ColIdx = 0 to 3
    For RowIdx = 0 to 3
      OffsetH = (ColIdx - 1.5) × 150
      OffsetV = (RowIdx - 1.5) × 120
      SpawnPos = BossPos + (PerpB × OffsetH) + (0,0,OffsetV)
      JB_SpawnProj(SpawnPos, DirB, Speed=900, Size=28, Damage=25,
        MaxDist=4000, Color=(1,0.1,0.1), Intensity=8, bSnap=false, ...)
```

> 32 proj au total. Les deux fronts se croisent à ~2000cm du boss. Le joueur doit identifier l'angle et se placer dans un gap, ou passer en dash à travers un mur.

---

### P3006 — Étoile Convergente (8 proj depuis autour du joueur, tous sur lui)

> Le plus "paniquant" : les proj n'arrivent pas du boss, ils convergent depuis le pourtour du joueur.
> Iframes obligatoires → 1 dash = 1 survie.

```
[Function JB_Pat_EtoileConvergente(BossPos)]
  PlayerPos = [Get Actor Location] of BP_JB_Character

  For i = 0 to 7                        ← 8 projectiles
    SpawnAngle = i × 45                 ← répartis à 45° d'intervalle
    SpawnRadius = 700                   ← 7 mètres autour du joueur
    OffsetX = Cos(SpawnAngle°) × SpawnRadius
    OffsetY = Sin(SpawnAngle°) × SpawnRadius
    SpawnPos = PlayerPos + Make Vector(OffsetX, OffsetY, 0)
    │
    ← tous pointent VERS le joueur
    Direction = Normalize(PlayerPos - SpawnPos)
    JB_SpawnProj(SpawnPos, Direction,
      Speed=550, Size=40, Damage=25, MaxDist=1200,
      Color=(0.67,0.2,1.0), Intensity=12, bSnap=false, ...)
```

> MaxDist=1200 → ils meurent après avoir couvert 12m (= juste assez pour atteindre le centre).
> Speed=550 → le joueur a ~1.3s pour réagir.
> Dash hors du cercle → passe entre deux proj. Dash tardif → iframes.

---

### P3010 — Pulsation (6 anneaux rapides successifs)

> Variante dure de P1003 : anneaux plus rapides, moins d'écart, plus de proj par anneau.
> Joueur coincé entre deux anneaux consécutifs → doit dash à travers.

```
Variables :
  PulseCount (Integer, non-instance)

[Custom Event] JB_SpawnPulseRing
  [Branch] PulseCount >= 6 ? → TRUE = return
  │
  Direction = Normalize(LiveTargetLocation - BossPos)
  PerpRight = Cross(Direction, (0,0,1))

  For i = 0 to 19                       ← 20 proj par anneau (plus dense que P1003)
    Angle    = i × 18                   ← 360/20
    OffsetH  = Cos(Angle°) × 260
    OffsetV  = Sin(Angle°) × 260
    SpawnPos = BossPos + (PerpRight × OffsetH) + (0,0,OffsetV)
    JB_SpawnProj(SpawnPos, Direction,
      Speed=1000, Size=25, Damage=25, MaxDist=4000,
      Color=(1,0.1,0.1), Intensity=9, bSnap=false, ...)
  │
  PulseCount += 1
  [Set Timer by Event] 0.22s → JB_SpawnPulseRing

[Function JB_Pat_Pulsation(BossPos)]
  Set PulseCount = 0
  Call JB_SpawnPulseRing
```

> 6 anneaux × 0.22s = 1.3s de durée. Speed=1000 = ultra rapide.
> Espace entre deux anneaux consécutifs : ~220cm à 0.5s (très serré). 1 dash suffit s'il est bien timé.

---

## F. Configurer le AttackPool pour le playtest

Dans le viewport UE5, sélectionner l'instance de BP_JB_DummyBoss → Détails → AttackPool :

**Pool "Découverte" (facile — premier run) :**
```
["P1001", "P1002", "P1005"]
```

**Pool "Playtest standard" (tous les P1) :**
```
["P1001", "P1002", "P1003", "P1004", "P1005"]
```

**Pool "Moyen" (ajouter P2 après validation P1) :**
```
["P1001", "P1002", "P1004", "P2001", "P2004", "P2006", "P2007"]
```

**Pool "Intense" (mix P2 + P3 — build de test complet) :**
```
["P1002", "P1005", "P2001", "P2004", "P2007", "P3001", "P3006", "P3010"]
```

> Conseil : tester les P3 d'abord en isolation (pool = `["P3006"]`) pour calibrer le timing et le Damage avant de les mettre en rotation.

---

## G. HP minimal dans BP_JB_Character (pour sentir les dégâts)

Ajouter dans BP_JB_Character :
- Variable `HP` (Float, défaut=100, Instance Editable=non)

Dans `OnComponentBeginOverlap` de BP_JB_Projectile :
```
HP -= Damage
[Print String] "HP : " + HP
[Branch] HP <= 0 → [Print String] "MORT (respawn todo)"
```

C'est suffisant pour le playtest. Le système complet vient au step 08 (après playtest).

---

## H. Tell visuel (bonus — 5 min)

Dans `JB_FireAttack`, avant le spawn, ajouter un flash sur le boss :

```
[Get StaticMesh of Boss] → [Create Dynamic Material Instance]
  → [Set Scalar Parameter "Intensity"] = 20.0
  → [Set Timer] 0.3s → Reset Intensity = 3.0
```

> Optionnel mais améliore beaucoup la lisibilité des patterns pendant le playtest.

---

## I. Checklist playtest

`Alt+P` → F1 spawn boss → observer :

- ✅ P1001 : grille 4×8 boules orange se déplace vers toi
- ✅ Dash espace → tu traverses la grille (iframes = pas de hit)
- ✅ Rater le dash → "HIT — 20" + "HP : 80" dans Output Log
- ✅ P1002 : grille large rouge, force déplacement latéral
- ✅ P1005 : 4 bras depuis le boss, force sortie de la croix
- ✅ Le boss enchaîne les patterns avec 0.75s de pause
- ✅ Dash vers le boss → projectiles joueur touchent la sphère boss
- ✅ P1001 Snap (si bSnap=true) : projectiles changent de direction à mi-chemin

---

## J. Après le playtest — suite logique

Une fois le gameplay de base validé :

| Priorité | Step                                                         |
|----------|--------------------------------------------------------------|
| 1        | **Step 07** — Plus de patterns (P2xxx, P3xxx, missiles)      |
| 2        | **Step 08** — HP/Armor/Ammo + HUD complet                    |
| 3        | **Step 09** — SFX                                            |
| 4        | **Step 10** — Éclairage / city assets                        |
