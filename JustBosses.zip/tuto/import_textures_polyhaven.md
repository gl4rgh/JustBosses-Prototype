# Import textures PolyHaven → UE5

**Source :** `E:\JustBosses\SourceAssets\Textures\Catacombs\`
**12 sets PBR 2K PNG — CC0 (domaine public)**

---

## A. Structure des maps PBR

Chaque set contient 4 fichiers :

| Suffixe      | Contenu                              | Channel UE5         |
|--------------|--------------------------------------|---------------------|
| `_diff_2k`   | Albedo / Base Color (RGB)            | Base Color          |
| `_nor_dx_2k` | Normal Map DirectX (RG)              | Normal (flip Y=NON) |
| `_arm_2k`    | AO(R) + Roughness(G) + Metallic(B)   | ORM packed          |
| `_disp_2k`   | Displacement / Height (R)            | Displacement (optionnel) |

> UE5 utilise les normales **DirectX** par défaut → `nor_dx` est le bon fichier (pas `nor_gl`).

---

## B. Importer dans UE5 — procédure rapide

### B1 — Import en masse

1. Dans Content Browser → créer `Content/Materials/Catacombs/Textures/`
2. **Drag & Drop** tous les PNG depuis l'explorateur Windows vers ce dossier Content Browser
3. UE5 détecte automatiquement les types

### B2 — Régler les paramètres de chaque texture

> À faire une fois par type, pas pour chaque fichier individuellement.

**Pour `_diff_2k` (Base Color) :**
- `sRGB = true` (déjà par défaut)
- `Compression = BC7` (ou DXT5 si BC7 indisponible)

**Pour `_nor_dx_2k` (Normal Map) :**
- Double-cliquer la texture → `Texture Settings`
- `Texture Type = Normal Map` (change automatiquement la compression en BC5)
- `sRGB = false` ← **OBLIGATOIRE** sinon les normales sont fausses
- `Flip Green Channel = false` (on a le fichier DirectX, pas OpenGL)

**Pour `_arm_2k` (ORM packed) :**
- `sRGB = false` ← **OBLIGATOIRE**
- `Compression = BC4` ou `Masks`

**Pour `_disp_2k` (Displacement) :**
- `sRGB = false`
- `Compression = Grayscale` ou `BC4`
- Optionnel — utiliser seulement si tu actives le Tessellation/Displacement dans le material

---

## C. Créer un Material par set de texture

`Content/Materials/Catacombs/` → New Material → `M_Cave_[NomZone]`

### Graphe standard (copier-coller pour chaque set)

```
[Texture Sample] _diff   → Base Color

[Texture Sample] _nor_dx → [Normal Map node] → Normal

[Texture Sample] _arm    →
  R → [Multiply → Param "AO Intensity" 1.0] → AO
  G → Roughness
  B → Metallic

[Param "Tiling"] → [TexCoord] → dans tous les Texture Sample
  (défaut Tiling = 1.0 — augmenter si texture trop grande sur le mesh)
```

> **Astuce tiling :** Les murs de catacombes font ~2m×2.5m.
> Si la texture semble trop grande → Tiling = 2.0 ou 3.0.

---

## D. Mapping des sets par zone

| Set                    | Material à créer             | Utilisé sur              |
|------------------------|------------------------------|--------------------------|
| N1_Mur_Pierre_Brut     | `M_Cave_N1_Mur_A`           | Murs couloirs Niveau 1   |
| N1_Mur_Pierre_Brut_V2  | `M_Cave_N1_Mur_B`           | Variation murs N1        |
| N1_Mur_Calcaire        | `M_Cave_N1_Calcaire`        | Murs salle centrale N1   |
| N2_Mur_Pierre_Taille   | `M_Cave_N2_Mur_A`           | Murs galerie ossuaire    |
| N2_Mur_Pierre_Humide   | `M_Cave_N2_Mur_Humide`      | Murs zone eau N2         |
| N2_Grands_Blocs        | `M_Cave_N2_Blocs`           | Piliers salle sculptures |
| N3_Mur_Ancien          | `M_Cave_N3_Mur`             | Murs antichambre boss    |
| N3_Blocs_Boss_Arena    | `M_Cave_N3_Arena`           | Murs boss arena          |
| Sol_Pierre_General     | `M_Cave_Sol_A`              | Sol galeries N1/N2       |
| Sol_Couloir            | `M_Cave_Sol_Couloir`        | Sol couloirs étroits      |
| Sol_Ossuaire_Humide    | `M_Cave_Sol_Ossuaire`       | Sol N2 ossuaire           |
| Brique_Voute_Acces     | `M_Cave_Voute`              | Voûte galerie d'accès    |

---

## E. Material Instance — travailler plus vite

Créer **1 seul Material parent** `M_Cave_Master` avec des paramètres :

```
[Param "Diffuse Texture"]  → Base Color
[Param "Normal Texture"]   → Normal
[Param "ORM Texture"]      → AO / Roughness / Metallic
[Param "Tiling"]           → TexCoord UV Scale
[Param "AO Intensity"]     → 1.0
[Param "Roughness Mult"]   → 1.0
```

Ensuite créer des **Material Instances** pour chaque set → changer seulement les textures et le tiling.
→ **Beaucoup plus rapide** que de recréer le graphe 12 fois.

---

## F. Tester rapidement

1. Créer un BSP Box dans le niveau
2. Assigner `M_Cave_N1_Mur_A` dessus
3. Vérifier :
   - ✅ Texture visible + pas de noir/blanc pur = sRGB correct
   - ✅ Normales qui réagissent à la lumière = normal map OK
   - ✅ Roughness non-métallique (pierre = roughness élevé ~0.8-0.9)
4. Ajuster le Tiling si la texture est trop grande ou petite sur le mur
