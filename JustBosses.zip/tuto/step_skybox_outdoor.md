# Skybox & Volumetric Clouds — Niveaux Extérieurs UE5

> Référence à utiliser pendant step10 (lighting/texturing) pour les niveaux en extérieur.
> Setup complet : Sky Atmosphere + Volumetric Clouds + Sky Light, configurable par niveau.

---

## Terminologie UE5

| Terme commun | Acteur UE5 réel | Rôle |
|---|---|---|
| "Skybox" | `Sky Atmosphere` | Ciel physique (dégradé, horizon, diffusion) |
| "Soleil" | `Directional Light` (Atmosphere Sun) | Source lumière + position soleil |
| "Lumière ambiante ciel" | `Sky Light` (Real Time Capture) | Ambient light depuis le ciel |
| "Nuages" | `Volumetric Cloud` | Nuages 3D volumétriques |
| "Fond statique" | `HDRI Backdrop` | Image HDR en fond (alternative légère) |

> Il n'y a pas de mesh "skybox" à poser. Tout est procédural et basé sur des acteurs.

---

## PARTIE 1 — Setup minimal (obligatoire)

### Les 3 acteurs indispensables

Placer dans chaque level extérieur :

```
World Outliner :
├── BP_Sky_Sphere         ← optionnel, legacy — NE PAS utiliser si Sky Atmosphere actif
├── SkyAtmosphere         ← ciel physique
├── DirectionalLight      ← soleil (lié à SkyAtmosphere)
└── SkyLight              ← ambient
```

#### 1. SkyAtmosphere

`Place Actors → Sky Atmosphere`

Paramètres principaux :
| Param | Valeur recommandée | Effet |
|---|---|---|
| Rayleigh Scattering | default | Bleu du ciel |
| Mie Scattering | 0.01–0.1 | Brume/pollution |
| Aerial Perspective | ON | Profondeur atmosphérique |
| Art Direction | OFF pour PBR | ON pour style cartoon/saturé |

#### 2. DirectionalLight (soleil)

- `Atmosphere / Fog → Atmosphere Sun Light` = **true**
- `Cast Volumetric Shadow` = true (si nuages actifs)
- `Light Source Angle` = 0.5–2.0 (taille du soleil → pénombre douce)
- Rotation : angle X = position du soleil dans le ciel

#### 3. SkyLight

- Mode : **Real Time Capture** (recommandé pour Lumen)
- `Recapture Sky` = appelé automatiquement par Lumen
- Intensity : 1.0–2.0 selon ambiance

---

## PARTIE 2 — Volumetric Clouds

`Place Actors → Volumetric Cloud`

### Paramètres clés

| Param | Valeur | Notes |
|---|---|---|
| Layer Bottom Altitude | 5.0 km | Altitude bas des nuages |
| Layer Height | 8.0 km | Épaisseur couche nuages |
| Tracing Start Max Distance | 350 km | Distance de rendu max — **réduire à 100 km** pour perf |
| Shadow Tracing Distance | 15 km | Distance ombres nuages — **réduire à 10 km** |
| View Sample Count Scale | 1.0 | Qualité ray marching — **0.5 en mid-range** |

### Material nuages (personnaliser l'aspect)

Le material par défaut est `M_VolumetricCloud` (engine content).
Copier et modifier dans `Content/JustBosses/Sky/M_JB_Clouds_[NomNiveau]`

Paramètres exposés à modifier par niveau :
- **Cloud Coverage** (0.0 = ciel dégagé → 1.0 = couvert)
- **Cloud Density** (nuages légers vs épais/sombres)
- **Erosion Noise Scale** (détail des bords)
- **Albedo** (couleur base — blanc pur à gris orageux)

---

## PARTIE 3 — Setup par niveau

### Principe : Data Asset par niveau

Créer `Content/JustBosses/Sky/DA_SkyPresets`
Type : **Data Asset** (créer une struct `S_JB_SkyPreset` d'abord)

```
Struct S_JB_SkyPreset :
- PresetName (String)
- SunAngle (Rotator)          ← position du soleil
- SunIntensity (Float)         ← 0=nuit, 10=midi, 4=coucher
- SkyLightIntensity (Float)
- AtmosphereMieScattering (Float)  ← brume
- CloudCoverage (Float)        ← 0.0→1.0
- CloudAlbedo (LinearColor)    ← blanc/gris/orageux
- FogDensity (Float)           ← brouillard de distance
- AmbientColor (LinearColor)   ← teinte globale ambiance
```

### Presets suggérés

| Preset | SunAngle | Coverage | Albedo | Ambiance |
|---|---|---|---|---|
| `Dawn_Ruins` | -10° | 0.3 | Orange-rose | Aube sur ruines |
| `Midday_Clear` | -60° | 0.1 | Blanc | Combat en plein soleil |
| `Dusk_Battle` | -5° | 0.6 | Orange-rouge | Crépuscule dramatique |
| `Storm_Arena` | -30° | 0.9 | Gris foncé | Orage, ambiance boss |
| `Night_Forest` | 90° (lune) | 0.4 | Bleu-gris | Nuit claire |

### Blueprint : appliquer un preset au chargement du niveau

Dans le **Level Blueprint** du niveau :

```
Event BeginPlay
  → Get All Actors of Class (SkyAtmosphere) → Get(0) → ref SkyAtmo
  → Get All Actors of Class (DirectionalLight) → Get(0) → ref Sun
  → Get All Actors of Class (VolumetricCloud) → Get(0) → ref Clouds
  → Get All Actors of Class (SkyLight) → Get(0) → ref SkyL

  → Load preset depuis DA_SkyPresets (index ou Enum niveau)
  → Set DirectionalLight Rotation = SunAngle
  → Set Light Intensity = SunIntensity
  → Set SkyLight Intensity = SkyLightIntensity
  → Set Cloud Material Parameter "CloudCoverage" = Coverage
  → Set Cloud Material Parameter "Albedo" = CloudAlbedo
```

Ou plus simple : stocker les refs dans le **GameMode** et exposer une fonction `ApplySkyPreset(Name)`.

---

## PARTIE 4 — Transition dynamique (optionnel)

Pour une transition jour→soir pendant le combat :

```
Function TransitionSky(From Preset, To Preset, Duration Float)
  → Timeline (durée = Duration)
  → Lerp tous les paramètres From → To via Alpha
  → Update acteurs chaque frame (ou toutes les 0.1s si perf)
```

Utilisation : déclencher une transition à 50% HP boss par exemple.

---

## PARTIE 5 — HDRI Backdrop (alternative légère)

Si les Volumetric Clouds sont trop lourds sur mid-range ou si le niveau est semi-intérieur :

`Place Actors → HDRI Backdrop`

- Brancher une texture HDRI (`.hdr` ou `.exr`)
- Sources gratuites : **PolyHaven.com → HDRIs** (CC0)
- Taille mesh : ajuster `Size` pour couvrir l'arène sans être gigantesque
- Compatible avec Sky Light en mode Captured Scene

> Avantage : ~0.1ms GPU. Inconvénient : statique, pas de nuages animés.

---

## PARTIE 6 — Perf

### Coût estimé RTX 4080 1440p

| Composant | GPU | Notes |
|---|---|---|
| Sky Atmosphere | ~0.1ms | Négligeable |
| Sky Light RT Capture | ~0.5ms | 1x/frame avec Lumen |
| Volumetric Clouds standard | ~2–4ms | Variable selon couverture |
| Volumetric Clouds optimisé | ~1ms | Voir settings ci-dessous |
| HDRI Backdrop | ~0.1ms | Option légère |

### Réglages perf Volumetric Clouds

**Console variables à ajouter dans `DefaultEngine.ini` :**

```ini
[SystemSettings]
; Qualité ray marching nuages
r.VolumetricCloud.ViewRaySampleCountScale=0.5
; Distance rendu max réduite
r.VolumetricCloud.ShadowTracingDistance=10
; Temporal accumulation (smooth + perf)
r.VolumetricCloud.EnableAerialPerspectiveSampling=1
```

**En Blueprint (menu Options joueur) :**
```
"Nuages Haute Qualité" toggle →
  Execute Console Command "r.VolumetricCloud.ViewRaySampleCountScale 1.0"
  ou
  Execute Console Command "r.VolumetricCloud.ViewRaySampleCountScale 0.3"
```

### Règle simple

- Arène principale combat → Volumetric Clouds ok (budget 2ms acceptable)
- Zone de hub/transition → HDRI ou Sky Atmosphere seul (pas de nuages)
- Niveau souterrain/intérieur → désactiver SkyAtmosphere + VolumetricCloud complètement

---

## PARTIE 7 — Éclipse (soleil / lune modulables)

### Concept

L'éclipse = transition dynamique entre état Soleil et état Lune, avec un disque occulteur.
Peut servir de mécanique boss (déclencher une éclipse à un seuil HP = changement d'ambiance total).

### Acteurs à ajouter

```
├── DirectionalLight_Sun     ← lumière solaire (Atmosphere Sun Light = true)
├── DirectionalLight_Moon    ← lumière lunaire (Atmosphere Sun Light = false)
│     Intensity : 0.05–0.1 lux, couleur bleu-argent
├── BP_JB_SunDisc            ← mesh sphère billboard (le soleil visible)
└── BP_JB_MoonDisc           ← mesh sphère billboard (la lune visible)
```

### Material des disques

`Content/JustBosses/Sky/M_JB_SunDisc`
- Domain : Surface, Unlit
- Emissive : couleur HDR (>1.0 pour bloom naturel)
- Opacity Mask : cercle parfait (texture ou SDF dans material)
- `SunColor` param : blanc-jaune (soleil) ou blanc-bleu (lune)
- `SunIntensity` param : 8.0 (jour) → 0.3 (éclipse) → 2.0 (lune)

### Blueprint BP_JB_EclipseController

```
Variables :
- SunLight (DirectionalLight ref)
- MoonLight (DirectionalLight ref)
- SunDisc (StaticMesh ref)
- MoonDisc (StaticMesh ref)
- bEclipseActive (Bool)

Function TriggerEclipse(Duration Float) :
  → Timeline (Duration)
  → Alpha 0→1
  → Lerp SunLight Intensity : 10.0 → 0.0
  → Lerp MoonLight Intensity : 0.0 → 0.08
  → Lerp SkyLight Color : blanc → bleu nuit
  → Lerp SunDisc Emissive : blanc-jaune → rouge-orange (corona éclipse)
  → Set PostProcess : légère désaturation (Saturation 0.7)
  → Lerp FogDensity : 0.0 → 0.02 (brume lunaire)

Function RevertEclipse(Duration Float) :
  → Même chose en sens inverse
```

### Éclipse partielle (annulaire)

Pour un effet corona visible pendant l'éclipse :
- `SunDisc` mesh reste visible mais plus petit
- `MoonDisc` mesh aligné devant — légèrement plus grand
- Material `SunDisc` : anneau lumineux (mask = ring, pas cercle plein)
- Résultat : anneau de feu autour du disque sombre → très dramatique

### Intégration boss

```
BP_JB_BossController :
  OnHealthThreshold(50%) → EclipseController → TriggerEclipse(5.0)
  OnBossDeath          → EclipseController → RevertEclipse(10.0)
```

### Presets éclipse

| État | SunIntensity | MoonIntensity | SkyColor | FogDensity |
|---|---|---|---|---|
| Plein jour | 10.0 | 0.0 | Blanc-bleu | 0.0 |
| Éclipse partielle | 3.0 | 0.0 | Jaune-orangé | 0.01 |
| Éclipse totale | 0.0 | 0.08 | Bleu nuit | 0.03 |
| Clair de lune | 0.0 | 0.1 | Bleu-argent | 0.005 |

---

## Checklist par niveau extérieur

- [ ] SkyAtmosphere placé + Atmosphere Sun Light activé sur DirectionalLight
- [ ] SkyLight en Real Time Capture
- [ ] VolumetricCloud placé + material copié pour ce niveau
- [ ] Preset `S_JB_SkyPreset` défini pour ce niveau
- [ ] Level Blueprint → applique preset au BeginPlay
- [ ] Console vars perf ajoutées à DefaultEngine.ini
- [ ] Test mid-range : GPU < 11ms total avec le ciel actif
