# Step 02 — Arène style Algos (Returnal)

**Objectif :** Espace de jeu jouable — arène circulaire style Algos (Returnal), boss central massif sur socle surélevé (buste visible depuis le bord), personnage ZQSD + visée souris, caméra fixe boss-fight.
**Prérequis :** Projet ouvert dans UE5, AZERTY configuré (step 01 ✓)
**Blueprint only — aucun C++**

> **Style mouvement Returnal :**
> - ZQSD = déplacement dans les axes caméra (indépendant de la visée)
> - Souris = rotation du personnage (il regarde toujours vers le curseur)
> - Dash (step 03) = direction du mouvement ZQSD, iframes pendant toute la durée (2m)

---

## 0. Navigation viewport éditeur — ZQSD (AZERTY)

> **À faire en premier.** Par défaut UE5 utilise WASD pour la navigation fly dans les viewports (clic droit maintenu + touches). Sur AZERTY il faut remapper.

### Procédure

`Edit → Editor Preferences → General → Keyboard Shortcuts`

Dans le champ **Search** en haut : taper `Forward` (ou `viewport`).

Déplier la section **Level Editor - Viewport Navigation**.

#### Remappings à effectuer

Pour chaque action : cliquer sur le binding existant → appuyer sur la nouvelle touche → `OK`.

| Action         | Défaut (QWERTY) | Nouveau (AZERTY) |
|----------------|-----------------|------------------|
| Move Forward   | W               | **Z**            |
| Move Left      | A               | **Q**            |
| Move Backward  | S               | S *(inchangé)*   |
| Move Right     | D               | D *(inchangé)*   |
| Move Up        | E               | E *(inchangé)*   |
| Move Down      | **Q** ← conflit | **C**            |

> **Conflit Q :** Sur QWERTY, `Q` = Move Down. En remappant Move Left sur Q, il faut obligatoirement remap Move Down ailleurs. `C` est le choix le plus naturel (sous la main gauche, proche de ZQSD).

#### Raccourcis utiles en vol

| Action                  | Touche              |
|-------------------------|---------------------|
| Accélérer               | `Shift` maintenu    |
| Vitesse caméra          | Molette souris      |
| Orbiter autour d'un objet | `Alt + clic gauche` |
| Focus sur la sélection  | `F`                 |
| Zoom rapide             | `Alt + clic droit + drag` |

### Test

Clic droit maintenu dans un viewport 3D → ZQSD doit naviguer en forward/left/backward/right, C descend, E monte. Shift accélère.

---

## A. Structure de dossiers (Content Browser)

`Ctrl+Espace` pour ouvrir le Content Browser. Clic droit → New Folder :

```
Content/
├── Maps/
├── Blueprints/
│   ├── GameMode/
│   └── Character/
└── Input/
    ├── Actions/
    └── Contexts/
```

---

## B. Créer le niveau

`File → New Level → Empty Level`
`File → Save Current Level As...` → `Content/Maps/L_Arena_01`

---

## C. Géométrie BSP — Arène circulaire style Algos

> **Style de référence :** Algos (Returnal, final boss) — arène circulaire ouverte, boss central massif dont le buste est visible depuis l'extrémité de la plateforme.

Dans le viewport : onglet **Place Actors** (Shift+1) → catégorie **Geometry** → glisser les brushes.

> **UE5 unités** : 1 unité = 1 cm. 3000 units = 30 mètres.

> **BSP Cylinder vs Box :** Pour une arène circulaire, utiliser le brush **Cylinder** (pas Box). Place Actors → Geometry → Cylinder. Paramètres dans Brush Settings : `Outer Radius`, `Inner Radius`, `Z` (hauteur), `Sides` (nombre de facettes — 32 = bon équilibre).

### Sol circulaire (arène principale)

| Paramètre     | Valeur   |
|---------------|----------|
| Type          | Cylinder BSP |
| Outer Radius  | `3000`   |
| Inner Radius  | `0`      |
| Z (hauteur)   | `100`    |
| Sides         | `32`     |
| Position      | X=0, Y=0, Z=-50 |

→ Résultat : plateau circulaire de 60m de diamètre, 1m d'épaisseur.

### Garde-corps (anneau périphérique — remplace les murs 4m)

Un garde-corps bas **ne bloque pas la vue** sur le boss.

| Paramètre     | Valeur   |
|---------------|----------|
| Type          | Cylinder BSP (hollow) |
| Outer Radius  | `3120`   |
| Inner Radius  | `2980`   |
| Z (hauteur)   | `120`    |
| Sides         | `32`     |
| Position      | X=0, Y=0, Z=10 |

→ Barrière de 1.2m de haut — le joueur ne tombe pas, la vue sur le boss est dégagée.

> Pour un Cylinder hollow en BSP : dans Brush Settings, `Inner Radius` > 0 crée l'anneau creux.

### Socle boss (centre, très surélevé)

Le boss doit être assez haut pour que son buste soit visible depuis le bord de l'arène (caméra -35°, Spring Arm 1400cm).

| Paramètre     | Valeur   |
|---------------|----------|
| Type          | Cylinder BSP |
| Outer Radius  | `700`    |
| Inner Radius  | `0`      |
| Z (hauteur)   | `300`    |
| Sides         | `16`     |
| Position      | X=0, Y=0, Z=150 |

→ Plateforme de 14m de diamètre, 3m de hauteur. Le boss spawn au sommet (Z=300). Avec la caméra à 1400cm/−35°, son buste est visible depuis le bord à 30m.

> **Vérification :** placer un cube 200cm de haut au centre du socle → Alt+P → se déplacer jusqu'au bord du sol → le cube doit rester visible. Ajuster Z du socle si besoin.

---

## D. Éclairage minimal

Place Actors → **Lights** :
1. **Directional Light** — laisser les valeurs par défaut, Intensity 10
2. **Sky Light** — cocher **Real Time Capture** dans les Détails

`Build → Build Lighting Only` si des warnings apparaissent (optionnel à ce stade).

---

## E. Input Actions (Enhanced Input)

### Créer les Input Actions

Dans `Content/Input/Actions/`, clic droit → **Input → Input Action** :

| Fichier       | Value Type            | Rôle                          |
|---------------|-----------------------|-------------------------------|
| `IA_Move`     | **Axis2D (Vector2D)** | Déplacement ZQSD              |
| `IA_Dodge`    | **Digital (bool)**    | Dash — touche Espace          |
| `IA_Shoot`    | **Digital (bool)**    | Tir — Clic gauche souris      |

### Créer l'Input Mapping Context (IMC)

Dans `Content/Input/Contexts/`, clic droit → **Input → Input Mapping Context**
Nommer : `IMC_JB_Default`

Ouvrir `IMC_JB_Default` :

**IA_Move** → ajouter 4 mappings :

| Touche | Modifier              | Résultat        |
|--------|-----------------------|-----------------|
| Z      | *(aucun)*             | Avant (Y+)      |
| S      | **Negate**            | Arrière (Y-)    |
| Q      | **Swizzle YXZ**       | Gauche (X-)     |
| D      | **Swizzle YXZ** + **Negate** | Droite (X+) |

> **Swizzle YXZ** : transforme la valeur axe Y → axe X (pour les déplacements latéraux).

**IA_Dodge** → 1 mapping :
| Touche  | Modifier |
|---------|----------|
| Space   | *(aucun)* |

**IA_Shoot** → 1 mapping :
| Touche           | Modifier |
|------------------|----------|
| Left Mouse Button | *(aucun)* |

---

## F. BP_JB_GameMode

`Content/Blueprints/GameMode/` → clic droit → **Blueprint Class** → `Game Mode Base`
Nommer : `BP_JB_GameMode`

Ouvrir → dans les **Defaults** du panneau Details :
- **Default Pawn Class** : `BP_JB_Character` *(on le créera juste après)*
- Laisser tout le reste par défaut

---

## G. BP_JB_Character

`Content/Blueprints/Character/` → clic droit → **Blueprint Class** → `Character`
Nommer : `BP_JB_Character`

### G1 — Composants (onglet Components)

Vérifier que ces composants sont présents (ils sont là par défaut sur un Character) :
- `CapsuleComponent` (root)
- `Arrow`
- `Mesh` (SkeletalMesh — on l'ignorera pour l'instant, pas de modèle)
- `CharacterMovement`

Ajouter manuellement :
- **Spring Arm** (clic `+ Add` → chercher "Spring Arm") → l'attacher à `CapsuleComponent`
- **Camera** → l'attacher au **Spring Arm**

### G2 — Configurer le Spring Arm

Sélectionner `Spring Arm` dans les composants → Détails :

| Paramètre                        | Valeur       |
|----------------------------------|--------------|
| Target Arm Length                | `1400`       |
| Socket Offset Z                  | `100`        |
| Inherit Pitch                    | **décoché**  |
| Inherit Yaw                      | décoché      |
| Inherit Roll                     | décoché      |
| Use Pawn Control Rotation        | **décoché**  |
| Rotation (Pitch)                 | `-35`        |

> Caméra fixe, angle boss-fight. Pas de rotation à la souris pour l'instant.

### G3 — Configurer le Character Movement

Sélectionner `CharacterMovement` → Détails :
| Paramètre                       | Valeur     |
|---------------------------------|------------|
| Max Walk Speed                  | `600`      |
| Orient Rotation to Movement     | **décoché** |
| Use Controller Desired Rotation | décoché    |

Dans les **Class Defaults** du personnage :
- `Use Controller Rotation Yaw` → **décoché**
- `Use Controller Rotation Pitch` → décoché
- `Use Controller Rotation Roll` → décoché

> Le perso NE tourne PAS avec le mouvement. La rotation est gérée manuellement via la souris (voir G4 Nœud 3).

### G4 — Event Graph : mouvement + visée souris + input

Ouvrir l'**Event Graph** de `BP_JB_Character` :

---

**Nœud 1 — Ajouter le contexte d'input au démarrage :**
```
Event BeginPlay
  └─→ [Get Player Controller]
        └─→ [Get Enhanced Input Local Player Subsystem]
              └─→ [Add Mapping Context]
                    ├─ Context : IMC_JB_Default
                    └─ Priority : 0
```

---

**Nœud 2 — Mouvement (relatif à la caméra) :**

> Mouvement relatif à la caméra = si on ajoute plus tard une rotation caméra, ZQSD suit. Meilleure pratique que de prendre les axes monde.

```
[Enhanced Input Action IA_Move]
  Action Value → Split Struct Pin → X (droite/gauche), Y (avant/arrière)
    │
    ├─→ [Get Player Camera Manager]
    │     └─→ [Get Camera Rotation]
    │           └─→ [Break Rotator] → Yaw uniquement
    │                 └─→ [Make Rotator] (Pitch=0, Yaw=Yaw, Roll=0)
    │                       ├─→ [Get Forward Vector] → [Add Movement Input] Scale = Y
    │                       └─→ [Get Right Vector]   → [Add Movement Input] Scale = X
    └─ (les deux Add Movement Input se branchent au même Make Rotator)
```

> **Split Struct Pin** : clic droit sur le pin `Action Value` → "Split Struct Pin".
> On prend uniquement le **Yaw** de la caméra (projette le mouvement sur le plan horizontal — pas d'effet du pitch caméra sur le déplacement).

---

**Nœud 3 — Visée souris (rotation du personnage vers le curseur) :**

> Chaque tick, on projette le curseur souris sur le sol → le personnage regarde ce point.

```
Event Tick
  └─→ [Get Player Controller]
        └─→ [Get Hit Result Under Cursor by Channel]
              ├─ Trace Channel : Visibility
              ├─ bTraceComplex : false
              │
              └─ (Exécution) bBlockingHit?
                    TRUE →
                      [Break Hit Result] → Impact Point (Vector)
                        └─→ [Find Look at Rotation]
                              ├─ From : [Get Actor Location]
                              └─ To   : Impact Point
                                    └─→ [Break Rotator] → Yaw uniquement
                                          └─→ [Make Rotator] (Pitch=0, Yaw=Yaw, Roll=0)
                                                └─→ [Set Actor Rotation]
                                                      ├─ Target : Self
                                                      └─ New Rotation : résultat Make Rotator
                    FALSE → (ne rien faire — évite le flip si curseur hors sol)
```

> **Pourquoi on isole le Yaw ?** Pour que le personnage ne s'incline pas vers le bas/haut si le curseur est loin ou sur un mur. On veut juste la rotation horizontale.

---

**Nœud 4 — Dodge (placeholder — step 03) :**
```
[Enhanced Input Action IA_Dodge]
  └─→ [Print String] "DODGE (todo)"
```

**Nœud 5 — Shoot (placeholder — step 03) :**
```
[Enhanced Input Action IA_Shoot]
  └─→ [Print String] "SHOOT (todo)"
```

> Les deux seront implémentés en step 03. Voir `step03_dash_projectile.md`.

---

## H. World Settings

`Window → World Settings` (ou l'onglet World Settings en haut à droite) :
- **GameMode Override** : `BP_JB_GameMode`

---

## I. Test

`Alt+P` (Play in Viewport) :
- ✅ Le personnage (capsule invisible) spawn
- ✅ ZQSD = déplacement sur le sol circulaire, indépendant de la visée
- ✅ Curseur souris = le personnage tourne vers lui en temps réel
- ✅ Mouvement et visée totalement découplés (Returnal-style)
- ✅ Espace = "DODGE (todo)" dans le coin haut gauche
- ✅ Caméra fixe, pitch -35°, Spring Arm 1400cm, suit la position du joueur
- ✅ Le personnage ne tombe pas (garde-corps 120cm en périphérie)
- ✅ Le socle boss central est visible depuis le bord de l'arène (cube placeholder si besoin)

---

## Résumé des fichiers créés

```
Content/
├── Maps/
│   └── L_Arena_01.umap
├── Blueprints/
│   ├── GameMode/
│   │   └── BP_JB_GameMode.uasset
│   └── Character/
│       └── BP_JB_Character.uasset
└── Input/
    ├── Actions/
    │   ├── IA_Move.uasset
    │   ├── IA_Dodge.uasset
    │   └── IA_Shoot.uasset
    └── Contexts/
        └── IMC_JB_Default.uasset
```

**Prochaine étape → Step 03 : Dash + Projectile joueur** (`step03_dash_projectile.md`)
