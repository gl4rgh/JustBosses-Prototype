# Step 08 — HP / Armure / Munitions + HUD (style Doom Eternal)

**Objectif :** Système de ressources aggressif-récompensant. Pas de regen passive. Chaque ressource se gagne par une action skillée. HUD UMG lisible en combat.
**Prérequis :** Step 06 ✓ — Projectiles qui touchent le joueur
**Blueprint only — aucun C++**

---

## A. Philosophie du système

> **Doom Eternal** : tu meurs si tu restes passif. Tu survies si tu attaques.
> **Just Bosses** : tu meurs si tu subis les patterns. Tu survies si tu dash bien ET tu attaques.

| Ressource    | Max | Perte                        | Récupération                                      |
|--------------|-----|------------------------------|---------------------------------------------------|
| HP           | 100 | Projectile boss touche       | Dash iframe à travers proj = **+5 HP**            |
|              |     |                              | Phase boss franchie (stagger) = **+20 HP**        |
| Armure       | 50  | Absorbe 50% dmg avant HP    | Pattern terminé sans hit = **+10 Armure**         |
|              |     |                              | Collecte shard flottant = **+5 Armure**           |
| Munitions SP | 10  | Tir puissant consomme 1      | Hit point faible boss = **+1 Muni SP**            |

### Calcul des dégâts
```
Incoming Damage = 20 (standard)

Si Armure > 0 :
  DmgToArmor = Min(Armure, IncomingDamage × 0.5)
  DmgToHP    = IncomingDamage - DmgToArmor
  Armure -= DmgToArmor
  HP     -= DmgToHP

Si Armure == 0 :
  HP -= IncomingDamage
```

> Exemple : 20 dégâts, 30 armure → -10 armure, -10 HP.

---

## B. Variables dans BP_JB_Character

| Nom               | Type    | Défaut | Instance | Rôle                                    |
|-------------------|---------|--------|----------|-----------------------------------------|
| `HP`              | Float   | 100.0  | non      | HP actuels                              |
| `MaxHP`           | Float   | 100.0  | oui      | HP maximum                              |
| `Armor`           | Float   | 0.0    | non      | Armure actuelle                         |
| `MaxArmor`        | Float   | 50.0   | oui      | Armure maximum                          |
| `SpecialAmmo`     | Integer | 0      | non      | Munitions spéciales actuelles           |
| `MaxSpecialAmmo`  | Integer | 10     | oui      | Maximum munitions spéciales             |
| `bGodMode`        | Boolean | false  | non      | Invincible (menu admin)                 |
| `bIsDead`         | Boolean | false  | non      | En cours de mort                        |
| `IframeHitCache`  | Array of Actor | — | non | Projectiles déjà comptés pour le gain HP iframe |

---

## C. Fonctions dans BP_JB_Character

### C1 — TakeDamage (appelée par BP_JB_Projectile)

```
[Function] TakeDamage(IncomingDamage Float)
  │
  └─→ [Branch] bGodMode OR bIsInvincible OR bIsDead ?
        TRUE → return (ignore)
        │
        FALSE →
          [Branch] Armor > 0 ?
            TRUE →
              DmgToArmor = Min(Armor, IncomingDamage × 0.5)
              DmgToHP    = IncomingDamage - DmgToArmor
              Armor = Max(0, Armor - DmgToArmor)
              HP    = Max(0, HP - DmgToHP)
            FALSE →
              HP = Max(0, HP - IncomingDamage)
          │
          → Camera Shake (petit) + HitFlash rouge sur HUD
          │
          [Branch] HP <= 0 ?
            TRUE → Call OnDeath
```

### C2 — OnDeath

```
[Function] OnDeath
  Set bIsDead = true
  [Get Player Controller] → [Disable Input] (désactive tout l'input pendant la mort)
  → [Play Anim] death animation (mannequin)
  → [Set Timer] 2.0s → Call RespawnPlayer
  → [Camera Fade to Black] Duration=1.5s
```

### C3 — RespawnPlayer

```
[Function] RespawnPlayer
  HP    = MaxHP
  Armor = 0
  SpecialAmmo = 0
  bIsDead = false
  → [Set Actor Location] = SpawnPoint (marqueur défini dans le niveau)
  → [Camera Fade from Black] Duration=0.5s
```

### C4 — GainHP (appelée par le système de rewards)

```
[Function] GainHP(Amount Float)
  [Branch] HP >= MaxHP ? → return
  HP = Min(MaxHP, HP + Amount)
  → VFX vert sur le joueur (spawn BP_FX_HPGain)
  → HUD pulse vert
```

### C5 — GainArmor

```
[Function] GainArmor(Amount Float)
  [Branch] Armor >= MaxArmor ? → return
  Armor = Min(MaxArmor, Armor + Amount)
  → VFX bleu
  → HUD pulse bleu
```

### C6 — GainSpecialAmmo

```
[Function] GainSpecialAmmo(Amount Integer)
  SpecialAmmo = Min(MaxSpecialAmmo, SpecialAmmo + Amount)
  → HUD pulse blanc
```

---

## D. Système de rewards — intégration dans le dash

Dans le **nœud dash** (step 03, Nœud 2), pendant la phase iframes :

```
[OnComponentBeginOverlap SphereCollision du joueur]  ← détection pendant iframe
  Other Actor →
    [Cast to BP_JB_Projectile]
      SUCCESS →
        [Branch] bIsInvincible ?  ← pendant le dash
          TRUE →
            [Branch] IframeHitCache contains Other Actor ?
              FALSE →
                Add Other Actor to IframeHitCache
                GainHP(5.0)     ← +5 HP pour chaque projectile traversé en iframe
                → [Spawn VFX] BP_FX_IframeAbsorb (particules dorées)
```

> `IframeHitCache` évite de compter le même projectile deux fois si on reste dessus.
> Clear IframeHitCache au début de chaque nouveau dash.

---

## E. Armor Shard — collectible flottant

`Content/Blueprints/Pickups/` → Blueprint Class → Actor
Nommer : `BP_JB_ArmorShard`

### Composants
- `SphereCollision` (radius=50cm) — Overlap avec Pawn
- `StaticMesh` (cube ou gemme) — scale 0.3, material Bleu Emissive
- `RotatingMovement` (rotation visuelle)

### Event Graph
```
[Event BeginPlay]
  → [Set Timer] lifetime = 8.0s → [Destroy Actor]

[OnComponentBeginOverlap]
  Other Actor → [Cast to BP_JB_Character]
    SUCCESS →
      [Call GainArmor(5.0)]
      [Destroy Actor]
```

### Spawn depuis le boss (fin de pattern)

Dans `JB_Pattern_*` — après la boucle de spawn :
```
[Random Float] < 0.3 ?    ← 30% de chance de dropper un shard
  TRUE →
    [Spawn Actor BP_JB_ArmorShard]
      Location : BossPos + Random Vector in Box (radius 200cm)
```

---

## F. Tir Puissant — SpecialAmmo

Dans `BP_JB_Character`, ajouter :
| Variable        | Type    | Défaut | Rôle                      |
|-----------------|---------|--------|---------------------------|
| `bSpecialMode`  | Boolean | false  | Bascule tir spécial actif |

Dans `IMC_JB_Default`, ajouter :
- `IA_SpecialShot` → touche **E** (ou Clic droit)

```
[IA_SpecialShot → Triggered]
  [Branch] SpecialAmmo > 0 AND bCanFire?
    TRUE →
      SpecialAmmo -= 1
      [Spawn Actor BP_JB_PlayerProjectile]
        → Set Damage = 50
        → Set Size = 50 (plus gros)
        → Set Color = (1.0, 0.8, 0.0) × 15  ← jaune intense
        → Set bPiercing = true               ← détruit les projectiles boss traversés
```

**bPiercing dans BP_JB_Projectile joueur :**
```
[OnComponentBeginOverlap]
  [Cast to BP_JB_Projectile]  ← projectile boss
    SUCCESS →
      [Branch] bPiercing ?
        TRUE → [Destroy Other Actor]  ← détruit le proj boss
               continue sans se détruire soi-même
```

---

## G. Point Faible du boss

Dans `BP_JB_DummyBoss`, ajouter :

### Composants
- `SphereCollision "WeakPoint"` (radius=80cm) — attaché à root, offset Z=100cm (haut du boss)
- `StaticMesh "WeakPointMesh"` — petite sphère, material pulsant (Timeline + Emissive)

### Variables
| Nom              | Type    | Défaut | Rôle                           |
|------------------|---------|--------|--------------------------------|
| `bWeakPointActive` | Boolean | false | Fenêtre de hit active          |
| `WeakPointWindow`  | Float   | 0.8   | Durée de la fenêtre (s)        |

### Activer la fenêtre (après chaque pattern)

Dans `OnPatternEnd` :
```
Set bWeakPointActive = true
[WeakPointMesh] → Set Visibility = true
→ [Play Timeline] pulse (Emissive 0→20→0, 0.3s loop)
→ [Set Timer] WeakPointWindow → DisableWeakPoint
```

### OnComponentBeginOverlap (WeakPoint)

```
[OnComponentBeginOverlap]
  [Cast to BP_JB_PlayerProjectile]
    SUCCESS AND bWeakPointActive ?
      → Apply Damage × 3 to boss HP
      → [Call GainSpecialAmmo(1)] on PlayerCharacter
      → Disable WeakPoint
      → [Spawn VFX] flash blanc sur le boss
```

---

## H. WBP_JB_HUD — Interface joueur

`Content/Blueprints/UI/` → Widget Blueprint
Nommer : `WBP_JB_HUD`

### H1 — Layout

```
[Canvas Panel]
  │
  ├─ [Vertical Box] (bas gauche, anchored bottom-left)
  │    ├─ [ProgressBar] "ArmorBar"   bleu,   taille 300×12px
  │    └─ [ProgressBar] "HPBar"      rouge,  taille 300×20px
  │
  ├─ [Horizontal Box] (bas droite, anchored bottom-right)
  │    ├─ [Text] "SP:"
  │    └─ [Text] "SpecialAmmoText"   blanc gras
  │
  ├─ [Image] "DashCooldownIndicator" (cercle en bas centre, rempli selon cooldown)
  │
  └─ [Border] "IframeOverlay"        (plein écran, cyan très transparent — visible pendant iframe)
       Opacity piloté par bIsInvincible
```

### H2 — Binding des valeurs (Event Tick dans WBP)

> UE5 recommande les bindings ou les Event Tick sur le Widget — Event Tick pour la réactivité.

```
[Event Tick]
  [Get Player Character] → Cast to BP_JB_Character → CharRef
  │
  ├─ HPBar       → [Set Percent] = CharRef.HP / CharRef.MaxHP
  ├─ ArmorBar    → [Set Percent] = CharRef.Armor / CharRef.MaxArmor
  ├─ SpecialText → [Set Text] = CharRef.SpecialAmmo + " / " + CharRef.MaxSpecialAmmo
  │
  ├─ DashCooldown :
  │    Elapsed = GetTimeSeconds - CharRef.LastDashTime
  │    [Set Percent of DashCircle] = Clamp(Elapsed / CharRef.DashCooldown, 0, 1)
  │
  └─ IframeOverlay :
       [Set Opacity] = CharRef.bIsInvincible ? 0.15 : 0.0
```

### H3 — Couleurs dynamiques (HP critique)

```
[Branch] CharRef.HP < 30 ?
  TRUE → HPBar → [Set Fill Color] = Rouge pulsant (Timeline sin wave)
  FALSE → [Set Fill Color] = Rouge normal
```

### H4 — Ajouter le HUD au viewport (BP_JB_Character BeginPlay)

```
[Event BeginPlay]
  ...  (après le mapping context existant)
  [Create Widget] WBP_JB_HUD → Set HUDWidget
  [Add to Viewport]
```

---

## I. HUD debug — overlay boss (optionnel, activable via menu admin)

`WBP_JB_HUD` — ajouter en haut à gauche (visibility = collapsed par défaut) :

```
[Vertical Box] "DebugPanel"  ← toggleé par menu admin → Overlay iframes debug
  ├─ [Text] "Phase    : " + BossPhase
  ├─ [Text] "Attaque  : " + LastAttackID
  ├─ [Text] "Total    : " + AttackCount
  └─ [Text] "Prochain : Xs"  (timer)
```

---

## J. Résumé fichiers créés / modifiés

```
Content/
├── Blueprints/
│   ├── Character/
│   │   └── BP_JB_Character         ← modifié : HP/Armor/Ammo, TakeDamage, OnDeath, Rewards
│   ├── Pickups/
│   │   └── BP_JB_ArmorShard        ← collectible armure flottant
│   ├── Boss/
│   │   └── BP_JB_DummyBoss         ← modifié : WeakPoint, Armor Shard spawn
│   └── UI/
│       └── WBP_JB_HUD              ← HUD joueur (HP/Armor/Ammo/Dash/Iframe)
└── Input/
    └── Actions/
        └── IA_SpecialShot          ← touche E
```

---

## K. Test complet

`Alt+P` :
- ✅ HUD visible : barre HP rouge, armure bleue, compteur SP
- ✅ Prendre un projectile → HP descend, armure absorbe 50%
- ✅ Dash iframe à travers proj → +5 HP affiché
- ✅ Pattern terminé sans hit → +10 armure
- ✅ Hit weak point → +1 SP
- ✅ E = tir puissant (consomme 1 SP, proj jaune, perce les proj boss)
- ✅ HP = 0 → mort, respawn 2s après
- ✅ God Mode admin → aucun dégât

---

**Prochaine étape → Step 09 : SFX / Atmosphère sonore** (`step09_sfx_atmosphere.md`)
