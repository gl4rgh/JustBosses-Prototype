# Step 10 — Éclairage, texturing, city assets

**Objectif :** Transformer l'arène BSP grise en environnement urbain crédible. Lumen full-RT, Nanite, ambiance nocturne/industrielle.
**Prérequis :** Step 09 ✓ — SFX intégrés
**Blueprint only — aucun C++**

---

## A. Objectif visuel cible

> Arène urbaine nocturne : toits de buildings visibles en fond, éclairage néon/industriel au sol, ciel étoilé ou nuageux. Contraste fort entre zones éclairées (dangers lisibles) et zones sombres (visuellement intéressantes).

Ton : **cyberpunk sombre** ou **industriel abandonné** — à toi de choisir.
Les deux fonctionnent avec les assets de villes standards Fab/Quixel.

---

## B. Settings projet — Lumen + Nanite

`Edit → Project Settings → Rendering` :

| Paramètre                        | Valeur recommandée (RTX 4080)     |
|----------------------------------|-----------------------------------|
| Dynamic Global Illumination      | **Lumen**                         |
| Reflection Method                | **Lumen**                         |
| Shadow Map Method                | **Virtual Shadow Maps**           |
| Nanite Tessellation              | **activé**                        |
| Hardware Ray Tracing             | **activé** (si supporté — oui)    |
| Lumen Hardware Ray Tracing       | **activé**                        |

> Redémarrage éditeur requis après modification rendering.

---

## C. Éclairage de base — 4 acteurs clés

Placer dans le niveau `L_Arena_01` :

### C1 — Directional Light (soleil/lune)

| Propriété            | Valeur          |
|----------------------|-----------------|
| Intensity            | 0.3 (nuit) / 5.0 (jour) |
| Light Color          | Bleu-violet froid (nuit) |
| Cast Shadows         | ✓               |
| Atmosphere Sun Light | ✓               |
| Source Angle         | 0.5             |

### C2 — Sky Light

| Propriété            | Valeur          |
|----------------------|-----------------|
| Mobility             | Movable         |
| Source Type          | Captured Scene  |
| Intensity            | 1.0             |
| Lower Hemisphere Color | Noir profond  |

> **Mobility Movable** = Lumen l'utilise dynamiquement. Static = baked uniquement.

### C3 — Sky Atmosphere

Acteur → `Sky Atmosphere` → drag dans le niveau.
- Rayleigh Scattering Scale : 0.033 (valeur réaliste)
- Mie Scattering : 0.003 (légère brume)

### C4 — Exponential Height Fog

| Propriété            | Valeur          |
|----------------------|-----------------|
| Fog Density          | 0.02 → 0.05 (selon ambiance) |
| Fog Inscattering Color | Bleu-gris sombre |
| Start Distance       | 500 cm          |
| Fog Max Opacity      | 0.8             |

> Fog trop dense = patterns illisibles. Garder density < 0.04 pour gameplay.

---

## D. Post Process Volume

Placer un `Post Process Volume` → **Infinite Extent** ✓ (couvre toute la scène)

| Catégorie       | Paramètre                | Valeur       |
|-----------------|--------------------------|--------------|
| Bloom           | Intensity                | 0.675 (défaut UE5) |
|                 | Threshold                | -1.0         |
| Exposure        | Min/Max EV100            | -2.0 / 4.0   |
|                 | Metering Mode            | Auto Exposure Histogram |
| Lens Flares     | Intensity                | 0.3          |
| Color Grading   | Contrast                 | 1.05         |
|                 | Crush Shadows            | 0.1          |
| Chromatic Aberration | Intensity           | 0.5          |
| Vignette        | Intensity                | 0.4          |
| Motion Blur     | Amount                   | 0.0 (**désactiver** — bullet hell lisibilité) |

> Bloom Threshold=-1.0 garantit que TOUS les matériaux Emissive brillent → cohérent avec M_Projectile HDR.

---

## E. Matériaux d'arène — remplacer le BSP gris

### E1 — Sol de l'arène

`Content/Materials/` → Material
Nommer : `M_Arena_Floor`

```
Domain : Surface
Blend Mode : Opaque
Shading Model : Default Lit

[Texture Sample] T_Concrete_Wet  (Quixel : surface_concrete_worn_xhbng)
  → Base Color
[Texture Sample] Normal Map      → Normal
[Constant] Roughness = 0.7
[Constant] Metallic  = 0.0
```

Sélectionner le BSP sol → Materials → assigner `M_Arena_Floor`.

### E2 — Murs de l'arène

Même principe avec `M_Arena_Wall` :
- Texture : béton ou brique industrielle (Quixel library → gratuit avec UE5)
- Ajouter une légère émission sur les bords bas (lumières rasantes)

### E3 — Lumières de sol (néons/strips)

Ajouter des `Point Light` ou `Rect Light` le long des murs bas :
- Couleur : cyan (0, 1, 1) ou magenta (1, 0, 1)
- Intensity : 500-1000 lux
- Attenuation Radius : 300 cm
- Cast Shadows : ✓

> Ces lumières créent le contraste visuel bullet-hell. Projectiles orange sur fond sombre = très lisible.

---

## F. Importer les city assets

### F1 — Quixel Bridge (intégré UE5)

`Content Browser → Add → Quixel Bridge`

Chercher :
- "urban building facade" → Nanite-ready
- "industrial metal rooftop"
- "concrete barrier"
- "street prop" (poubelles, caisses, piliers)

→ Clic **Add** → s'importe directement dans le projet avec Nanite activé.

### F2 — Assets Fab.com

Si tu as des assets ville achetés/téléchargés :
`Content Browser → Import` → sélectionner les fichiers `.fbx`

Dans la fenêtre d'import :
| Option              | Valeur      |
|---------------------|-------------|
| Import Meshes       | ✓           |
| **Build Nanite**    | ✓           |
| Generate Lightmaps  | ✗ (on utilise Lumen dynamique) |
| Combine Meshes      | ✗ (garder les pièces séparées) |

### F3 — Placement des buildings en fond

Les buildings servent de **skyline visible** depuis l'arène, pas de géo jouable :
- Les placer à 4000-8000 cm du centre (hors zone de jeu)
- Scale : 3-5× pour imposer sans être accessibles
- Pas besoin de collision (Can Collide = ✗)
- LOD automatique via Nanite

> Trick : placer des cubes/cylinders BSP géants texturés "béton" pour simuler des buildings rapidement. Les vrais assets pour plus tard.

---

## G. Couvrir l'arène — ciel ou toit ?

Deux options :

**Option A — Ciel ouvert (arène extérieure)**
- Garder Sky Atmosphere + Directional Light
- Ajouter quelques nuages avec `Volumetric Cloud` acteur (optionnel, lourd)
- Buildings visibles autour → effet rooftop urbain

**Option B — Arène couverte (intérieure industrielle)**
- Ajouter un plan BSP comme plafond à ~600cm
- Supprimer Sky Atmosphere
- Éclairage 100% artificiel (néons, spot lights industriels)
- Plus sombre, plus intense — style warehouse ou arène souterraine

> Recommandation pour le gameplay bullet-hell : **Option A** avec ciel sombre (nuit). Plus de lisibilité, les projectiles se détachent mieux.

---

## H. Optimisation (obligatoire avec assets ville)

### H1 — Vérifier Nanite sur tous les meshes importés

Sélectionner un Static Mesh → `Details → Nanite Settings → Enable Nanite` ✓

Ou en masse : Content Browser → sélectionner plusieurs meshes → clic droit → `Asset Actions → Nanite → Enable Nanite`.

### H2 — Cull Distance Volume

Placer un `Cull Distance Volume` autour de l'arène de jeu :
- Size : légèrement plus grand que la zone de gameplay
- Cull Distances : [(0, 1000), (100, 5000)] — petits objets disparaissent à 10m, grands à 50m

### H3 — Shadow Distance

`Post Process Volume → Shadow` → **Distance Field Shadow Distance** : 3000 cm max.
Shadows trop loin = coûteux. En bullet hell, le joueur regarde le sol → les ombres lointaines sont inutiles.

---

## I. Checklist visuelle

`Alt+P` :

- ✅ Sol texturé béton/industriel (plus de gris BSP)
- ✅ Murs avec matériaux appliqués
- ✅ Lumières de sol néon → contraste fort
- ✅ Projectiles boss orange/violet ressortent nettement
- ✅ Fog discret (pas de soupe, patterns lisibles)
- ✅ Bloom actif → boules émissives brillent
- ✅ Buildings visibles en fond (skyline urbaine)
- ✅ Pas de motion blur (désactivé dans Post Process)
- ✅ FPS > 60 constant avec ville en fond (Nanite + Lumen)

---

## J. Checklist perf (RTX 4080 — objectifs)

| Métrique               | Cible      | Vérifier via                    |
|------------------------|------------|---------------------------------|
| FPS                    | > 120      | `stat fps`                      |
| GPU Time               | < 8ms      | `stat gpu`                      |
| Lumen Scene Update     | < 3ms      | `stat lumen`                    |
| Nanite Triangles       | < 50M      | `Nanite Visualize → Triangles`  |
| Shadow Depth           | < 2ms      | `stat gpu`                      |

> La 4080 16GB tient facilement du Lumen + Nanite + city assets à 1440p/120fps. Si ça rame = assets non-Nanite ou shadows mal configurées.

---

**Projet complet après step 10 :**
Arena jouable → Patterns → Admin → HP/Armor → SFX → Visuellement propre.
**Projet complet pour la phase proto.**
Si Step 07 (Patterns suite) n'est pas encore fait → `step07_patterns_suite.md`
Sinon → retour au playtest, itération sur les patterns et le gameplay.
