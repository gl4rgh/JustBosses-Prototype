# Step 05 — Dummy Boss (cible d'entraînement)

**Objectif :** Boss immobile, flottant à 5m, rotation smooth vers le joueur, boucle d'attaques depuis un pool. Placeholder visuel = sphère UE5 scale ×5. Logique identique à `cl_boss_controller.lua` de Kosmos.
**Prérequis :** Step 04 ✓ — Menu Admin fonctionnel (F9, spawn/despawn boss intégré)
**Blueprint only — aucun C++**

> ℹ️ Le menu admin (step 04) gère le spawn/despawn du boss via F9 → panneau Boss.
> La touche F1 provisoire décrite en section E est **obsolète** si step 04 est fait — passer directement à la section E2.

---

## A. Créer BP_JB_DummyBoss

`Content/Blueprints/Boss/` → Blueprint Class → **Actor**
Nommer : `BP_JB_DummyBoss`

---

## B. Composants

| Composant               | Attaché à        | Rôle                                      |
|-------------------------|------------------|-------------------------------------------|
| `SceneComponent` (root) | —                | Pivot racine                              |
| `StaticMesh`            | Root             | Visuel boss (mannequin placeholder)       |
| `SphereCollision`       | Root             | Hitbox pour les projectiles joueur        |

**Configurer StaticMesh :**
- Static Mesh : `Engine/BasicShapes/Sphere` (placeholder)
- Scale : `X=5, Y=5, Z=5` (= 5m — cohérent avec Kosmos)
- Collision : **No Collision** (le boss est invincible aux physiques)
- Material : créer `M_BossPlaceholder` (couleur rouge simple, Emissive faible)

**Configurer SphereCollision :**
- Sphere Radius : `250` (2.5m — demi-sphère de 5m)
- Collision Preset : **Custom** → tous les channels = Overlap sauf `Pawn` = Ignore

---

## C. Variables

Ouvrir BP_JB_DummyBoss → **My Blueprint → Variables** :

| Nom                  | Type             | Défaut  | Instance Editable | Rôle                                   |
|----------------------|------------------|---------|-------------------|----------------------------------------|
| `bIsActive`          | Boolean          | false   | non               | Combat en cours                        |
| `bIsPaused`          | Boolean          | false   | non               | Pause admin                            |
| `bAttacking`         | Boolean          | false   | non               | Verrou anti-overlap d'attaques         |
| `AttackPool`         | Array of String  | (vide)  | **oui**           | IDs des attaques disponibles           |
| `PatternDuration`    | Float            | 7.0     | **oui**           | Durée max d'un pattern (s)             |
| `PauseBetween`       | Float            | 0.75    | **oui**           | Pause entre deux attaques (s)          |
| `RotationSpeed`      | Float            | 120.0   | **oui**           | Vitesse rotation vers joueur (°/s)     |
| `LiveTargetLocation` | Vector           | (0,0,0) | non               | Position joueur rafraîchie (50ms)      |
| `AttackCount`        | Integer          | 0       | non               | Compteur debug                         |
| `LastAttackID`       | String           | "—"     | non               | Dernier ID lancé (debug)               |
| `LiveTargetHandle`   | Timer Handle     | —       | non               | Handle du timer live target            |
| `AttackLoopHandle`   | Timer Handle     | —       | non               | Handle de la boucle d'attaques         |

> **Remplir AttackPool dans le viewport :** sélectionner BP_JB_DummyBoss placé dans la scène → Détails → AttackPool → `+` → taper les IDs voulus (`P1001`, `P1002`, etc.)

---

## D. Event Graph

### D1 — Rotation smooth vers le joueur (Event Tick)

```
[Event Tick] (Delta Seconds)
  │
  └─→ [Branch] bIsActive ?
        TRUE →
          [Get Player Character] → [Get Actor Location] → TargetLoc
          [Get Actor Location] → SelfLoc
          │
          [Find Look at Rotation]
            ├─ From : SelfLoc
            └─ To   : TargetLoc
                  └─→ [Break Rotator] → Yaw only
                        └─→ [Make Rotator] (Pitch=0, Yaw=Yaw, Roll=0) → TargetRot
          │
          [RInterpTo (Rotator)]
            ├─ Current  : [Get Actor Rotation]
            ├─ Target   : TargetRot
            ├─ Delta    : Delta Seconds
            └─ Interp Speed : RotationSpeed / 180.0  (normalise °/s → facteur interp)
                  └─→ [Set Actor Rotation]
```

> `RInterpTo` = interpolation lissée — identique au smooth tracking de Kosmos (`maxDelta = RotationSpeed × 16/1000`).

---

### D2 — Live Target (rafraîchi toutes les 50ms)

```
[Custom Event] "StartLiveTarget"
  └─→ [Set Timer by Event] (looping=true, Time=0.05)
        Event → [Custom Event] "TickLiveTarget"
              └─→ [Get Player Character] → [Get Actor Location] → Set LiveTargetLocation
```

---

### D3 — Boucle d'attaques

```
[Custom Event] "StartAttackLoop"
  └─→ [Custom Event] "DoNextAttack"  ← s'appelle elle-même après chaque cycle

[Custom Event] "DoNextAttack"
  │
  └─→ [Branch] bIsActive AND NOT bIsPaused ?
        │
        FALSE → (fin de boucle — ne rien faire)
        │
        TRUE →
          [Branch] bIsPaused ?
            TRUE → [Set Timer by Event] Time=0.2 → DoNextAttack  (polling pause)
            │
            FALSE →
              Set bAttacking = true
              │
              [Get array length AttackPool] > 0 ?
                FALSE → [Print String] "Pool vide" → Set Timer Time=2.0 → DoNextAttack
                │
                TRUE →
                  [Random Integer in Range] Min=0, Max=(Length-1)
                    └─→ [Get (Array)] AttackPool[index] → AttackID
                  │
                  Set LastAttackID = AttackID
                  AttackCount += 1
                  │
                  [Print String] "Attaque : " + AttackID + " #" + AttackCount
                  │
                  [JB_FireAttack] (Function — voir D4)
                    ├─ AttackID : AttackID
                    └─ BossPos  : Get Actor Location
                  │
                  [Set Timer by Event] Time=PatternDuration
                    Event → [Custom Event] "OnPatternEnd"

[Custom Event] "OnPatternEnd"
  Set bAttacking = false
  │
  [Set Timer by Event] Time=PauseBetween
    Event → DoNextAttack
```

---

### D4 — Fonction JB_FireAttack (placeholder → step 06)

Dans **My Blueprint → Functions** → `+` → nommer `JB_FireAttack`

Inputs : `AttackID` (String), `BossPos` (Vector)

```
[Print String] "FIRE : " + AttackID + " depuis " + BossPos
(implémentation réelle step 06 — portage patterns Kosmos)
```

---

### D5 — Fonctions publiques (appelées par le menu admin)

**BossStart** (Custom Event, Call in Editor = non)
```
[Custom Event] "BossStart"
  Set bIsActive = true
  Set bIsPaused = false
  Set AttackCount = 0
  → StartLiveTarget
  → StartAttackLoop
```

**BossDespawn** (Custom Event)
```
[Custom Event] "BossDespawn"
  Set bIsActive = false
  Set bIsPaused = false
  [Clear Timer by Handle] LiveTargetHandle
  [Clear Timer by Handle] AttackLoopHandle
  [Destroy Actor]
```

**BossPause** / **BossResume** (Custom Events)
```
[Custom Event] "BossPause"   → Set bIsPaused = true
[Custom Event] "BossResume"  → Set bIsPaused = false → DoNextAttack
```

**BossForceAttack** (Custom Event, Input : AttackID String)
```
[Custom Event] "BossForceAttack" (AttackID)
  → [JB_FireAttack] (AttackID, Get Actor Location)
```

---

## E. Spawner le boss

> **Si step 04 (admin menu) fait :** utiliser F9 → Panneau Boss → bouton Spawn/Despawn.
> Passer directement à la section F.
>
> **Si step 04 non fait (skip) :** utiliser la touche F1 provisoire ci-dessous.

### E1 — Via menu admin (recommandé)

Dans `WBP_JB_AdminMenu` → Panneau Boss → bouton "Spawn Boss" :
```
[On Clicked "Spawn Boss"]
  [Branch] ActiveBoss is Valid ?
    FALSE → [Spawn Actor BP_JB_DummyBoss] → Set ActiveBoss
    TRUE  → [Destroy Actor] ActiveBoss → Clear ActiveBoss
```
Connecter la référence `ActiveBoss` dans BP_JB_GameMode (ou BP_JB_Character selon ton implémentation).

### E2 — Via F1 provisoire (si admin menu non fait)

Dans `BP_JB_Character`, ajouter une variable :
| Nom           | Type              | Rôle                   |
|---------------|-------------------|------------------------|
| `ActiveBoss`  | BP_JB_DummyBoss (Object Reference) | Référence au boss actif |

Touche temporaire F1 — à remplacer par le menu admin une fois step 04 fait :
```
[Keyboard Event F1]
  └─→ [Branch] ActiveBoss is Valid ?
        FALSE →
          [Spawn Actor BP_JB_DummyBoss]
            └─ Location : [Get Actor Location] + (0, 800, 500)  ← 8m devant, 5m en hauteur
                  └─→ Set ActiveBoss = résultat
                        └─→ [Call BossStart on ActiveBoss]
        TRUE →
          [Call BossDespawn on ActiveBoss]
          Set ActiveBoss = null
```

---

## F. Debug HUD (optionnel)

Dans BP_JB_DummyBoss, **Event Tick** (après la rotation) :
```
[Branch] bIsActive ?
  TRUE →
    [Draw Debug String]
      ├─ Location : Get Actor Location + (0, 0, 300)
      ├─ Text : LastAttackID + " [" + AttackCount + "]"
      ├─ Color : Orange
      └─ (visible en viewport PIE)
```

---

## G. Résumé fichiers créés

```
Content/
├── Blueprints/
│   └── Boss/
│       └── BP_JB_DummyBoss.uasset
└── Materials/
    └── M_BossPlaceholder.uasset     ← sphère rouge simple
```

---

## H. Test

`Alt+P` → F9 → Panneau Boss → Spawn Boss :
- ✅ Boss (sphère rouge ×5) apparaît 8m devant, 5m en hauteur
- ✅ Rotation smooth vers le joueur
- ✅ "Attaque : P1001 #1" dans la console Output Log (si AttackPool rempli)
- ✅ F9 → Despawn Boss = despawn propre
- ✅ Le projectile joueur traverse le boss sans le détruire (pas de HP encore)

---

**Prochaine étape → Step 06 : Moteur Patterns (BP_JB_Projectile)** (`step06_pattern_engine.md`)
