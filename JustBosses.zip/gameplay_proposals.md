# Just Bosses — Propositions Gameplay
> Document de brainstorm. Rien d'obligatoire — à valider ou virer au cas par cas.
> Généré 2026-02-28.

---

## 1. Système HP / Armure / Munitions (inspiration Doom Eternal)

> Doom Eternal oblige le joueur à être AGRESSIF pour survivre — pas passif.
> On adapte cette philosophie à un boss fight bullet-hell.

### 1.1 Idée centrale
**Le joueur ne régénère rien naturellement. Il récupère des ressources par des actions skillées.**

| Ressource    | Max | Récupération                                                      |
|--------------|-----|-------------------------------------------------------------------|
| HP           | 100 | Dash avec iframes à travers un projectile = +5 HP                 |
|              |     | Stagger du boss (phase franchie) = +20 HP burst                   |
| Armure       | 50  | coup au corps a corps (modif du dev)             |
|              |     | Collecte de "shards" flottants émis par le boss                   |
| Munitions SP | 10  | Toucher le point faible du boss = +1 munition spéciale            |

> L'armure absorbe 50% des dégâts avant d'impacter les HP.
> L'armure monte jusqu'à 50 puis STOP (pas d'over-armor).

### 1.2 Types de tir
| Type        | Dégâts | Cadence | Munitions | Effet spécial                      |
|-------------|--------|---------|-----------|-------------------------------------|
| Standard    | 10     | 0.15s   | ∞         | —                                   |


### 1.3 Boucle de jeu résultante
```
Subir un pattern → dash pour éviter → iframes à travers proj → gain HP
Agresser le boss → gain munitions SP → tir puissant pour percer le prochain pattern
```
→ Le joueur qui joue bien est récompensé en ressources. Celui qui subit s'appauvrit progressivement.

---

## 2. Tells (avertissements visuels avant les attaques)

> Kosmos : son au lancement. Just Bosses : son + visuel anticipatif.

### 2.1 Système de tells
une attaque random du pool, une fois attaque finie, reelancer une attaque au bout de 0.75secondes

### 2.2 Weak Point
plus tard

---

## 3. Phases du boss

> plus tard

### Proposition de structure à 3 phases

plus tard

> **Transition de phase :** boss stagger (0.5s immobile, clignotant) → burst HP pour le joueur → reprise plus agressive.

### Combos de patterns (phase 3)
- 2 attaques se chevauchent (pattern D3 + missile simultanés)
- Exemple : Mandala + M3002 Déluge en même temps
- Ça se fait avec un délai de spawn décalé de 0.5s entre les deux

---

## 4. Gestion des arènes — idées avec les city assets

> T'as des assets de villes. Autant s'en servir autrement que juste comme décor.

### 4.1 Arène urbaine destructible (simple)
- Des obstacles urbains (voitures, caisses, piliers) dans l'arène
- Les projectiles du boss les détruisent progressivement (material swap + destroy)
- **Impact gameplay :** l'arène change pendant le combat, force le joueur à s'adapter

### 4.2 Zones de l'arène
- **Zone centrale** (près du boss) : dégâts ×1.5 sur le boss mais projectiles ×1.2 de vitesse
- **Zone périphérique** : safe mais tirs moins efficaces
- → Encourage le joueur à rester proche (agressif) vs jouer safe mais lentement

### 4.3 Véhicules comme cover
> "Véhicules avec iframes" — idée originale de la session précédente.
- Des épaves de voitures dans l'arène servent de cover temporaire
- Un projectile du boss = véhicule détruit (particules, explosion)
- **Twist** : rester trop longtemps derrière un véhicule = le boss change de pattern pour vous forcer à bouger (Nebula convergente depuis votre côté)

---

## 5. Mécaniques innovantes (hors conventions)

### 5.1 Pattern "Miroir" actif
> Idée 4th wall : le boss copie exactement les mouvements du joueur pour 5s.
> Le joueur doit rester immobile ou se déplacer en cercle pour ne pas se faire piéger.

### 5.2 Projectiles "récupérables"
- Certains projectiles (marqués différemment) peuvent être déviés par le tir puissant
- Impact du tir puissant sur un projectile = il repart vers le boss = dégâts ×2
- Mini-mécanique de parry à distance

### 5.3 Zone d'esquive parfaite (Perfect Dodge)
- Si le dash finit exactement quand un projectile touche la capsule de collision (timing précis)
- = Slow motion 0.5s + bonus HP ou munition SP
- Feedback visuel fort (screen flash blanc, son distinct)
- **Risqué/récompensé** — pas obligatoire, mais skillful

### 5.4 Combo d'esquives
- Enchaîner X dashs parfaits sans prendre de dégâts → multiplicateur de dégâts temporaire (×1.5, 5s)
- Compteur visible dans le HUD
- Prendre un hit = combo reset

### 5.5 Terminal Claude in-game (4th wall)
> Déjà prévu dans le CLAUDE.md. Quelques idées concrètes :
- Pendant le combat, des messages apparaissent dans le terminal
- Le boss "communique" avec le joueur via le terminal (texte généré selon les patterns)
- Exemple : "Pattern P3008 chargé. Bonne chance." ou "Tu viens d'activer le Mandala. Franchement."
- Admin peut forcer des messages custom via le menu admin (section Terminal)
- Potentiel 4th wall : le boss peut commenter la performance du joueur

---

## 6. Système de score / Leaderboard

> Utile pour le multi — les potes peuvent se comparer.

| Action                       | Points    |
|------------------------------|-----------|
| Dash iframe réussi           | +50       |
| Perfect Dodge                | +200      |
| Combo ×2 maintenu            | ×2 sur tout|
| Hit boss point faible        | +100      |
| Tir puissant parry           | +300      |
| Phase franchie               | +500      |
| Prendre un hit               | -100      |
| Mort                         | -500      |

> Leaderboard en fin de session affiché dans le terminal Claude.

---

## 7. Idées "ouvertes" (à creuser ou virer)

- **Équipes** : 2v2 — une équipe distrait le boss, l'autre attaque le point faible
- **Rôles différenciés** : Tank (armure naturelle mais tir lent) / DPS (tir rapide, fragile) / Support (peut heal les alliés)
- **Boss jouable** : un admin peut prendre le contrôle du boss et choisir les patterns manuellement (menu admin → "Prendre le contrôle")
- **Arène qui se réduit** : les murs se rapprochent progressivement en phase 3
- **Météo** : pluie / grêle qui réduit légèrement la visibilité des projectiles (challenge pour les joueurs avancés)
- **Challenges admin** : activer un modificateur "no dash", "HP ×0.5", "vitesse boss ×2" pour varier les runs

---

## Priorités suggérées (ordre d'implémentation)

1. **HP/Armure/Munitions + HUD** — core gameplay loop (step 07)
2. **Tells visuels** — lisibilité combat (step 06, lors du portage des patterns)
3. **Weak point** — simple à ajouter sur le DummyBoss
4. **Perfect Dodge** — feedback skill, simple en BP (check collision timing)
5. **Phases boss** — structure de progression (step 07-08)
6. **Score** — connexion naturelle au terminal Claude
7. **Arène destructible** — polish visuel (après que le gameplay core soit solide)
