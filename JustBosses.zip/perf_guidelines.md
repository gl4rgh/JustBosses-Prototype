# Performance Guidelines — Just Bosses (UE 5.7.3) v0.0.1

**Hardware dev :** Ryzen 9 9800X3D (8c/16t, 96 Mo L3 3D V-Cache) + RTX 4080, 1440p
**Cible joueur :** PC mid-range (ex: RTX 3060/RX 6700), **60fps stables**, upscaling TSR/DLSS/FSR en Balanced
**Pas de cible console.** PC-only.

---

## 1. Thread model UE5 + 9800X3D

```
Game Thread    → logique Blueprint, AI, physique légère, input  (1 cœur)
Render Thread  → draw calls, préparation GPU                    (1 cœur)
RHI Thread     → commandes GPU bas niveau                       (1 cœur)
Worker Threads → physique Chaos, audio decode, IO async         (5 cœurs restants)
```

### Ryzen 9 9800X3D — points utiles pour UE5

| Caractéristique        | Impact sur Just Bosses                                        |
|------------------------|---------------------------------------------------------------|
| 8 cœurs / 16 threads   | UE5 TaskGraph exploite tous les Worker Threads effectivement  |
| 96 Mo L3 3D V-Cache    | Blueprint VM tourne hot-cache → overhead Blueprint **réduit** vs CPU normal |
| L3 V-Cache grand       | `Cast To`, lookups de variables, arrays de refs → moins pénalisants |
| Fréquence mono-cœur    | Game Thread rapide = gameplay fluide même si Blueprint-heavy  |

> Le 9800X3D est un des meilleurs CPU possibles pour du Blueprint UE5. Le grand cache L3 réduit les miss coûteux du VM interprété. **Pour autant, ne pas abuser : les bonnes pratiques restent valables.**

### Ce qui est automatiquement multi-threadé :
- **Niagara GPU** : simulation particules → GPU, zéro coût Game/Worker Thread
- **Lumen / HW RT** : Render Thread + GPU
- **Chaos Physics** : Worker Threads (tous les cœurs dispo)
- **Audio MetaSound** : Worker Thread dédié
- **IO async** (chargement assets) : Worker Thread

### Ce qui reste sur le Game Thread (Blueprint) :
- Logique acteurs, HP, dégâts, inputs
- Timers BP, Event Dispatchers
- → OK pour du gameplay léger (~50 acteurs dans l'arène)

---

## 2. Frametime budget — cible 60fps mid-range

**Référence principale : 60fps constant sur mid-range avec upscaling Balanced.**

| Métrique         | Budget 60fps  | Mesure               | Note                          |
|------------------|--------------|----------------------|-------------------------------|
| Frame total      | < 16.6 ms    | `stat fps`           | Budget global                 |
| GPU Frame        | < 11 ms      | `stat gpu`           | Laisse ~5ms pour CPU          |
| CPU Game Thread  | < 5 ms       | `stat unit` → Game   | BP + logique                  |
| Render Thread    | < 4 ms       | `stat unit` → Draw   |                               |
| Lumen Scene      | < 3 ms       | `stat lumen`         |                               |
| Shadow Depth     | < 2 ms       | `stat gpu`           |                               |
| Nanite           | < 2 ms       | `Nanite Visualize`   |                               |

> Sur **dev** (RTX 4080 + 9800X3D) on est souvent à 120fps+ — profiler régulièrement en mode **mid-range simulé** : réduire résolution de rendu à 720p ou baisser TSR en Performance pour stresser le GPU à budget équivalent.

---

## 3. Anti-Aliasing + Upscaling — options complètes (2025)

### AA natifs UE5 (Deferred Rendering)

> **MSAA = incompatible** Deferred Rendering → désactive Lumen + Nanite. Ne pas utiliser.
> **TXAA** = technologie NVIDIA propriétaire non intégrée dans UE5. TSR est son équivalent moderne.

| AA Method | `r.AntiAliasingMethod` | Qualité   | Coût    | Temporal | Notes                          |
|-----------|------------------------|-----------|---------|----------|--------------------------------|
| None      | 0                      | Nul       | ~0      | Non      | Debug uniquement               |
| **FXAA**  | 1                      | Basique   | Minimal | Non      | Pas de ghosting, léger flou    |
| **TAA**   | 2                      | Bon       | Moyen   | Oui      | Legacy — peut ghoster          |
| **TSR**   | 4                      | Excellent | Moyen+  | Oui      | Défaut UE5 — ghosting possible |

---

### DLSS 4 (NVIDIA — janvier 2025)

Plugin Fab : `NVIDIA DLSS` — `Edit → Plugins → NVIDIA DLSS`

**Modèle transformer** (remplace le CNN de DLSS 2/3) → meilleure qualité sur tous les RTX.

| Feature                    | GPU requis      | Description                                          |
|----------------------------|-----------------|------------------------------------------------------|
| **Super Resolution (SR)**  | RTX 20/30/40/50 | Upscaling + AA — le mode principal                   |
| **Ray Reconstruction (RR)**| RTX 20/30/40/50 | Remplace le denoiser RT → reflets + GI plus nets     |
| **Frame Generation (FG)**  | RTX 40 uniquement| Génère 1 frame interpolée → ×2 fps affiché          |
| **Multi Frame Gen (MFG)**  | RTX 50 uniquement| Génère jusqu'à 3 frames → ×4 fps affiché            |
| **NVIDIA Reflex**          | RTX (tous)      | Réduit la latence système — **coupler avec FG**      |

> **RTX 4080 (dev) :** SR ✓, RR ✓, FG ✓, MFG ✗ (RTX 50 seulement)

**⚠️ Frame Generation + bullet-hell :** FG ajoute ~1 frame de latence (+16ms à 60fps).
Pour un jeu de réaction, c'est perceptible. **Toujours activer Reflex avec FG** pour compenser.
→ Recommandation : **FG désactivé par défaut**, option disponible dans le menu.

---

### FSR 3.1 / FSR 4 (AMD — 2024-2025)

Plugin Fab : `AMD FidelityFX Super Resolution` — `Edit → Plugins → AMD FSR`

| Version     | GPU requis         | Features                                             |
|-------------|--------------------|------------------------------------------------------|
| **FSR 1**   | Tous (spatial)     | Upscale spatial uniquement, pas d'AA temporel        |
| **FSR 2/3** | Tous               | Temporal SR + AA — universel                         |
| **FSR 3.1** | Tous               | SR amélioré + **Frame Generation** (software, tous GPU) |
| **FSR 4**   | RX 9000 (RDNA 4)   | ML hardware accéléré, qualité ≈ DLSS 4 SR            |

> **FSR 3.1 est l'option universelle** — fonctionne sur toutes les cartes y compris NVIDIA et Intel.
> FSR 4 = exclusif RX 9070/9070 XT (RDNA 4, 2025). Qualité DLSS-like avec accélération matérielle.
> **FSR 3 FG sans Reflex = +latence** — même remarque que DLSS FG pour le bullet-hell.

---

### XeSS 2 (Intel — 2025)

Plugin Fab : `Intel Xess` — `Edit → Plugins → Intel Xess`

| Version  | GPU requis  | Features                                    |
|----------|-------------|---------------------------------------------|
| **XeSS 1**| Tous        | SR temporel + AA                            |
| **XeSS 2**| Tous        | SR amélioré + **Frame Generation**          |

> XeSS fonctionne sur tous les GPU (hardware accéléré sur Arc, software sur les autres).

---

### Matrice GPU → recommandation

| GPU joueur              | SR recommandé        | Frame Gen        | Latence compensée |
|-------------------------|----------------------|------------------|-------------------|
| RTX 50xx               | **DLSS 4 SR**        | DLSS 4 MFG       | Reflex (inclus)   |
| RTX 40xx (dev : 4080)  | **DLSS 4 SR**        | DLSS 3 FG + Reflex | ✓ avec Reflex   |
| RTX 20/30xx            | **DLSS 4 SR**        | ✗ (pas de FG)    | Reflex SR uniquement |
| RX 9000 (RDNA 4)       | **FSR 4**            | FSR 3 FG         | ⚠️ sans Reflex   |
| RX 6000/7000           | **FSR 3.1**          | FSR 3 FG         | ⚠️ sans Reflex   |
| Intel Arc              | **XeSS 2**           | XeSS 2 FG        | ⚠️ sans Reflex   |
| GPU ancien / iGPU      | **FSR 3.1 ou FXAA** | ✗                | N/A               |

---

### Plugins à activer dans UE5

```
Edit → Plugins → chercher et activer :
  "NVIDIA DLSS"                      ← DLSS 4 SR + FG + RR + Reflex
  "AMD FidelityFX Super Resolution"  ← FSR 3.1 (+ FSR 4 si dispo pour UE 5.7)
  "Intel Xess"                       ← XeSS 2
→ Redémarrer l'éditeur après activation
```

> Vérifier les versions des plugins sur Fab — les plugins DLSS/FSR/XeSS sont mis à jour
> indépendamment du moteur. Toujours prendre la dernière version compatible UE 5.7.

---

### Exposer dans le menu Options — BP

```
[Execute Console Command] "r.AntiAliasingMethod 1"    ← FXAA (fallback universel)
[Execute Console Command] "r.AntiAliasingMethod 2"    ← TAA
[Execute Console Command] "r.AntiAliasingMethod 4"    ← TSR
[Execute Console Command] "r.ScreenPercentage 50"     ← Performance
[Execute Console Command] "r.ScreenPercentage 67"     ← Balanced
[Execute Console Command] "r.ScreenPercentage 77"     ← Quality
[Execute Console Command] "r.ScreenPercentage 85"     ← Ultra Quality
[Execute Console Command] "r.ScreenPercentage 100"    ← Native
```

Pour DLSS/FSR/XeSS → **utiliser les BP nodes exposés par les plugins** (pas des console commands) :
- DLSS : nœud `UDLSSLibrary → Set DLSS Mode` (enum : Performance/Balanced/Quality/Ultra/Auto)
- FSR : nœud `UFSRModule → SetFSRQualityMode`
- Reflex : nœud `UReflexLibrary → SetReflexMode` (activer **dès que FG est actif**)

### Presets de qualité

| Preset       | `r.ScreenPercentage` | DLSS/FSR équivalent | Cible                        |
|--------------|---------------------|---------------------|------------------------------|
| Performance  | 50%                 | Performance         | iGPU / très vieux GPU        |
| **Balanced** | **67%**             | **Balanced**        | **Défaut recommandé**        |
| Quality      | 77%                 | Quality             | Mid-range confortable        |
| Ultra        | 85%                 | Ultra Quality       | Haut de gamme                |
| Native       | 100%                | DLAA (DLSS natif)   | RTX 4080+                    |

> **Default au lancement :** Auto-détecter DLSS → FSR → XeSS → TSR, preset Balanced.
> Si TSR uniquement disponible et ghosting gênant → proposer TAA en option explicite.

---

## 4. CPU traps Blueprint — à éviter

### Patterns dangereux

| Anti-pattern                              | Pourquoi                         | Alternative                        |
|-------------------------------------------|----------------------------------|------------------------------------|
| `Get All Actors of Class` chaque tick     | Scan de tous les acteurs monde   | Cache la ref en BeginPlay          |
| `Cast To` chaque tick                     | Overhead VM même avec V-Cache    | Cast une fois, stocke la ref       |
| `For Each` sur 100+ acteurs / tick        | Game Thread bloqué               | Étaler sur plusieurs frames (Timer)|
| Tick sur tous les acteurs                 | N acteurs × overhead Tick        | `Can Tick = false` si inutile      |
| Spawn 20+ acteurs en une frame            | Spike ~50ms = freeze             | Pool d'acteurs (step06)            |
| `Delay` imbriqués dans des loops          | Accumulation de handles          | Un seul Timer Handle par logique   |

### Bonnes pratiques

```
BeginPlay   → toutes les refs (Cast, Get GameMode, Get Controller...)
EventTick   → UNIQUEMENT ce qui doit vivre chaque frame (rotation vers souris)
Timer       → tout ce qui est périodique (AttackLoop boss)
Event       → réagir (Overlap, Hit, HP change) plutôt que poller
```

---

## 5. GPU / CPU — trouver l'équilibre

**Règle : Niagara GPU pour les effets visuels purs. CPU (Actor BP) pour tout ce qui a de la logique.**

| Système               | Recommandation  | Raison                                               |
|-----------------------|-----------------|------------------------------------------------------|
| NS_ElectricBolt       | GPU Sim Stage   | Visuel pur, pas de logique → 10k particules pour rien en CPU |
| NS_PlayerHit          | CPU ou GPU      | Burst court (< 50 part.) → CPU OK                    |
| Projectiles boss      | **Actor BP CPU**| Snap, dégâts, pooling → logique nécessaire           |
| Ambiance (poussière)  | GPU             | Décoratif, zéro logique                              |
| Eau (Water Plugin)    | GPU natif       | Simulation shallow water intégrée                    |
| Physique (Chaos)      | Worker Threads  | Automatique                                          |

> **Ne pas forcer GPU partout.** Un système Niagara GPU avec des `Blueprint Script` dedans = pire que CPU. Garder GPU pour le visuel pur, CPU pour la logique.

```
Niagara → Emitter → Properties → Sim Target : GPU Compute Sim
← seulement si l'émetteur n'a pas de script logique
```

---

## 6. Rendu — quads vs triangles

| Source           | Format    | Status                                          |
|------------------|-----------|-------------------------------------------------|
| BSP UE5          | Quads     | ⚠️ Grey box uniquement → convertir avant step10 |
| Quixel Bridge    | Triangles | ✅ Safe                                         |
| Fab assets tiers | Variable  | Vérifier : `Static Mesh Editor → Triangles`    |
| BSP converti     | Triangles | ✅ `Brush Settings → Create Static Mesh`        |

---

## 7. Lumen + HW Ray Tracing — rebonds et réglages mid-range

### Réglages projet (Edit → Project Settings → Rendering)

| Paramètre                        | Valeur                            |
|----------------------------------|-----------------------------------|
| Dynamic Global Illumination      | Lumen                             |
| Lumen → Software Ray Tracing     | **désactivé** (on a HW RT)        |
| Lumen → Hardware Ray Tracing     | **activé**                        |
| Lumen Scene Detail               | **1.0** minimum (évite leaks)     |
| Lumen Scene View Distance        | 1500 cm (arène 60m, marge ok)     |
| Reflection Method                | Lumen                             |
| Shadow Map Method                | Virtual Shadow Maps               |

### Nombre de rebonds — recommandations mid-range

Le nombre de rebonds se configure dans le **Post Process Volume** (Infinite Extent) :

```
Post Process Volume → Global Illumination → Lumen Global Illumination
  → Max Bounces : 2          ← sweet spot mid-range (défaut = 1)
  → Screen Traces : ✓        ← cheap, améliore la qualité en espace écran

Post Process Volume → Reflections → Lumen Reflections
  → Max Roughness : 0.5      ← pas de reflets sur les surfaces trop rugueuses
  → Ray Lighting Mode : Surface Cache (moins cher que HW RT pur)
```

| Rebonds GI  | Qualité       | Coût GPU   | Usage recommandé                  |
|-------------|---------------|------------|-----------------------------------|
| 1           | Correct       | Minimal    | Low-end, TSR Performance          |
| **2**       | **Bon**       | **Moyen**  | **Mid-range, TSR Balanced ← cible** |
| 4           | Très bon      | Élevé      | High-end, TSR Quality             |
| 8           | Diminishing returns | Très élevé | Inutile en temps réel        |

> **Pour Just Bosses : 2 rebonds.** L'arène est relativement petite et fermée — les rebonds supplémentaires au-delà de 2 sont peu visibles dans ce contexte.

### Variables console utiles (équilibrage mid-range)

```bash
r.Lumen.DiffuseIndirect.MaxBounces 2        # rebonds GI (Post Process override)
r.Lumen.Reflections.MaxRoughnessToTrace 0.5 # reflections sur surfaces < 50% rugosité
r.Lumen.HardwareRayTracing.MaxIterations 4  # itérations HW RT (défaut 8 → réduire à 4)
r.Lumen.ScreenProbeGather.DownsampleFactor 2 # réduire résolution GI (perf++, qualité-)
r.Lumen.Reflections.DownsampleFactor 2     # réduire résolution reflections
```

### Anti-leaks

```
1. Lumen Scene Detail ≥ 1.0
2. Épaisseur des murs > 30 cm (les rayons traversent les surfaces trop fines)
3. Pas de trous dans la géo (BSP bien fermé)
4. Sphere Reflection Captures dans les coins si des zones restent sombres
```

**Sphere Reflection Captures (si leaks persistants) :**
- 4 acteurs dans les coins de l'arène, height ~200cm
- Radius 1500cm, Influence Radius 2000cm
- Capture Resolution : 128 (pas besoin de plus pour une arène)

---

## 8. Cull Distance — simple

**Pas besoin de setup complexe pour une arène 60m.**

Deux approches, choisir une :

**Option A — Max Draw Distance sur les meshes décoratifs directement :**
```
Sélectionner un mesh décoratif (building lointain, prop) → Détails
→ Rendering → Max Draw Distance : 8000 (80m)
← Les assets hors zone de jeu disparaissent à 80m
```

**Option B — Un seul Cull Distance Volume (si vraiment nécessaire) :**
```
Place Actors → Cull Distance Volume
Size : 10000 × 10000 × 3000 (couvre toute la zone jouable)
Cull Distances : [(0, 5000)]  ← tous les petits objets disparaissent à 50m
```

> Pour une arène de 60m avec ~50 acteurs, le culling UE5 automatique (Frustum Culling) fait déjà le travail. N'ajouter un Cull Distance Volume que si `stat gpu` montre un problème réel.

---

## 9. Taille de niveau

| Paramètre         | Valeur              |
|-------------------|---------------------|
| Arène gameplay    | Ø ~60m              |
| Zone décors max   | ~300m du centre     |
| World Partition   | **désactivé**       |
| Level Streaming   | non (pour l'instant)|

---

## 10. Commandes de profilage

```bash
stat fps              # FPS + frametime global
stat unit             # Game / Draw / GPU / RHI
stat gpu              # breakdown GPU par catégorie
stat Lumen            # budget Lumen
r.Nanite.Visualize 1  # triangles Nanite
r.ScreenPercentage 67 # forcer TSR Balanced (test mid-range)
r.ScreenPercentage 50 # forcer TSR Performance (test low-end)
ProfileGPU            # snapshot GPU détaillé
```

---

## 11. Résumé règles d'or

1. **Tick = péché** si > 10 acteurs en font un pour de la logique
2. **Cache tes refs** en BeginPlay, jamais en Tick
3. **Niagara GPU** = visuel pur uniquement (pas de logique)
4. **Actor BP** = tout ce qui a de la logique (projectiles, boss)
5. **BSP → SM** avant le step10
6. **Lumen HW RT uniquement** (SW RT = off)
7. **World Partition = non**
8. **Upscaling TSR Balanced par défaut** (`r.ScreenPercentage 67`)
9. **stat unit + stat gpu** à tourner régulièrement pendant le dev
10. **Profiler en TSR Performance** pour simuler un mid-range
