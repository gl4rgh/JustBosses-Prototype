# Blender + UE5 Pipeline — Just Bosses v0.0.1

---

## 1. Dépendances Blender

**Blender lui-même = standalone, zéro dépendance externe obligatoire.**
Python est intégré (3.11+). Pip est disponible via le Python embarqué.

### Addons indispensables pour le pipeline UE5

| Addon                  | Source              | Coût  | Installation                        |
|------------------------|---------------------|-------|-------------------------------------|
| **Send to Unreal**     | Epic Games (GitHub) | Free  | `Edit → Preferences → Add-ons → Install` |
| io_scene_fbx           | Builtin Blender     | Free  | Activé par défaut                   |
| **Auto-Rig Pro**       | Blender Market      | ~40€  | Meilleur outil de rigging           |
| Rigify                 | Builtin Blender     | Free  | Rig procédural basique              |

### Send to Unreal (recommandé)

Télécharger depuis : https://github.com/EpicGames/BlenderTools
→ Dossier `send2ue/` → drag dans `Edit → Preferences → Add-ons → Install from disk`

Permet d'envoyer meshes + animations directement dans UE5 ouvert, sans passer par FBX manuel.

```
Blender → Pipeline → Send to Unreal → Configure paths → Export
↓
UE5 → Content Browser → asset importé automatiquement
```

### Installer un package pip dans Blender (si un addon le nécessite)

```powershell
# Remplacer 4.3 par ta version Blender
& "C:\Program Files\Blender Foundation\Blender 4.x\4.x\python\bin\python.exe" -m pip install <package>
```

---

## 2. IA utilisables dans Blender

### A. Dream Textures (Stable Diffusion — le plus utile)

**Usage :** générer des textures directement dans Blender depuis un prompt texte.
**Mode :** fonctionne localement (GPU) ou via API HuggingFace.

Installation :
```
https://github.com/carson-katri/dream-textures
→ Télécharger la release .zip → Install from disk dans Blender Add-ons
→ Au premier lancement : Download Model (SD 1.5 ou SDXL, ~4 Go)
```

> **Rappel charte JB** : les textures générées par IA ne vont pas directement dans le jeu — elles servent de référence/inspiration. La texture finale = recomposée ou remplacée par une source CC0 (PolyHaven).

### B. BlenderGPT

**Usage :** contrôler Blender en langage naturel via ChatGPT (génère du Python).
**Prérequis :** clé API OpenAI (payant, ~1 centime par requête).

```
https://github.com/gd3kr/BlenderGPT
→ pip install openai (dans le Python Blender, voir ci-dessus)
→ Entrer clé API dans les préférences du addon
```

> Utile pour automatiser des tâches répétitives ("aligne tous ces os sur l'axe Z", "ajoute un modificateur Mirror sur tous les objets sélectionnés").

### C. Meshy.ai / Kaedim (services web)

**Usage :** text-to-3D mesh. Tu décris, ça génère un mesh .fbx/.obj.
**Prix :** freemium (quelques générations gratuites/jour).
**Workflow :** générer → télécharger FBX → importer Blender → retravailler → UE5.

> Qualité variable. Utile pour des props rapides ou des placeholders. Pas pour le boss final.

### D. AccuRIG (Reallusion — free)

**Usage :** auto-rigging. Importer un mesh humanoïde/créature → rig automatique.
**Intérêt JB :** rigger le boss rapidement pour le prototypage.
→ https://actorcore.reallusion.com/auto-rig

---

## 3. Animations — Blender ou UE5 ?

### Règle générale

| Tâche                              | Où faire          | Raison                                      |
|------------------------------------|-------------------|---------------------------------------------|
| Créer des animations d'attaque     | **Blender**       | Timeline flexible, feedback immédiat        |
| Rigging du boss                    | **Blender**       | Auto-Rig Pro / AccuRIG / Rigify             |
| Blending entre animations          | **UE5**           | Animation Blueprint, State Machine          |
| Cinématiques / cutscenes           | **UE5 Sequencer** | Natif, timeline intégrée dans le niveau     |
| Retargeting MetaHuman              | **UE5**           | IK Retargeter natif                         |
| Animations procédurales (boss)     | **UE5 Control Rig** | Nœuds BP, inverse kinematics dynamique    |

### Pipeline recommandé pour le boss

```
1. Blender
   → Créer/importer le mesh du boss
   → Rigger (Auto-Rig Pro ou AccuRIG)
   → Créer les animations :
      - Idle
      - AttackP1001, AttackP1003... (une anim par pattern si besoin)
      - Hit, Death
   → Exporter FBX (armature + anims)
      File → Export → FBX
      ✓ Armature
      ✓ Bake Animation
      ✓ Apply Scalings : FBX All (évite le scale ×100 dans UE5)

2. UE5
   → Importer le FBX (Content Browser → Import)
      ✓ Import Animations
      ✓ Skeletal Mesh
   → Créer Animation Blueprint (ABP_JB_Boss)
      → State Machine : Idle → Attack → Hit → Death
   → Brancher les transitions sur les variables BP_JB_DummyBoss
      (bIsAttacking, bIsHit, HP <= 0...)
```

### Mixamo (alternative rapide — prototype)

Pour les anims placeholder **sur des personnages humanoïdes** :
→ https://www.mixamo.com (Adobe, free)
→ Uploader le mesh → auto-rig + bibliothèque d'animations
→ Télécharger FBX → importer directement dans UE5

> Pour le boss (créature non-humanoïde) → Mixamo ne s'applique pas. Blender obligatoire.

### Exporter les settings FBX Blender → UE5

```
File → Export → FBX (.fbx)

Transform :
  Scale : 0.01  ← UE5 attend du cm, Blender est en m → ×0.01 compense
  Apply Unit : ✓
  Apply Scalings : FBX All
  Forward : -Z Forward
  Up : Y Up

Armature :
  ✓ Add Leaf Bones : décocher (UE5 n'en veut pas)
  ✓ Primary Bone Axis : Y Axis
  ✓ Secondary Bone Axis : X Axis

Bake Animation :
  ✓ Key All Bones : ✓
  ✓ Force Start/End Keying : ✓
  NLA Strips : décocher si une seule anim à la fois
```

---

## 4. Versionner les fichiers Blender

Les `.blend` sont des binaires mais compressibles. Quelques options :

**Option A — Committer dans git (simple)**
```bash
# .gitignore du projet ne les exclut pas par défaut
git add Content/Art/Boss/JB_Boss_v001.blend
git commit -m "art: boss mesh v001 - proportions de base"
```
→ Nommage recommandé : `NomFichier_v001.blend`, `v002.blend`... (version manuelle)

**Option B — Blender Versioning intégré**
`File → Preferences → System → Save Versions : 10`
→ Blender garde les 10 dernières versions auto dans `filename.blend1`, `.blend2`...
→ Ces fichiers sont dans le dossier de travail (pas dans le projet UE5)

**Option C — Dossier SourceAssets/ versionné séparément**
```
E:\JustBosses\SourceAssets\Blender\
  ├── Boss\
  │   ├── JB_Boss_v001.blend
  │   └── JB_Boss_v002.blend
  └── Props\
      └── JB_Prop_Barrier_v001.blend
```
→ Ce dossier est dans `.gitignore` du projet UE5 (trop lourd)
→ Il est sauvegardé via `backup_daily.ps1` (le script inclut le dossier parent `E:\JustBosses\`)

> **Recommandation** : Option B pour le travail quotidien + Option C pour l'archivage.
