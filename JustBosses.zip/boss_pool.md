# Just Bosses — Pool de Boss

> Liste des boss conçus/planifiés pour Just Bosses.
> Chaque boss a un thème élémentaire, un nom, et un pool d'attaques associé.

---

## APELPISÍA — Boss 01 (Boss principal)

**Nom :** APELPISÍA (Ἀπελπισία)
**Étymologie :** grec ancien — "désespoir total, perte de tout espoir" (ἀπελπίζω = abandonner tout espoir)
**Prononciation :** *ah-pel-pi-SEE-ah*

**Thème :** Désespoir / Chaos élémentaire
**Difficulté :** ★★★★★ HARD (difficulté cible finale — boss principal du jeu)
**Style visuel :** Boss surélevé sur socle (arène circulaire Ø60m), buste dominant le champ de bataille
**Référence gameplay :** bullet-hell multi-phases, héritage Project Kosmos

### Phases

| Phase | Seuil HP | Élément dominant | Comportement |
|---|---|---|---|
| Phase 1 | 100% → 70% | Neutre | Patterns D1/D2 classiques — apprentissage |
| Phase 2 | 70% → 40% | Vent + Feu | Patterns D2/D3 — VFX élémentaires actifs, vents affectent proj |
| Phase 3 | 40% → 0% | Tous les éléments | Patterns D3 + Missiles + Uniques — chaos total |

### Transitions de phase

- **70% HP** : Stagger 2s → +20 HP joueur → flash éclipse partielle → vent global s'active
- **40% HP** : Stagger 3s → +20 HP joueur → éclipse totale → tous éléments simultanés

### Pool d'attaques (héritage Kosmos)

**D1 :** P1001, P1002, P1003, P1004, P1005
**D2 :** P2001, P2004, P2006, P2007 (implémentés) + P2002, P2003, P2005, P2008, P2009 (à porter)
**D3 :** P3001, P3006, P3010 (implémentés) + suite (step07)
**Missiles :** M1001, M2001, M3001 (phase 2+)
**Uniques :** U2001 Boomerang, U3001 Pluie, U3003 Architecture Vivante (stub)

### Élémentaire associé

- Phase 2 : Wind Source actif (affecte vélocité projectiles + déplacement joueur)
- Phase 3 : Fire zones, Earth chunks (Chaos), Water Body (vagues boss)
- Voir `docs/elemental_system.md` pour l'architecture technique

### Musique adaptive

- Cues par phase documentés dans `docs/audio/` (à compléter)
- Transitions : horizontal re-sequencing via Quartz + MetaSounds
- Segments identifiés manuellement sur les tracks source

---

---

## DUMMY TEST BOSS — Boss de test (pas de nom définitif)

> Ce boss sert exclusivement au **test et à l'équilibrage** du gameplay.
> Pas de lore, pas de nom grec — c'est le banc d'essai.
> Actuellement : BP_JB_DummyBoss (sphère ×5, step05)

**Difficulté cible pour les tests :** plage Medium-Hard → Hard → Very Hard
→ L'idée est de tester l'équilibrage sur toute la plage pour trouver le sweet spot

### Niveaux de difficulté de test

| Preset | BossSpeed | PatternFreq | ProjectileSpeed | Dégâts/proj | Usage |
|---|---|---|---|---|---|
| Medium-Hard | 0.8× | 0.85s pause | 900 cm/s | 8 | Warmup — joueur apprend les patterns |
| Hard | 1.0× | 0.75s pause | 1100 cm/s | 12 | Référence — équilibre cible |
| Very Hard | 1.3× | 0.5s pause | 1400 cm/s | 15 | Stress test — chercher les bugs d'équilibrage |

> Ces valeurs sont des points de départ — à ajuster par playtest.
> Le panneau **Gameplay** du menu admin (F9) permet de modifier le speed boss en temps réel.

### Upgrades joueur à tester (notes équilibrage)

Les upgrades affectent la boucle HP/Armor/Ammo — à tester sur le dummy boss avant de les figer :

| Upgrade | Effet | Impact à observer |
|---|---|---|
| Dash Speed +20% | 1680cm/s → 2016cm/s | Est-ce que l'iframe se termine trop tôt sur Very Hard ? |
| Dash Cooldown -100ms | 600ms → 500ms | Trop safe ? Le joueur peut-il dasher en boucle sans skill ? |
| HP Max +25 | 100 → 125 | Allonge le combat → tension réduite ? |
| Fire Rate +30% | 0.10s → 0.07s | DPS joueur trop élevé → boss meurt trop vite en phase 1 ? |
| SP Ammo Max +5 | 10 → 15 | Tir puissant trop fréquent → phase 2 trop facile ? |
| Armor Regen | +5/pattern évité | Power trop passif → casse la philosophie Doom Eternal ? |

> **Règle d'or** : chaque upgrade doit créer un trade-off, pas juste rendre le joueur plus fort.
> Exemple valide : +Dash Speed mais +Cooldown (plus nerveux, moins safe).
> Exemple invalide : +HP Max sans contrepartie (juste un buff passif).

### Méthode de test recommandée

```
1. Lancer avec preset Medium-Hard → jouer 5 min
2. Si pas de mort → passer à Hard
3. Noté : nombre de morts, source (pattern, missile, OOB...)
4. Activer un upgrade → re-tester à Hard
5. Si le fight devient trivial → l'upgrade est trop fort
6. Tester Very Hard : si injouable → revoir PatternFreq ou ProjectileSpeed
```

> Panneau **Boss** du menu admin (F9) : pool selector + forcer une attaque → utile pour tester
> un pattern spécifique en boucle sans attendre le cycle aléatoire.

---

## Boss suivants (à définir)

| Slot | Nom | Thème | Difficulté | Statut |
|---|---|---|---|---|
| Boss 02 | TBD | TBD | TBD | Non défini |
| Boss 03 | TBD | TBD | TBD | Non défini |

---

## Notes design

- Chaque boss = thème visuel fort + mécanique signature différente de Apelpisía
- Cohérence charte : fun/fair play, accessible multi public
- Innovation > convention (véhicule cover, water phase, éclipse = exemples validés)
- Dummy test boss ≠ boss du jeu — ne pas lui donner un nom avant que le gameplay soit stabilisé
