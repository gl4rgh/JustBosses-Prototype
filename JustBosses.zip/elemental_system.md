# Système Élémentaire — Just Bosses

> Inspiration : Breath of the Wild — effets visuels élémentaires (vent/eau/terre/feu) qui interagissent
> avec le gameplay (boss phases, projectiles, déplacement joueur).
> Niveau de complexité ciblé : **détails visuels + impact gameplay léger** (pas de simulation physique complète).

---

## Architecture décidée

### Couche 1 — Visual Only (c++)
Effets visuels purs qui n'affectent pas la logique de jeu.
→ Niagara, materials, Wind Source, post-process.
→ 100% Blueprint.

### Couche 2 — Gameplay Light (Blueprint + C++ optionnel)
Éléments qui affectent le joueur ou les projectiles légèrement.
→ Zone de vent qui dévie les projectiles, zone de feu qui brûle.
→ Blueprint suffit pour la majorité.

### Couche 3 — State Machine Élémentaire (C++ recommandé)
Si on veut des interactions entre éléments (feu + eau = vapeur, vent + feu = propagation).
→ `UJB_ElementalComponent` en C++ → notifie les Blueprints via delegates.
→ À implémenter seulement si le gameplay l'exige clairement.

---

## VENT (Wind)

### UE5 Built-in : Wind Directional Source

`Place Actors → Wind Directional Source`

| Paramètre | Valeur | Notes |
|---|---|---|
| Speed | 0.0 → 5.0 | 0 = calme, 5 = tempête |
| Strength | 0.1 → 1.0 | Multiplicateur global |
| Tightness | 0.0 → 1.0 | 1.0 = directionnel pur, 0.0 = turbulence |

Le Wind Source affecte automatiquement :
- Vegetation WPO (si les materials l'écoutent via `GetWindAtLocation`)
- Niagara Wind Force module (particules dévient dans la direction du vent)
- Chaos Cloth (vêtements personnage si activé)

### Blueprint — Spawn Wind lors d'une phase boss

```
BP_JB_BossController → Phase2Trigger :
  → Spawn Actor "BP_JB_WindSource" (Wind Directional Source wrapper)
  → Set Wind Speed : Timeline 0→3 en 2 secondes (montée progressive)
  → Duration : 8s → Destroy Actor
```

### Gameplay — Vent qui dévie les projectiles

Dans `BP_JB_Projectile` → Event Tick (ou Timer 0.05s pour perf) :
```
Get World Wind → Get Wind Velocity At Position → Add impulse to velocity
Multiplier : 0.1 → 0.3 (léger, pas game-breaking)
```

### Gameplay — Vent qui pousse le joueur

Dans `BP_JB_Character` → Event Tick (si dans zone vent) :
```
Overlap avec BP_JB_WindZone (Box/Sphere Collision) :
  → Launch Character (Force = Wind Direction × WindStrength × 150cm/s)
  → Force appliquée toutes les 0.1s (pas en Tick)
```

### VFX Niagara — NS_JB_Wind

```
Emitter : GPU
Sprite : feuilles / débris / particules de poussière
Niagara Wind Force module : Get Wind from World
Rate : 200 particules/s (léger)
Lifetime : 3s
Velocity Inherit : 80%
Color : transparent blanc-beige (ambiance, pas distraction)
```

---

## FEU (Fire)

### Source : Niagara (pas de plugin externe nécessaire)

Niagara a des templates feu built-in depuis UE5 :
`Content Browser → Add → Niagara System → Templates → Fire`

Ou Quixel Bridge : chercher `fire emitter niagara` → assets prêts.

### NS_JB_Fire — Setup boss

```
Emitter : GPU
Base flame : Sprite animé (flipbook 8×8 fire texture CC0 — Quixel)
Smoke : second émetteur GPU, délai 0.1s, montée lente
Heat distortion : Post Process Distortion material sur la zone

Paramètres exposés :
- FireIntensity (0.0 → 1.0) : scale des émetteurs
- FireColor (Linear Color) : orange normal → rouge phase 3 → blanc phase finale
- Radius : zone de feu (affecte damage zone)
```

### Blueprint — Zone de feu (BP_JB_FireZone)

```
Components :
- Sphere Collision (Radius = 200cm) → damage zone
- Niagara NS_JB_Fire
- Point Light (orange, Intensity 5000, Attenuation 400)

Events :
- OnComponentBeginOverlap (avec Player) → damage 5/s (timer)
- OnComponentEndOverlap → stop damage timer
- Tick (OFF) — tout via Overlap events
```

### Interaction Vent + Feu

Simple version Blueprint :
- Wind Speed > 2.0 → augmenter `FireIntensity` par 0.5
- Spawner NS_JB_FireSpark qui suit la direction du vent
- Pas de vrai spreading procédural (trop complexe pour le gain)

---

## EAU (Water)

> Déjà documenté dans `docs/ue5_demos_assets.md` section 8 (Water Plugin).

### Rappel rapide — Water Body + Boss

- Water Body Lake → arène partiellement inondée phase 2
- Wave Source → vagues concentriques depuis le boss (onde de choc élémentaire)
- Buoyancy Component sur Character → joueur porté par les vagues

### Ajout : pluie élémentaire (NS_JB_Rain)

```
Emitter : GPU, type Sprite (gouttes)
Direction : Z négatif, léger angle vent
Rate : 1000/s (zone d'arène seulement — Cull via Bounds)
Material : translucide, Unlit, opacité 0.3
Impact : Decal splash sur sol (Pool de 20 decals max)
```

### Wetness — Material Parameter

Sur le sol de l'arène : Material Instance avec `Wetness` Scalar (0.0 → 1.0) :
- `Wetness = 0` : sol sec normal
- `Wetness = 1` : sol mouillé (Roughness 0.05, léger reflet Lumen)

Déclenché par BP_JB_WaterPhaseController → Set Material Parameter via Timeline 30s (montée progressive).

---

## TERRE (Earth)

### Chaos Destruction — rochers qui tombent

`Place Actors → Geometry Collection` (component Chaos)

1. Créer un mesh de roche (Quixel `rock_chunk`)
2. Converti en Geometry Collection : clic droit → **Fracture Mesh**
3. Fracture mode : `Uniform` 8–16 morceaux
4. Placer en hauteur dans l'arène (plafond ou hors-champ)
5. Déclencher via BP :

```
BP_JB_EarthAttack :
  → Spawn BP_JB_FallingRock (wrapper Geometry Collection)
  → Disable Chaos simulation au spawn (position figée)
  → Timer 0.5s → Enable Chaos → tombe via gravité
  → Radius damage zone : 150cm (à l'impact)
  → Visual tell : shadow projector au sol 1s avant impact
```

> **Note perf** : Chaos Destruction = CPU coûteux. Limiter à 3–6 rochers max simultanés.
> Désactiver la simulation Chaos après impact (1s post-fracture = `Sleep` threshold).

### Tremblements de sol (Earth quake feel)

```
BP_JB_BossController → EarthPhase :
  → Camera Shake (Blueprint CameraShake, intensity 2.0, durée 3s)
  → Execute Console Command "r.Atmosphere.Fog.Density 0.05" (brume de poussière)
  → Spawn NS_JB_Dust (Niagara GPU, particules de poussière, 500/s, 5s)
```

---

## ÉLECTRICITÉ (Lightning)

> Référence : chain lightning entre joueurs, stun, arc électrique entre surfaces conductrices.
> Intérêt multijoueur : un joueur touché transmet le choc aux joueurs proches (chain, distance max 300cm).

### VFX — NS_JB_Lightning

```
Emitter : GPU
Type : Ribbon (arc de lumière entre 2 points)
  → Point A : source de l'attaque (boss ou zone)
  → Point B : joueur le plus proche
  → Width : 3cm, jitter UV pour effet crépitant
  → Color : bleu-blanc (0.5, 0.8, 1.0) HDR (×8)
  → Lifetime : 0.15s (flash instantané)
  → Second ribbon décalé : offset aléatoire (fork visuel)
Accompagnement : Point Light bleu (Intensity 50000, Attenuation 100cm, durée 0.15s)
```

### Blueprint — BP_JB_LightningZone

```
Components :
- Sphere Collision (Radius = 150cm) → stun zone
- Niagara NS_JB_Lightning
- Audio : son crépitement (SFX_JB_Lightning → Metasound)

Events :
- OnComponentBeginOverlap (Player) :
  → Stun Player 0.8s (désactive inputs mouvement, dash toujours OK)
  → Damage 15 (one-shot — doit esquiver)
  → Chain check : cherche autres Players dans 300cm → propage damage 8
```

### Gameplay — Chain Lightning (multijoueur)

```
BP_JB_LightningAttack → Projectile Homing sur un joueur random :
  → Impact → SphereOverlap 300cm → cherche autres BP_JB_Character
  → Pour chaque joueur trouvé : Damage 8 + Spawn NS_JB_Lightning (arc visuel)
  → Chaîne max 3 sauts (compteur, pas de boucle infinie)
```

> Dangereux en multi : regroupement = game over. Encourage le spacing.
> Dash ne supprime PAS le stun (une fois touché = stun full durée).

### Interaction Électricité + Eau

Eau au sol (Wetness > 0.5) → conducteur :
```
BP_JB_LightningAttack → impact sol → si Wetness Param > 0.5 :
  → SphereOverlap radius ×3 (450cm au lieu de 150cm)
  → Damage réduit à 8 (zone élargie mais moins fort)
  → Visual : NS_JB_LightningSpread (arcs qui rampent sur le sol mouillé)
```

---

## VOID (Gravité / Trou Noir)

> Références : Mothership/Arbiter Black Hole (SC2), Gravity spells (Elden Ring — Meteorite, Gravitas).
> Concept core : **attraction/annihilation** — pas de dégâts directs classiques,
> la zone de Void *aspire* le joueur, supprime les projectiles alliés, et peut briser les iframes dash
> au bout de 2s de contact continu.

### Comportement gameplay

| Phase | Rayon | Effet |
|---|---|---|
| Pull Zone (bord extérieur) | 400cm | Joueur aspiré (force 80cm/s) |
| Danger Zone (milieu) | 200cm | Aspiration 200cm/s + damage 3/s |
| Singularité (centre) | 50cm | Damage 50/s + iframes cassées après 2s |
| Projectile absorption | toute la zone | Annihile les projectiles alliés ET ennemis |

### VFX — NS_JB_VoidSingularity

```
Emitter : GPU
Sphère centrale :
  → Sphere mesh distorté (Material Unlit, distortion via SceneTexture offset)
  → Post Process Sphere Mask → radial blur vers l'intérieur (absorption lens)
  → Color : noir profond avec liseré violet HDR (0.4, 0.0, 1.0) ×12
  → Pulsation lente : scale 0.9 → 1.1 en 0.5s loop

Particules aspirées :
  → Velocity : direction inverse de la singularité (attraction)
  → Particules de décombres/poussière qui spiralent
  → Rate 300/s, lifetime 1s, spirale via Curl Noise module
```

### Blueprint — BP_JB_VoidSingularity

```
Components :
- Sphere Collision "PullZone" (Radius = 400cm) → Pull force
- Sphere Collision "DangerZone" (Radius = 200cm) → Damage + Pull fort
- Sphere Collision "Singularite" (Radius = 50cm) → Death zone
- Niagara NS_JB_VoidSingularity
- Point Light noir-violet (émissivité négative via Lumen — astuce : material PP)

Event Tick (0.05s Timer) :
  → Pour chaque Player dans PullZone :
     → Get direction Player → Singularity center
     → Launch Character vers le centre (force = 80cm/s, ignorer masse)
  → Pour chaque Player dans DangerZone :
     → Launch Character ×2.5 (200cm/s) + Damage 3 * deltaTime
  → Pour chaque Player dans Singularite :
     → Damage 50 * deltaTime
     → InContactTimer += deltaTime → si > 2s : Set bDashInvincible = false

Projectile absorption :
  → OnComponentBeginOverlap (BP_JB_Projectile, any tag) → Destroy Actor
  → VFX : NS_JB_AbsorbPop (petite explosion d'absorption)

Durée : 6s → ShrinkTimeline (scale 1→0 en 0.5s) → Destroy
```

### Anti-cheese

- Le **dash** *à l'intérieur* de la Pull Zone est plus difficile (aspiration constante) — le joueur doit dasher *en dehors* radial
- Si 2 Void actifs simultanément → interactions entre eux (les singularités se repoussent : force répulsive entre BP_JB_VoidSingularity, distance < 600cm)
- Projectiles bossalliés → absorbés aussi (boss tire pas dans sa propre singularité par design)

### Interaction Void + Éléments

| Void + | Effet |
|---|---|
| Fire | Inferno aspiré : la flamme tourne autour de la singularité, zone brûlante annulaire |
| Wind | Spirale amplifiée : Pull force ×1.5, visibilité réduite (NS_JB_Wind aspiré) |
| Earth | Rochers orbitaux : les chunks Chaos orbitent avant de tomber (délai 1s supplémentaire) |
| Water | Vortex liquide : Wetness spread instantané + NS_JB_Rain inversée (eau remonte) |
| Lightning | Arc gravitationnel : chain lightning attire les joueurs vers la singularité lors des arcs |

---

## C++ : UJB_ElementalComponent (optionnel — si interactions nécessaires)

> À implémenter si le gameplay demande des interactions cross-élémentaires.
> Pour l'instant : BP suffit. Ce fichier documente l'architecture si C++ devient nécessaire.

### Quand passer en C++ ?

- Si `GetWorldWind` en Tick devient un goulot (milliers d'acteurs)
- Si on veut un état élémentaire persistant par acteur (projectile "enflammé" par zone feu)
- Si les interactions (feu + vent = taille x2, eau + feu = steam) deviennent trop complexes en BP

### Architecture C++ proposée

```cpp
// E:\JustBosses\JustBosses\Source\JustBosses\Public\JB_ElementalComponent.h

UENUM(BlueprintType)
enum class EJB_Element : uint8
{
    None        UMETA(DisplayName = "None"),
    Fire        UMETA(DisplayName = "Fire"),
    Water       UMETA(DisplayName = "Water"),
    Wind        UMETA(DisplayName = "Wind"),
    Earth       UMETA(DisplayName = "Earth"),
    Lightning   UMETA(DisplayName = "Lightning"),
    Void        UMETA(DisplayName = "Void"),
};

UCLASS(ClassGroup=(JustBosses), meta=(BlueprintSpawnableComponent))
class JUSTBOSSES_API UJB_ElementalComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    // État élémentaire courant
    UPROPERTY(BlueprintReadWrite, Category = "Elemental")
    EJB_Element CurrentElement = EJB_Element::None;

    // Intensité (0.0 = aucun effet, 1.0 = maximum)
    UPROPERTY(BlueprintReadWrite, Category = "Elemental")
    float ElementIntensity = 0.0f;

    // Délégué notifié quand l'état change → BP peut réagir (VFX, damage, etc.)
    UPROPERTY(BlueprintAssignable, Category = "Elemental")
    FOnElementChanged OnElementChanged;

    // Appelé par le boss ou une zone pour changer l'état
    UFUNCTION(BlueprintCallable, Category = "Elemental")
    void ApplyElement(EJB_Element NewElement, float Intensity, float Duration);

    // Table d'interactions : Fire + Water = Steam, etc.
    UFUNCTION(BlueprintCallable, Category = "Elemental")
    EJB_Element ResolveInteraction(EJB_Element A, EJB_Element B);

private:
    FTimerHandle ElementDurationHandle;
    void ClearElement();
};
```

### Table d'interactions élémentaires

| Élément A | Élément B | Résultat | Effet |
|---|---|---|---|
| Fire | Water | Steam | Brouillard opaque 3s, visibilité réduite |
| Fire | Wind | Inferno | FireIntensity ×2, zone élargie |
| Earth | Water | Mud | Joueur ralenti (slow 40%), sol glissant |
| Wind | Water | Spray | Particules fine pluie, Wetness rapide |
| Earth | Fire | Lava | Zone dégâts continus, infranchissable sans dash |
| Lightning | Water | Electrocution | Pull zone ×3, damage ×2, arcs visuels sur sol mouillé |
| Lightning | Wind | StormArc | Chain lightning portée ×2, saut max 5 cibles |
| Void | Fire | FireVortex | Flammes orbitales, zone brûlante annulaire |
| Void | Wind | Maelstrom | Pull force ×1.5, visibilité quasi nulle |
| Void | Earth | OrbitalStrike | Rochers en orbite avant impact (délai +1s) |
| Void | Water | Vortex | Wetness instantané + pluie remontante |
| Void | Lightning | GravArc | Chain lightning aspire les joueurs vers la singularité |

---

## Intégration phases boss — Apelpisía

```
Phase 1 (100→70%) : aucun élément actif
Phase 2 (70→40%) : Wind + Fire (patterns dévient + zones brûlantes)
  → OnPhase2 : SpawnWindSource (Speed 2.0) + SpawnFireZones (3 positions)
  → Patterns D2/D3 modifiés : certains projectiles "enflammés" (couleur rouge + WindOffset)
Phase 3 (40→0%) : Tous les éléments
  → OnPhase3 : EarthAttack toutes les 15s + Water Body flood + Wind max + Fire intense
  → Full chaos — le joueur doit dash constamment pour survivre
```

---

## Checklist implémentation

- [ ] Wind Directional Source wrappé dans BP_JB_WindSource (spawn/destroy via boss)
- [ ] NS_JB_Wind (Niagara débris/feuilles) créé
- [ ] BP_JB_FireZone (collision + damage + NS_JB_Fire) créé
- [ ] NS_JB_Fire template depuis Quixel/Niagara templates
- [ ] BP_JB_FallingRock (Chaos Geometry Collection) créé
- [ ] Water Body Lake placé dans L_Arena_01 (désactivé par défaut, activé phase 2)
- [ ] BP_JB_LightningZone (collision + stun + chain + NS_JB_Lightning) créé
- [ ] BP_JB_VoidSingularity (3 collisions + pull force + absorption projectiles) créé
- [ ] NS_JB_VoidSingularity (distortion sphère + particules spirales) créé
- [ ] BP_JB_BossController → phase triggers branchés sur chaque système élémentaire
- [ ] (Optionnel) UJB_ElementalComponent C++ si interactions nécessaires
