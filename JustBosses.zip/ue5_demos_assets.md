# UE5 Demos & Sample Projects — Assets à migrer

> **Comment migrer des assets vers JustBosses :**
> 1. Ouvrir le projet sample dans UE5 séparément
> 2. Content Browser → sélectionner les assets voulus
> 3. Clic droit → **Asset Actions → Migrate**
> 4. Destination : `E:\JustBosses\JustBosses\Content\`
> UE5 copie tout l'arbre de dépendances (materials, textures, meshes).

> **Alternative Quixel Bridge (plus simple) :**
> Dans l'éditeur JustBosses → `Add → Quixel Bridge` → chercher par nom → clic `Add`.
> Gratuit pour tous les projets UE5.

---

## 1. Valley of the Ancient

**Accès :** Fab.com → chercher "Valley of the Ancient" → Télécharger (gratuit)
**Taille :** ~8 Go
**UE5 compat :** 5.0 → peut nécessiter une recompilation de shaders sur 5.7

| Asset                            | Utilité dans JustBosses           | Dossier source           |
|----------------------------------|-----------------------------------|--------------------------|
| Rochers Nanite (calcaire/grès)   | Murs N1 — galeries d'inspection   | `Content/Rocks/`         |
| Sol caverne (gravier/argile)     | Sol catacombes                    | `Content/Ground/`        |
| Atmospheric fog material         | Brume des catacombes              | `Content/Materials/Atmo` |
| Sky/Lumen setup                  | Référence éclairage indirect      | `Content/Lighting/`      |
| Waterfall/water particles        | Eau qui ruisselle dans les murs   | `Content/Effects/`       |

**Ce qu'on NE migre pas :**
- Le temple entier (trop spécifique, pas Paris)
- Les personnages (on a MetaHuman)

---

## 2. City Sample / The Matrix Awakens

**Accès :** Fab.com → "City Sample" OU "The Matrix Awakens City Sample"
**Taille :** ~100 Go (projet complet) | ~15 Go (assets uniquement)
**UE5 compat :** 5.0/5.1 → recompile shaders sur 5.7, quelques warnings possibles

> ⚠️ **Très lourd.** Télécharger uniquement si tu as l'espace disque. Le 990 Pro tient, mais prévois 150 Go libres avec le cache.

| Asset                            | Utilité dans JustBosses           | Dossier source           |
|----------------------------------|-----------------------------------|--------------------------|
| Façades bâtiments haussmanniens  | Surface + vue depuis les rues     | `Content/Buildings/`     |
| Trottoirs / asphalte Nanite      | Zone de transition surface        | `Content/Roads/`         |
| Lampadaires urbains              | Éclairage rues surface            | `Content/Props/Lights/`  |
| Véhicules (props statiques)      | Cover temporaire en surface       | `Content/Vehicles/`      |
| PCG City rules                   | Génération procédurale rues       | `Content/PCG/`           |
| Night sky / atmospheric          | Ciel nocturne Paris               | `Content/Sky/`           |

**Astuce City Sample :** Les bâtiments utilisent une architecture PCG + Houdini baked.
Pour Just Bosses, prendre les meshes "baked" directement (pas le PCG setup entier).

---

## 3. Electric Dreams Environment

**Accès :** Fab.com → "Electric Dreams Environment"
**Taille :** ~6 Go
**UE5 compat :** 5.1+ → bon sur 5.7

| Asset                            | Utilité dans JustBosses           |
|----------------------------------|-----------------------------------|
| Terrain PCG rules                | Génération procédurale de la zone de surface |
| Végétation Nanite (herbes, fougères) | Détails sol N1 (racines qui percent le calcaire) |
| Rocks proceduraux                | Variation des rochers en catacombes |
| Lumière volumétrique (God Rays)  | Rayon de lumière Zone B (trou dans le plafond) |

**Ce qu'on NE migre pas :**
- Le paysage entier (trop nature, pas urbain)
- Les effets météo (inutile sous terre)

---

## 4. Lyra Starter Game

**Accès :** Fab.com → "Lyra Starter Game" (gratuit)
**Taille :** ~3 Go
**UE5 compat :** 5.x → excellent

> Lyra c'est plus un framework de gameplay qu'un pack d'assets visuels.
> **Ne pas migrer les assets visuels** (beige/plastique, pas notre style).

| Élément                          | Utilité dans JustBosses           |
|----------------------------------|-----------------------------------|
| Input System setup               | Référence Enhanced Input avancé   |
| Character Movement Component     | Référence pour le dash avancé     |
| Game Feature plugins pattern     | Architecture pour futures features|
| AbilitySystem (GAS) setup        | Si on veut implémenter GAS plus tard |

**Usage :** Ouvrir Lyra en référence, lire le code — ne pas migrer d'assets.

---

## 5. Quixel Megascans (via Bridge — PRIORITAIRE)

**Accès :** Dans l'éditeur UE5 → `Add → Quixel Bridge` → connecter compte Epic
**Taille :** Téléchargé à la demande (quelques Mo par asset)
**UE5 compat :** Natif — optimisé 5.x, Nanite activé automatiquement

> **C'est la source principale d'assets pour JustBosses.** Tout est gratuit avec UE5.

### Liste prioritaire pour les catacombes

| Search term                       | Zone        | Priorité |
|-----------------------------------|-------------|----------|
| `limestone wall paris`            | N1          | ★★★      |
| `cave ceiling rock`               | N1 N2       | ★★★      |
| `wet stone floor`                 | N1 N2 N3    | ★★★      |
| `human skull`                     | N2 N3       | ★★★      |
| `human bone`                      | N2 N3       | ★★★      |
| `medieval iron gate`              | Raccourcis  | ★★★      |
| `wall torch medieval`             | N1          | ★★★      |
| `candle melted`                   | N3          | ★★★      |
| `stone arch tunnel`               | Galeries    | ★★       |
| `cobblestone mossy`               | Surface     | ★★       |
| `graffiti concrete`               | N1 (cataphiles) | ★★   |
| `iron spiral staircase`           | Transitions | ★★       |
| `iron ladder rusty`               | Puits N1→N2 | ★★       |
| `water drip rock`                 | Sol N1      | ★        |
| `mushroom rock`                   | Détails     | ★        |

### Liste pour la surface (rues parisiennes)

| Search term                       | Zone        | Priorité |
|-----------------------------------|-------------|----------|
| `haussmann building facade`       | Surface     | ★★★      |
| `paris sidewalk concrete`         | Rues        | ★★★      |
| `wet asphalt night`               | Rues        | ★★★      |
| `street light post`               | Rues        | ★★       |
| `urban dumpster metal`            | Props rue   | ★★       |
| `broken glass window`             | Bâtiments   | ★★       |
| `parisian rooftop zinc`           | Toits       | ★        |

---

## 6. Infiltrator Demo

**Accès :** Fab.com → "Infiltrator Demo" (dans la bibliothèque Epic — **déjà disponible**)
**Taille :** ~3 Go
**UE5 compat :** Originellement UE4 — recompile shaders sur 5.7, peut nécessiter ajustements matériaux

| Asset                            | Utilité dans JustBosses           |
|----------------------------------|-----------------------------------|
| Industrial corridor meshes       | Référence style entrepôt / salle machine |
| Metal panels, pipes, vents       | Déco murs arène industrielle      |
| Character textures (skin, cloth) | Référence MetaHuman si besoin     |
| Lighting setup industrial        | Référence éclairage spot+néon     |

> Assets visuellement impressionnants mais style "sci-fi corporate" — à filtrer pour rester dans le thème JustBosses.

---

## 7. Infinity Blade: Grass Lands

**Accès :** Fab.com → "Infinity Blade: Grass Lands" (dans la bibliothèque Epic — **déjà disponible**)
**Taille :** ~1 Go
**UE5 compat :** UE4 origin — OK sur 5.7 avec recompile

| Asset                            | Utilité dans JustBosses           |
|----------------------------------|-----------------------------------|
| Stone architecture (arches, pillars) | Décor arène style antique/fantasy |
| Rock terrain pieces              | Compléter Valley of the Ancient   |
| Grass, foliage Nanite-upgradeable| Détails naturels N1 catacombes    |
| Modular castle pieces            | Boss arena N3 si style donjon     |

> **Gratuit Epic, déjà dans la lib** — migration immédiate depuis l'Epic Launcher.

---

## 8. Water Plugin (intégré UE5 — pour boss ideas)

**Accès :** `Edit → Plugins → Water` → activer → redémarrer l'éditeur
**Coût :** Gratuit, inclus dans le moteur
**UE 5.7 compat :** Natif — excellent

### Water Body Actors disponibles

| Actor                | Usage                                              |
|----------------------|----------------------------------------------------|
| `Water Body Ocean`   | Zone marine illimitée — pas utile pour arène        |
| `Water Body Lake`    | Zone d'eau fermée (arène inondée, mare de boss)    |
| `Water Body River`   | Courant directionnel (pousse le joueur !)          |
| `Water Body Custom`  | Forme quelconque (flaque asymétrique, etc.)        |

### Capacités GPU

- **Simulation shallow water** (GPU) : vagues + déformation de surface en temps réel
- **Buoyancy Component** : acteurs qui flottent / réagissent aux vagues (BP component)
- **Wave sources** : spawn des vagues programmatiquement depuis un BP → **boss attack idea**

### Setup rapide (arène inondée)

```
1. Edit → Plugins → Water → activer
2. Place Actors → chercher "Water Body Lake"
3. Dessiner la zone d'eau dans le viewport
4. Le Water Body génère automatiquement sa simulation
5. Sur BP_JB_Character → Add Component → BuoyancyComponent
   → Le joueur flotte si il tombe dans l'eau
```

### Idée boss — Water Phase

```
Boss Phase 2 → spawner WaveSource actors :
  → vagues concentriques depuis le boss (onde de choc)
  → courant Water Body River de 3 secondes (pousse le joueur hors d'une zone safe)
  → arène partiellement inondée = zones safe réduites
  → le joueur doit dash pour ne pas être emporté (synerg avec iframes)
```

> Coût perf : Simulation GPU → cheap sur RTX 4080. Activer `r.Water.SingleLayer.Reflection 1` pour reflets Lumen.

---

## 9. Ancient Game (Soul: City)

**Accès :** Fab.com → rechercher "Soul: City" ou "Ancient Game"
**Status :** Asset packs optionnels payants ou anciens samples Epic

> Moins pertinent pour Just Bosses. À ignorer si budget/temps limités.

---

## 10. Fab.com — Assets gratuits spécifiques à chercher

> Fab.com = le nouveau Marketplace Epic, intègre Sketchfab + Quixel + créateurs tiers.
> Filtrer : **Price = Free | Engine = Unreal | Category = Environments**

| Titre à chercher sur Fab          | Usage                              |
|-----------------------------------|------------------------------------|
| `Modular Dungeon Kit`             | Kit modulaire catacombes           |
| `Underground Cave Kit`            | Galeries souterraines              |
| `Medieval Catacomb Pack`          | Si disponible — assets spécialisés |
| `Ossuary / Cemetery Assets`       | Crânes, croix, ambiance           |
| `Modular City Streets`            | Rues modulaires Paris-style        |
| `Night City Lights Pack`          | Néons et éclairage nocturne        |
| `Sci-Fi Particle Effects`         | Effets pour les projectiles boss   |
| `Electric VFX Niagara`            | Effets électriques (NS_ElectricBolt) |

---

## 11. Ordre de téléchargement recommandé

```
PHASE 1 — Prototype (maintenant) :
  ✓ Quixel Bridge → skull + limestone + torch (30 min de download)
  → Suffit pour le whitebox de la boss arena

PHASE 2 — Niveau jouable :
  → Quixel Bridge → tous les assets N1/N2 de la liste
  → Fab gratuits → Modular Dungeon Kit si trouvé

PHASE 3 — Surface + polish :
  → City Sample (assets uniquement, pas le PCG)
  → Valley of the Ancient → rochers + water VFX

PHASE 4 — Finition :
  → Electric Dreams → God Rays pour Zone B
  → Electric VFX Niagara → NS_ElectricBolt
```

---

## 12. Notes compatibilité UE 5.7.3

| Projet              | Risque compat | Solution                              |
|---------------------|---------------|---------------------------------------|
| Valley of Ancient   | Moyen         | Recompile shaders, vérifier materials |
| City Sample         | Moyen-Élevé   | PCG pas garanti, prendre meshes baked |
| Electric Dreams     | Faible        | Natif 5.1+, OK                        |
| Lyra                | Faible        | Natif 5.x, OK                         |
| Infiltrator Demo    | Faible-Moyen  | UE4 origin, materials à vérifier      |
| Infinity Blade GL   | Faible-Moyen  | UE4 origin, majority OK en 5.7.3      |
| Quixel Bridge       | Aucun         | Natif, optimisé pour 5.7.3            |
| Water Plugin        | Aucun         | Built-in 5.x, natif                   |
| Fab assets tiers    | Variable      | Vérifier la version min de l'auteur   |
